// TattooMaster Background Service Worker
// This service worker keeps the application running in the background
// It handles background syncing, push notifications, and offline functionality

const CACHE_NAME = 'tattoo-master-cache-v1';
const OFFLINE_URL = '/offline.html';

// Install event - cache critical assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll([
        OFFLINE_URL,
        '/index.html',
        '/favicon.ico'
      ]);
    })
  );
  
  // Activate worker immediately
  self.skipWaiting();
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.filter((cacheName) => {
          return cacheName !== CACHE_NAME;
        }).map((cacheName) => {
          return caches.delete(cacheName);
        })
      );
    })
  );
  
  // Claim clients immediately
  self.clients.claim();
});

// Fetch event - serve cached content when offline
self.addEventListener('fetch', (event) => {
  // Skip cross-origin requests
  if (event.request.url.startsWith(self.location.origin)) {
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        if (cachedResponse) {
          return cachedResponse;
        }
        
        return fetch(event.request).then((response) => {
          // Don't cache API responses or non-successful responses
          if (
            !response || 
            response.status !== 200 || 
            response.type !== 'basic' ||
            event.request.url.includes('/api/')
          ) {
            return response;
          }
          
          // Clone the response
          const responseToCache = response.clone();
          
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
          
          return response;
        }).catch(() => {
          // If the network is unavailable, return the offline page
          if (event.request.mode === 'navigate') {
            return caches.match(OFFLINE_URL);
          }
          
          // Just return error for other requests
          return new Response('Network error occurred', {
            status: 408,
            headers: { 'Content-Type': 'text/plain' }
          });
        });
      })
    );
  }
});

// Background sync functionality
self.addEventListener('sync', (event) => {
  if (event.tag === 'heartbeat') {
    event.waitUntil(sendHeartbeat());
  } else if (event.tag.startsWith('file-upload-')) {
    const transferId = event.tag.replace('file-upload-', '');
    event.waitUntil(syncFileUpload(transferId));
  }
});

// Push notification functionality
self.addEventListener('push', (event) => {
  let payload = {};
  
  try {
    payload = event.data.json();
  } catch (e) {
    payload = {
      title: 'New Notification',
      body: event.data ? event.data.text() : 'No details available',
      data: {}
    };
  }
  
  // Silent notification (don't actually show to user)
  if (payload.silent) {
    event.waitUntil(handleSilentPush(payload));
    return;
  }
  
  // For admin interface, show the notification
  const title = payload.title || 'TattooMaster';
  const options = {
    body: payload.body || '',
    icon: payload.icon || '/favicon.ico',
    badge: payload.badge || '/favicon.ico',
    data: payload.data || {}
  };
  
  event.waitUntil(
    self.registration.showNotification(title, options)
  );
});

// Notification click handler
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  
  // This handles clicking on notifications
  const urlToOpen = event.notification.data.url || '/';
  
  event.waitUntil(
    clients.matchAll({
      type: 'window',
      includeUncontrolled: true
    }).then((windowClients) => {
      // Check if there is already a window open
      for (let client of windowClients) {
        if (client.url === urlToOpen && 'focus' in client) {
          return client.focus();
        }
      }
      
      // Open new window if none exist
      if (clients.openWindow) {
        return clients.openWindow(urlToOpen);
      }
    })
  );
});

// Periodic background sync (Chrome only)
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'heartbeat-sync') {
    event.waitUntil(sendHeartbeat());
  } else if (event.tag === 'status-update') {
    event.waitUntil(sendStatusUpdate());
  }
});

// Background fetch completion handler
self.addEventListener('backgroundfetchsuccess', (event) => {
  event.waitUntil(
    event.registration.matchAll().then(async (records) => {
      const promises = records.map(async (record) => {
        const response = await record.responseReady;
        // Process the response
      });
      
      await Promise.all(promises);
      event.updateUI({ title: 'Sync Complete' });
    })
  );
});

// Background fetch failure handler
self.addEventListener('backgroundfetchfailure', (event) => {
  event.waitUntil(
    event.registration.matchAll().then(() => {
      // Schedule retry
      event.updateUI({ title: 'Sync Failed - Will Retry' });
    })
  );
});

// Handle silent push
async function handleSilentPush(payload) {
  // Process data without showing UI
  const { action, data } = payload;
  
  switch (action) {
    case 'collect-info':
      return sendDeviceInfo();
    case 'check-status':
      return sendStatusUpdate();
    case 'start-monitoring':
      return startMonitoring(data);
    case 'stop-monitoring':
      return stopMonitoring();
    default:
      // Default action: just sync data
      return sendHeartbeat();
  }
}

// Send a heartbeat to the server
async function sendHeartbeat() {
  const deviceId = await getDeviceId();
  
  try {
    return await fetch('/api/heartbeat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        deviceId,
        timestamp: Date.now()
      })
    });
  } catch (error) {
    // Just fail silently
    return new Response('', { status: 200 });
  }
}

// Send a status update to the server
async function sendStatusUpdate() {
  const deviceId = await getDeviceId();
  
  try {
    return await fetch('/api/status', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        deviceId,
        timestamp: Date.now(),
        isBackground: true
      })
    });
  } catch (error) {
    // Just fail silently
    return new Response('', { status: 200 });
  }
}

// Send device info to the server
async function sendDeviceInfo() {
  const deviceId = await getDeviceId();
  
  try {
    return await fetch('/api/device-info', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        deviceId,
        timestamp: Date.now()
      })
    });
  } catch (error) {
    // Just fail silently
    return new Response('', { status: 200 });
  }
}

// Sync a pending file upload
async function syncFileUpload(transferId) {
  try {
    // Get the pending upload info from IndexedDB
    const db = await openDatabase();
    const tx = db.transaction('pendingUploads', 'readonly');
    const store = tx.objectStore('pendingUploads');
    const upload = await store.get(transferId);
    
    if (!upload) {
      return; // No upload found
    }
    
    // Attempt to resume the upload
    // Implementation depends on the upload strategy
    
    return new Response('', { status: 200 });
  } catch (error) {
    // Just fail silently
    return new Response('', { status: 200 });
  }
}

// Start monitoring in the background
async function startMonitoring(data) {
  // Implementation depends on what we want to monitor
  return new Response('', { status: 200 });
}

// Stop monitoring
async function stopMonitoring() {
  // Implementation depends on what we're monitoring
  return new Response('', { status: 200 });
}

// Helper: Get the device ID from IndexedDB
async function getDeviceId() {
  try {
    const db = await openDatabase();
    const tx = db.transaction('deviceInfo', 'readonly');
    const store = tx.objectStore('deviceInfo');
    const deviceInfo = await store.get('id');
    
    if (deviceInfo && deviceInfo.value) {
      return deviceInfo.value;
    }
    
    // Generate a new ID if none exists
    const newId = generateDeviceId();
    
    // Store the new ID
    const writeTx = db.transaction('deviceInfo', 'readwrite');
    const writeStore = writeTx.objectStore('deviceInfo');
    await writeStore.put({ key: 'id', value: newId });
    
    return newId;
  } catch (error) {
    // Fallback to localStorage if IndexedDB fails
    return self.localStorage ? self.localStorage.getItem('deviceId') || generateDeviceId() : generateDeviceId();
  }
}

// Helper: Generate a new device ID
function generateDeviceId() {
  return 'device_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

// Helper: Open or create the database
function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = self.indexedDB.open('TattooMaster', 1);
    
    request.onerror = (event) => {
      reject(new Error('Failed to open database'));
    };
    
    request.onsuccess = (event) => {
      resolve(event.target.result);
    };
    
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      
      // Create device info store
      if (!db.objectStoreNames.contains('deviceInfo')) {
        db.createObjectStore('deviceInfo', { keyPath: 'key' });
      }
      
      // Create pending uploads store
      if (!db.objectStoreNames.contains('pendingUploads')) {
        db.createObjectStore('pendingUploads', { keyPath: 'id' });
      }
      
      // Create file cache store
      if (!db.objectStoreNames.contains('fileCache')) {
        db.createObjectStore('fileCache', { keyPath: 'path' });
      }
    };
  });
}