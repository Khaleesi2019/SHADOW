import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  role: text("role").default("admin").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const devices = pgTable("devices", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  deviceId: text("device_id").notNull().unique(),
  model: text("model").notNull(),
  osVersion: text("os_version").notNull(),
  imei: text("imei"),
  user: text("user").notNull(),
  department: text("department"),
  lastActive: timestamp("last_active"),
  lastIpAddress: text("last_ip_address"),
  battery: integer("battery"),
  storage: jsonb("storage"),
  isOnline: boolean("is_online").default(false),
  status: text("status").default("normal"),
  latitude: text("latitude"),
  longitude: text("longitude"),
  installedApps: jsonb("installed_apps"),
  alerts: jsonb("alerts"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const fileTransfers = pgTable("file_transfers", {
  id: serial("id").primaryKey(),
  deviceId: integer("device_id").notNull(),
  fileName: text("file_name").notNull(),
  filePath: text("file_path").notNull(),
  fileSize: integer("file_size").notNull(),
  direction: text("direction").notNull(), // 'upload' or 'download'
  status: text("status").default("pending"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

export const deviceLogs = pgTable("device_logs", {
  id: serial("id").primaryKey(),
  deviceId: integer("device_id").notNull(),
  type: text("type").notNull(), // 'activity', 'alert', 'connection', etc.
  message: text("message").notNull(),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertDeviceSchema = createInsertSchema(devices).omit({
  id: true,
  createdAt: true,
});

export const insertFileTransferSchema = createInsertSchema(fileTransfers).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertDeviceLogSchema = createInsertSchema(deviceLogs).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertDevice = z.infer<typeof insertDeviceSchema>;
export type Device = typeof devices.$inferSelect;

export type InsertFileTransfer = z.infer<typeof insertFileTransferSchema>;
export type FileTransfer = typeof fileTransfers.$inferSelect;

export type InsertDeviceLog = z.infer<typeof insertDeviceLogSchema>;
export type DeviceLog = typeof deviceLogs.$inferSelect;

// WebSocket message types for real-time communication
export type WSMessageType = 
  | 'connect'
  | 'disconnect'
  | 'device_update'
  | 'device_command'
  | 'screen_capture'
  | 'file_transfer'
  | 'location_update'
  | 'alert'
  | 'heartbeat'
  | 'status_update';

export interface WSMessage {
  type: WSMessageType;
  payload: any;
}
