import { users, type User, type InsertUser, devices, type Device, type InsertDevice, fileTransfers, type FileTransfer, type InsertFileTransfer, deviceLogs, type DeviceLog, type InsertDeviceLog } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Device methods
  getDevice(id: number): Promise<Device | undefined>;
  getDeviceByDeviceId(deviceId: string): Promise<Device | undefined>;
  getDevices(): Promise<Device[]>;
  createDevice(device: InsertDevice): Promise<Device>;
  updateDevice(id: number, device: Partial<Device>): Promise<Device | undefined>;
  updateDeviceStatus(deviceId: string, isOnline: boolean, status?: string): Promise<Device | undefined>;
  
  // File Transfer methods
  getFileTransfers(deviceId: number): Promise<FileTransfer[]>;
  createFileTransfer(transfer: InsertFileTransfer): Promise<FileTransfer>;
  updateFileTransferStatus(id: number, status: string, completedAt?: Date): Promise<FileTransfer | undefined>;
  
  // Device Log methods
  getDeviceLogs(deviceId: number): Promise<DeviceLog[]>;
  createDeviceLog(log: InsertDeviceLog): Promise<DeviceLog>;
  
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private devices: Map<number, Device>;
  private fileTransfers: Map<number, FileTransfer>;
  private deviceLogs: Map<number, DeviceLog>;
  sessionStore: session.SessionStore;
  
  private userIdCounter: number;
  private deviceIdCounter: number;
  private fileTransferIdCounter: number;
  private deviceLogIdCounter: number;

  constructor() {
    this.users = new Map();
    this.devices = new Map();
    this.fileTransfers = new Map();
    this.deviceLogs = new Map();
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24h in ms
    });
    
    this.userIdCounter = 1;
    this.deviceIdCounter = 1;
    this.fileTransferIdCounter = 1;
    this.deviceLogIdCounter = 1;
    
    // Create initial admin user
    this.createUser({
      username: 'admin',
      password: '$2b$10$PoIKXC.1DvTm2mKz9YkL1.A3Ys6/ZSNLlz.C3EF7zsmxf1Yq.sbIG', // hashed "admin123"
      name: 'System Admin',
      email: 'admin@company.com',
      role: 'admin'
    });
    
    // Create sample devices
    this.setupSampleDevices();
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }
  
  // Device methods
  async getDevice(id: number): Promise<Device | undefined> {
    return this.devices.get(id);
  }
  
  async getDeviceByDeviceId(deviceId: string): Promise<Device | undefined> {
    return Array.from(this.devices.values()).find(
      (device) => device.deviceId === deviceId,
    );
  }
  
  async getDevices(): Promise<Device[]> {
    return Array.from(this.devices.values());
  }
  
  async createDevice(device: InsertDevice): Promise<Device> {
    const id = this.deviceIdCounter++;
    const now = new Date();
    const newDevice: Device = { ...device, id, createdAt: now };
    this.devices.set(id, newDevice);
    return newDevice;
  }
  
  async updateDevice(id: number, updateData: Partial<Device>): Promise<Device | undefined> {
    const device = this.devices.get(id);
    if (!device) return undefined;
    
    const updatedDevice = { ...device, ...updateData };
    this.devices.set(id, updatedDevice);
    return updatedDevice;
  }
  
  async updateDeviceStatus(deviceId: string, isOnline: boolean, status?: string): Promise<Device | undefined> {
    const device = Array.from(this.devices.values()).find(
      (device) => device.deviceId === deviceId,
    );
    
    if (!device) return undefined;
    
    const updatedDevice = { 
      ...device, 
      isOnline, 
      ...(status && { status }), 
      lastActive: new Date() 
    };
    
    this.devices.set(device.id, updatedDevice);
    return updatedDevice;
  }
  
  // File Transfer methods
  async getFileTransfers(deviceId: number): Promise<FileTransfer[]> {
    return Array.from(this.fileTransfers.values()).filter(
      (transfer) => transfer.deviceId === deviceId,
    );
  }
  
  async createFileTransfer(transfer: InsertFileTransfer): Promise<FileTransfer> {
    const id = this.fileTransferIdCounter++;
    const now = new Date();
    const newTransfer: FileTransfer = { ...transfer, id, createdAt: now, completedAt: null };
    this.fileTransfers.set(id, newTransfer);
    return newTransfer;
  }
  
  async updateFileTransferStatus(id: number, status: string, completedAt?: Date): Promise<FileTransfer | undefined> {
    const transfer = this.fileTransfers.get(id);
    if (!transfer) return undefined;
    
    const updatedTransfer: FileTransfer = { 
      ...transfer, 
      status, 
      ...(completedAt && { completedAt }) 
    };
    
    this.fileTransfers.set(id, updatedTransfer);
    return updatedTransfer;
  }
  
  // Device Log methods
  async getDeviceLogs(deviceId: number): Promise<DeviceLog[]> {
    return Array.from(this.deviceLogs.values())
      .filter((log) => log.deviceId === deviceId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async createDeviceLog(log: InsertDeviceLog): Promise<DeviceLog> {
    const id = this.deviceLogIdCounter++;
    const now = new Date();
    const newLog: DeviceLog = { ...log, id, createdAt: now };
    this.deviceLogs.set(id, newLog);
    return newLog;
  }
  
  // Helper to setup initial data
  private setupSampleDevices() {
    const sampleDevices: InsertDevice[] = [
      {
        name: 'Samsung Galaxy S21',
        deviceId: 'SGS21-001',
        model: 'Samsung Galaxy S21',
        osVersion: 'Android 12',
        imei: '359125420413782',
        user: 'Maria Lopez',
        department: 'Sales',
        lastIpAddress: '192.168.1.45',
        battery: 85,
        storage: { used: 23.5, total: 128 },
        isOnline: true,
        status: 'normal',
        installedApps: [
          { name: 'Gmail', packageName: 'com.google.android.gm' },
          { name: 'Chrome', packageName: 'com.android.chrome' },
          { name: 'WhatsApp', packageName: 'com.whatsapp' }
        ],
        alerts: []
      },
      {
        name: 'iPhone 13',
        deviceId: 'IP13-002',
        model: 'iPhone 13',
        osVersion: 'iOS 15.4',
        imei: '356538072453186',
        user: 'Carlos Mendez',
        department: 'Marketing',
        lastIpAddress: '192.168.1.72',
        battery: 42,
        storage: { used: 78, total: 256 },
        isOnline: true,
        status: 'normal',
        installedApps: [
          { name: 'Mail', packageName: 'com.apple.mail' },
          { name: 'Safari', packageName: 'com.apple.safari' },
          { name: 'Slack', packageName: 'com.slack' }
        ],
        alerts: []
      },
      {
        name: 'Xiaomi Redmi Note',
        deviceId: 'XRN-003',
        model: 'Xiaomi Redmi Note 11',
        osVersion: 'Android 11',
        imei: '866619048327554',
        user: 'Juan Perez',
        department: 'Warehouse',
        lastIpAddress: '192.168.1.105',
        battery: 95,
        storage: { used: 42, total: 128 },
        isOnline: true,
        status: 'alert',
        alerts: [
          { id: 1, type: 'security', message: 'Unusual activity detected: Accessing secure app storage', timestamp: new Date().toISOString() }
        ],
        installedApps: [
          { name: 'Gmail', packageName: 'com.google.android.gm' },
          { name: 'Chrome', packageName: 'com.android.chrome' },
          { name: 'WhatsApp', packageName: 'com.whatsapp' }
        ]
      },
      {
        name: 'Motorola G Power',
        deviceId: 'MGP-004',
        model: 'Motorola G Power',
        osVersion: 'Android 11',
        imei: '351756102486753',
        user: 'Ana Rivera',
        department: 'Support',
        lastIpAddress: '192.168.1.89',
        battery: 67,
        storage: { used: 35, total: 64 },
        isOnline: true,
        status: 'normal',
        installedApps: [
          { name: 'Gmail', packageName: 'com.google.android.gm' },
          { name: 'Chrome', packageName: 'com.android.chrome' },
          { name: 'WhatsApp', packageName: 'com.whatsapp' }
        ],
        alerts: []
      },
      {
        name: 'Google Pixel 6',
        deviceId: 'GP6-005',
        model: 'Google Pixel 6',
        osVersion: 'Android 12',
        imei: '352075098645321',
        user: 'Roberto Garcia',
        department: 'IT',
        lastIpAddress: '192.168.1.124',
        battery: null,
        storage: { used: 45, total: 128 },
        isOnline: false,
        status: 'normal',
        installedApps: [
          { name: 'Gmail', packageName: 'com.google.android.gm' },
          { name: 'Chrome', packageName: 'com.android.chrome' },
          { name: 'Slack', packageName: 'com.slack' }
        ],
        alerts: []
      },
      {
        name: 'Samsung Galaxy A32',
        deviceId: 'SGA32-006',
        model: 'Samsung Galaxy A32',
        osVersion: 'Android 11',
        imei: '354269107548632',
        user: 'Miguel Torres',
        department: 'Sales',
        lastIpAddress: '192.168.1.67',
        battery: 15,
        storage: { used: 28, total: 64 },
        isOnline: true,
        status: 'alert',
        alerts: [
          { id: 2, type: 'location', message: 'Geofence violation: Outside of allowed perimeter', timestamp: new Date().toISOString() }
        ],
        installedApps: [
          { name: 'Gmail', packageName: 'com.google.android.gm' },
          { name: 'Chrome', packageName: 'com.android.chrome' },
          { name: 'WhatsApp', packageName: 'com.whatsapp' }
        ]
      }
    ];
    
    // Create the sample devices
    sampleDevices.forEach(device => {
      this.createDevice({
        ...device,
        lastActive: new Date()
      });
    });
  }
}

// Export a singleton instance
export const storage = new MemStorage();
