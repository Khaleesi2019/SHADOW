import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { storage } from './storage';
import { WSMessage, WSMessageType, Device } from '@shared/schema';

// Map to store active device connections
const connectedDevices = new Map<string, WebSocket>();
// Map to store active admin connections
const adminConnections = new Set<WebSocket>();

export function setupWebSocket(server: Server) {
  const wss = new WebSocketServer({ server, path: '/ws' });
  
  wss.on('connection', (ws: WebSocket) => {
    console.log('New WebSocket connection');
    
    // Temporary storage for client identity
    let clientType: 'admin' | 'device' = 'admin';
    let deviceId: string | null = null;
    
    ws.on('message', async (message: string) => {
      try {
        // Parse incoming message
        const data: WSMessage = JSON.parse(message);
        
        // Handle connection initialization
        if (data.type === 'connect') {
          const { type, id } = data.payload;
          
          if (type === 'device') {
            clientType = 'device';
            deviceId = id;
            
            // Register device connection
            connectedDevices.set(id, ws);
            
            // Update device status in storage
            await storage.updateDeviceStatus(id, true);
            
            // Log the connection
            await storage.createDeviceLog({
              deviceId: (await storage.getDeviceByDeviceId(id))?.id || 0,
              type: 'connection',
              message: 'Device connected',
              metadata: { timestamp: new Date().toISOString() }
            });
            
            // Broadcast to all admins that this device is now online
            broadcastToAdmins({
              type: 'device_update',
              payload: { 
                deviceId: id, 
                isOnline: true,
                lastActive: new Date().toISOString()
              }
            });
            
            console.log(`Device ${id} connected`);
          } else if (type === 'admin') {
            // Register admin connection
            adminConnections.add(ws);
            console.log('Admin connected');
          }
        } 
        // Handle device updates (status, battery, etc.)
        else if (data.type === 'device_update' && deviceId) {
          const device = await storage.getDeviceByDeviceId(deviceId);
          if (device) {
            await storage.updateDevice(device.id, data.payload);
            
            // Broadcast update to all admins
            broadcastToAdmins({
              type: 'device_update',
              payload: {
                deviceId,
                ...data.payload
              }
            });
          }
        }
        // Handle alerts from devices
        else if (data.type === 'alert' && deviceId) {
          const device = await storage.getDeviceByDeviceId(deviceId);
          if (device) {
            // Update device status to alert
            await storage.updateDevice(device.id, { 
              status: 'alert', 
              alerts: [...(device.alerts || []), data.payload]
            });
            
            // Create log entry
            await storage.createDeviceLog({
              deviceId: device.id,
              type: 'alert',
              message: data.payload.message,
              metadata: data.payload
            });
            
            // Broadcast alert to all admins
            broadcastToAdmins({
              type: 'alert',
              payload: {
                deviceId,
                alert: data.payload
              }
            });
          }
        }
        // Handle location updates
        else if (data.type === 'location_update' && deviceId) {
          const device = await storage.getDeviceByDeviceId(deviceId);
          if (device) {
            await storage.updateDevice(device.id, {
              latitude: data.payload.latitude,
              longitude: data.payload.longitude,
              lastActive: new Date()
            });
            
            // Broadcast to admins
            broadcastToAdmins({
              type: 'location_update',
              payload: {
                deviceId,
                latitude: data.payload.latitude,
                longitude: data.payload.longitude,
                timestamp: new Date().toISOString()
              }
            });
          }
        }
        // Handle screen capture data
        else if (data.type === 'screen_capture' && deviceId) {
          // Forward screen capture data to admins that are monitoring this device
          broadcastToAdmins({
            type: 'screen_capture',
            payload: {
              deviceId,
              imageData: data.payload.imageData,
              timestamp: new Date().toISOString()
            }
          });
        }
        // Handle file transfer progress updates
        else if (data.type === 'file_transfer' && deviceId) {
          broadcastToAdmins({
            type: 'file_transfer',
            payload: {
              deviceId,
              ...data.payload
            }
          });
        }
        // Handle admin commands to devices
        else if (data.type === 'device_command' && clientType === 'admin') {
          const targetDevice = data.payload.deviceId;
          const deviceWs = connectedDevices.get(targetDevice);
          
          if (deviceWs && deviceWs.readyState === WebSocket.OPEN) {
            deviceWs.send(JSON.stringify({
              type: 'device_command',
              payload: data.payload.command
            }));
            
            // Log the command
            const device = await storage.getDeviceByDeviceId(targetDevice);
            if (device) {
              await storage.createDeviceLog({
                deviceId: device.id,
                type: 'command',
                message: `Command: ${data.payload.command.type}`,
                metadata: data.payload.command
              });
            }
          } else {
            // Send error back to admin if device is not connected
            ws.send(JSON.stringify({
              type: 'error',
              payload: {
                message: 'Device is not connected',
                deviceId: targetDevice
              }
            }));
          }
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });
    
    // Handle connection close
    ws.on('close', async () => {
      if (clientType === 'device' && deviceId) {
        // Remove from connected devices
        connectedDevices.delete(deviceId);
        
        // Update device status in storage
        await storage.updateDeviceStatus(deviceId, false);
        
        // Log the disconnection
        const device = await storage.getDeviceByDeviceId(deviceId);
        if (device) {
          await storage.createDeviceLog({
            deviceId: device.id,
            type: 'connection',
            message: 'Device disconnected',
            metadata: { timestamp: new Date().toISOString() }
          });
        }
        
        // Broadcast to all admins that this device is now offline
        broadcastToAdmins({
          type: 'device_update',
          payload: { 
            deviceId, 
            isOnline: false,
            lastActive: new Date().toISOString()
          }
        });
        
        console.log(`Device ${deviceId} disconnected`);
      } else if (clientType === 'admin') {
        // Remove from admin connections
        adminConnections.delete(ws);
        console.log('Admin disconnected');
      }
    });
  });
  
  return wss;
}

// Helper function to broadcast a message to all connected admin clients
function broadcastToAdmins(message: WSMessage) {
  adminConnections.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(message));
    }
  });
}

// Helper function to broadcast to specific admin
export function sendToAdmin(adminWs: WebSocket, message: WSMessage) {
  if (adminWs.readyState === WebSocket.OPEN) {
    adminWs.send(JSON.stringify(message));
  }
}

// Helper function to broadcast to specific device
export function sendToDevice(deviceId: string, message: WSMessage) {
  const deviceWs = connectedDevices.get(deviceId);
  if (deviceWs && deviceWs.readyState === WebSocket.OPEN) {
    deviceWs.send(JSON.stringify(message));
    return true;
  }
  return false;
}

// Get all connected devices
export function getConnectedDevices() {
  return Array.from(connectedDevices.keys());
}

// Check if device is connected
export function isDeviceConnected(deviceId: string) {
  return connectedDevices.has(deviceId);
}
