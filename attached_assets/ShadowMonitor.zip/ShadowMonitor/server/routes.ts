import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { setupWebSocket, sendToDevice } from "./websocket";
import { z } from "zod";
import { insertDeviceSchema, insertFileTransferSchema, insertDeviceLogSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Setup authentication routes
  setupAuth(app);
  
  // Setup WebSocket server
  setupWebSocket(httpServer);
  
  // Middleware to check authentication for API routes
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };
  
  // Device routes
  app.get("/api/devices", requireAuth, async (req, res) => {
    try {
      const devices = await storage.getDevices();
      res.json(devices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch devices" });
    }
  });
  
  app.get("/api/devices/:id", requireAuth, async (req, res) => {
    try {
      const device = await storage.getDevice(parseInt(req.params.id));
      if (!device) {
        return res.status(404).json({ message: "Device not found" });
      }
      res.json(device);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch device" });
    }
  });
  
  app.post("/api/devices", requireAuth, async (req, res) => {
    try {
      const deviceData = insertDeviceSchema.parse(req.body);
      const device = await storage.createDevice(deviceData);
      res.status(201).json(device);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid device data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create device" });
    }
  });
  
  app.patch("/api/devices/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = req.body;
      
      const updatedDevice = await storage.updateDevice(id, updateData);
      if (!updatedDevice) {
        return res.status(404).json({ message: "Device not found" });
      }
      
      res.json(updatedDevice);
    } catch (error) {
      res.status(500).json({ message: "Failed to update device" });
    }
  });
  
  // File Transfer routes
  app.get("/api/devices/:deviceId/files", requireAuth, async (req, res) => {
    try {
      const deviceId = parseInt(req.params.deviceId);
      const transfers = await storage.getFileTransfers(deviceId);
      res.json(transfers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch file transfers" });
    }
  });
  
  app.post("/api/devices/:deviceId/files", requireAuth, async (req, res) => {
    try {
      const deviceId = parseInt(req.params.deviceId);
      
      const transferData = insertFileTransferSchema.parse({
        ...req.body,
        deviceId
      });
      
      const transfer = await storage.createFileTransfer(transferData);
      
      // Notify device about the file transfer request via WebSocket
      const device = await storage.getDevice(deviceId);
      if (device) {
        const success = sendToDevice(device.deviceId, {
          type: 'file_transfer',
          payload: {
            id: transfer.id,
            action: 'request',
            ...transferData
          }
        });
        
        if (!success) {
          return res.status(422).json({ message: "Device is not connected" });
        }
      }
      
      res.status(201).json(transfer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid file transfer data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create file transfer" });
    }
  });
  
  app.patch("/api/files/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      const updatedTransfer = await storage.updateFileTransferStatus(
        id, 
        status,
        status === 'completed' ? new Date() : undefined
      );
      
      if (!updatedTransfer) {
        return res.status(404).json({ message: "File transfer not found" });
      }
      
      res.json(updatedTransfer);
    } catch (error) {
      res.status(500).json({ message: "Failed to update file transfer" });
    }
  });
  
  // Device Logs routes
  app.get("/api/devices/:deviceId/logs", requireAuth, async (req, res) => {
    try {
      const deviceId = parseInt(req.params.deviceId);
      const logs = await storage.getDeviceLogs(deviceId);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch device logs" });
    }
  });
  
  app.post("/api/devices/:deviceId/logs", requireAuth, async (req, res) => {
    try {
      const deviceId = parseInt(req.params.deviceId);
      
      const logData = insertDeviceLogSchema.parse({
        ...req.body,
        deviceId
      });
      
      const log = await storage.createDeviceLog(logData);
      res.status(201).json(log);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid log data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create log" });
    }
  });

  // Device control API endpoint
  app.post("/api/devices/:deviceId/command", requireAuth, async (req, res) => {
    try {
      const deviceId = req.params.deviceId;
      const command = req.body.command;
      
      const device = await storage.getDeviceByDeviceId(deviceId);
      if (!device) {
        return res.status(404).json({ message: "Device not found" });
      }
      
      // Send command to device via WebSocket
      const success = sendToDevice(deviceId, {
        type: 'device_command',
        payload: command
      });
      
      if (!success) {
        return res.status(422).json({ message: "Device is not connected" });
      }
      
      // Log the command
      await storage.createDeviceLog({
        deviceId: device.id,
        type: 'command',
        message: `Command: ${command.type}`,
        metadata: command
      });
      
      res.status(200).json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to send command to device" });
    }
  });
  
  return httpServer;
}
