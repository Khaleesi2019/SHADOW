import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useLocation } from 'wouter';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface SecretKeypadProps {
  adminCode: string;
  triggerElement?: React.ReactNode;
}

export function SecretKeypad({ adminCode, triggerElement }: SecretKeypadProps) {
  const [showKeypad, setShowKeypad] = useState(false);
  const [enteredCode, setEnteredCode] = useState('');
  const [countdown, setCountdown] = useState(3);
  const [showSuccess, setShowSuccess] = useState(false);
  const [_, setLocation] = useLocation();

  // Manejar la entrada de dígitos
  const handleDigitPress = (digit: number) => {
    const newCode = enteredCode + digit.toString();
    setEnteredCode(newCode);
    
    // Verificar si el código es correcto
    if (newCode === adminCode) {
      setShowSuccess(true);
      // Iniciar cuenta regresiva para redirección
      setCountdown(3);
    }
    
    // Reiniciar si ya hay 6 dígitos y el código es incorrecto
    if (newCode.length >= 6 && newCode !== adminCode) {
      setEnteredCode('');
    }
  };
  
  // Borrar último dígito
  const handleBackspace = () => {
    setEnteredCode(prev => prev.slice(0, -1));
  };
  
  // Autenticación y redirección después de código correcto
  useEffect(() => {
    let timer: number;
    if (showSuccess) {
      // Importar dinámicamente para evitar ciclos de dependencia
      import('./AdminAuth').then(({ useAdminAuth }) => {
        const { authenticateWithCode } = useAdminAuth();
        
        timer = window.setInterval(() => {
          setCountdown(prev => {
            const newCount = prev - 1;
            if (newCount <= 0) {
              clearInterval(timer);
              setTimeout(async () => {
                setShowKeypad(false);
                setShowSuccess(false);
                
                // Autenticar directamente como administrador
                await authenticateWithCode();
                setLocation('/');
                
              }, 500);
            }
            return newCount;
          });
        }, 1000);
      });
    }
    
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [showSuccess, setLocation]);

  // Elemento invisible que activará el teclado al hacer clic
  const defaultTrigger = (
    <div 
      className="fixed bottom-2 right-2 w-4 h-4 cursor-pointer z-10 opacity-0 hover:opacity-20"
      onClick={() => setShowKeypad(true)}
    />
  );
  
  return (
    <>
      {triggerElement || defaultTrigger}
      
      <Dialog open={showKeypad} onOpenChange={setShowKeypad}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {showSuccess 
                ? "Acceso Concedido" 
                : "Ingrese código de administrador"}
            </DialogTitle>
          </DialogHeader>
          
          {showSuccess ? (
            <div className="flex flex-col items-center py-4">
              <div className="text-xl font-bold text-green-600 mb-2">Redireccionando en {countdown}...</div>
              <p className="text-sm text-muted-foreground">
                Accediendo al panel de administración
              </p>
            </div>
          ) : (
            <div className="py-4">
              {/* Pantalla donde se muestra el código */}
              <div className="flex justify-center mb-4">
                <div className="bg-neutral-100 rounded-md p-3 w-44 text-center">
                  <span className="font-mono text-2xl tracking-widest">
                    {enteredCode.split('').map((_, i) => '•').join('')}
                  </span>
                </div>
              </div>
              
              {/* Teclado numérico */}
              <div className="grid grid-cols-3 gap-2 max-w-xs mx-auto">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(digit => (
                  <Button
                    key={digit}
                    variant="outline"
                    className="h-12 text-xl"
                    onClick={() => handleDigitPress(digit)}
                  >
                    {digit}
                  </Button>
                ))}
                {/* Última fila */}
                <Button
                  variant="outline"
                  className="h-12"
                  onClick={handleBackspace}
                >
                  ←
                </Button>
                <Button
                  variant="outline"
                  className="h-12 text-xl"
                  onClick={() => handleDigitPress(0)}
                >
                  0
                </Button>
                <Button
                  variant="default"
                  className="h-12"
                  onClick={() => setShowKeypad(false)}
                >
                  X
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}