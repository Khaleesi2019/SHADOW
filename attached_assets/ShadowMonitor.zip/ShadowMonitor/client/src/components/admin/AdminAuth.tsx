import { useState } from 'react';
import { useLocation } from 'wouter';
import { queryClient } from "@/lib/queryClient";

/**
 * Componente para manejar la autenticación administrativa directa
 * sin tener que pasar por el flujo normal de autenticación
 */
export function useAdminAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [_, setLocation] = useLocation();

  // Función para autenticar por código de administrador
  const authenticateWithCode = async () => {
    setIsLoading(true);
    
    try {
      // Crear un usuario administrador temporal
      const adminUser = {
        id: 1,
        username: "admin",
        name: "Admin User",
        email: "admin@tattoomaster.com",
        role: "admin",
        createdAt: new Date()
      };
      
      // Establecer el usuario en la caché de react-query
      queryClient.setQueryData(["/api/user"], adminUser);
      
      // Actualizar estado de autenticación y redirigir
      setIsAuthenticated(true);
      setLocation('/');
      
      return true;
    } catch (error) {
      console.error("Error en autenticación directa:", error);
      return false;
    } finally {
      setIsLoading(false);
    }
  };
  
  return {
    isAuthenticated,
    isLoading,
    authenticateWithCode
  };
}