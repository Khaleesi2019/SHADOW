import { Bell, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface HeaderProps {
  title: string;
  onSearch?: (query: string) => void;
  searchPlaceholder?: string;
  notificationCount?: number;
}

export function Header({ 
  title, 
  onSearch, 
  searchPlaceholder = "Search devices...",
  notificationCount = 0 
}: HeaderProps) {
  return (
    <header className="bg-white border-b border-neutral-medium shadow-sm">
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center">
          <h1 className="text-lg font-medium text-neutral-darkest">{title}</h1>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="relative hidden sm:block">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral" />
            <Input 
              type="text" 
              placeholder={searchPlaceholder}
              className="pl-10 bg-neutral-light focus:bg-white w-full sm:w-48 md:w-64" 
              onChange={(e) => onSearch && onSearch(e.target.value)}
            />
          </div>
          
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5 text-neutral-dark" />
            {notificationCount > 0 && (
              <Badge 
                variant="destructive" 
                className="absolute -top-0.5 -right-0.5 flex items-center justify-center w-4 h-4 p-0 text-[10px]"
              >
                {notificationCount > 9 ? '9+' : notificationCount}
              </Badge>
            )}
          </Button>
        </div>
      </div>
    </header>
  );
}
