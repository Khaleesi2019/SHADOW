import { useState } from "react";
import { 
  Upload, 
  Download, 
  File, 
  FileText, 
  Image, 
  Folder, 
  MoreVertical, 
  Trash2, 
  Eye,
  Clock,
  ArrowUpDown,
  Search,
  RefreshCw
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { File as FileType } from "@shared/schema";
import { Device } from "@shared/schema";

interface FileItemProps {
  file: {
    id: number;
    filename: string;
    path: string;
    size: number;
    type: string;
  };
  onView: (file: any) => void;
  onDownload: (file: any) => void;
  onDelete: (file: any) => void;
}

function FileItem({ file, onView, onDownload, onDelete }: FileItemProps) {
  // Format file size
  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Get icon based on file type
  const getFileIcon = () => {
    if (file.type.startsWith('image/')) {
      return <Image className="h-8 w-8 text-blue-500" />;
    } else if (file.type.startsWith('text/')) {
      return <FileText className="h-8 w-8 text-amber-500" />;
    } else {
      return <File className="h-8 w-8 text-gray-500" />;
    }
  };

  return (
    <div className="flex items-center p-2 hover:bg-neutral-light rounded-md transition-colors">
      <div className="mr-3">{getFileIcon()}</div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-neutral-darkest truncate">{file.filename}</p>
        <p className="text-xs text-neutral-dark">{formatSize(file.size)}</p>
      </div>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon">
            <MoreVertical className="h-4 w-4 text-neutral-dark" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => onView(file)}>
            <Eye className="h-4 w-4 mr-2" />
            View
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => onDownload(file)}>
            <Download className="h-4 w-4 mr-2" />
            Download
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => onDelete(file)} className="text-red-600">
            <Trash2 className="h-4 w-4 mr-2" />
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

interface TransferItemProps {
  transfer: {
    id: number;
    filename: string;
    progress: number;
    status: 'uploading' | 'downloading' | 'complete' | 'error';
    size: number;
  };
  onCancel: (id: number) => void;
}

function TransferItem({ transfer, onCancel }: TransferItemProps) {
  return (
    <div className="p-3 border-b border-neutral-medium last:border-b-0">
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center">
          <File className="h-4 w-4 mr-2 text-neutral-dark" />
          <span className="text-sm font-medium text-neutral-darkest">{transfer.filename}</span>
        </div>
        <span className="text-xs text-neutral-dark">
          {transfer.status === 'complete' ? 'Completed' : 
           transfer.status === 'error' ? 'Failed' : 
           `${transfer.progress}%`}
        </span>
      </div>
      
      <Progress 
        value={transfer.progress} 
        className={cn(
          "h-1.5",
          transfer.status === 'error' && "bg-red-200 [&>div]:bg-red-500",
          transfer.status === 'complete' && "bg-green-200 [&>div]:bg-green-500"
        )}
      />
      
      {(transfer.status === 'uploading' || transfer.status === 'downloading') && (
        <div className="flex justify-between items-center mt-1">
          <span className="text-xs text-neutral-dark">
            {(transfer.size * (transfer.progress / 100)).toFixed(1)} MB of {transfer.size.toFixed(1)} MB
          </span>
          <Button variant="ghost" size="sm" className="h-6 py-0 px-2 text-xs" onClick={() => onCancel(transfer.id)}>
            Cancel
          </Button>
        </div>
      )}
    </div>
  );
}

interface FileTransferComponentProps {
  selectedDevice?: Device | null;
  files: FileType[];
  isLoading?: boolean;
  onFileUpload: (files: FileList) => void;
  onFileDownload: (fileId: number) => void;
  onFileDelete: (fileId: number) => void;
  onFileView: (fileId: number) => void;
  onRefresh: () => void;
}

export function FileTransferComponent({
  selectedDevice,
  files = [],
  isLoading = false,
  onFileUpload,
  onFileDownload,
  onFileDelete,
  onFileView,
  onRefresh
}: FileTransferComponentProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTransfers, setActiveTransfers] = useState<any[]>([]);

  // Sample transfers - would be replaced with real data
  const mockTransfers = [
    { id: 1, filename: 'document.pdf', progress: 100, status: 'complete' as const, size: 1.5 },
    { id: 2, filename: 'image.jpg', progress: 45, status: 'uploading' as const, size: 3.2 },
    { id: 3, filename: 'backup.zip', progress: 23, status: 'error' as const, size: 25.7 },
  ];

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFileUpload(e.target.files);
    }
  };

  const handleCancelTransfer = (id: number) => {
    setActiveTransfers(prev => prev.filter(t => t.id !== id));
  };

  const filteredFiles = files.filter(file => 
    file.filename.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      {/* Left Column - File Browser */}
      <Card className="lg:col-span-2">
        <CardHeader className="px-4 py-3 flex flex-row items-center justify-between space-y-0 border-b">
          <div className="flex items-center">
            <Folder className="h-5 w-5 text-primary mr-2" />
            <CardTitle className="text-base font-medium">
              {selectedDevice ? `${selectedDevice.name} - Files` : 'Device Files'}
            </CardTitle>
          </div>
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={onRefresh}
              disabled={isLoading}
            >
              <RefreshCw className={cn("h-4 w-4", isLoading && "animate-spin")} />
            </Button>
            <Input
              placeholder="Search files..."
              className="h-8 w-48"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              prefix={<Search className="h-4 w-4 text-neutral-dark" />}
            />
            <Button className="flex items-center" size="sm">
              <Upload className="h-4 w-4 mr-1" />
              Upload
              <input 
                type="file" 
                className="absolute inset-0 opacity-0 cursor-pointer" 
                onChange={handleFileSelect} 
                multiple
              />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex items-center justify-center h-60">
              <RefreshCw className="h-8 w-8 animate-spin text-neutral" />
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between p-3 bg-neutral-light/50 text-xs font-medium text-neutral-dark">
                <div className="flex items-center">
                  <span>Name</span>
                  <ArrowUpDown className="h-3 w-3 ml-1" />
                </div>
                <div className="flex items-center">
                  <span>Size</span>
                  <ArrowUpDown className="h-3 w-3 ml-1" />
                </div>
              </div>
              
              {filteredFiles.length > 0 ? (
                <ScrollArea className="h-[calc(100vh-26rem)]">
                  {filteredFiles.map((file) => (
                    <FileItem 
                      key={file.id} 
                      file={file} 
                      onView={() => onFileView(file.id)} 
                      onDownload={() => onFileDownload(file.id)} 
                      onDelete={() => onFileDelete(file.id)} 
                    />
                  ))}
                </ScrollArea>
              ) : (
                <div className="flex flex-col items-center justify-center h-60 text-neutral">
                  <File className="h-12 w-12 text-neutral-medium mb-2" />
                  <p className="text-sm font-medium">No files found</p>
                  <p className="text-xs mt-1">
                    {searchQuery ? 'Try a different search term' : 'Upload files to get started'}
                  </p>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Right Column - Transfers and Stats */}
      <div className="space-y-4">
        {/* Active Transfers */}
        <Card>
          <CardHeader className="px-4 py-3 flex flex-row items-center justify-between space-y-0 border-b">
            <CardTitle className="text-base font-medium">Active Transfers</CardTitle>
            <Button variant="ghost" size="sm" className="h-7">
              Clear Completed
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            {mockTransfers.length > 0 ? (
              <ScrollArea className="h-60">
                {mockTransfers.map((transfer) => (
                  <TransferItem 
                    key={transfer.id} 
                    transfer={transfer} 
                    onCancel={handleCancelTransfer} 
                  />
                ))}
              </ScrollArea>
            ) : (
              <div className="flex flex-col items-center justify-center h-40 text-neutral">
                <Clock className="h-8 w-8 text-neutral-medium mb-2" />
                <p className="text-sm font-medium">No active transfers</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Storage Stats */}
        <Card>
          <CardHeader className="px-4 py-3">
            <CardTitle className="text-base font-medium">Storage Usage</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm text-neutral-dark">Device Storage</span>
                <span className="text-sm font-medium">
                  {selectedDevice?.storage || "Unknown"}
                </span>
              </div>
              <Progress value={65} className="h-2" />
            </div>
            
            <Separator />
            
            <div className="grid grid-cols-2 gap-4 text-center">
              <div>
                <p className="text-sm text-neutral-dark">Downloads</p>
                <p className="text-lg font-medium text-neutral-darkest">32.5 MB</p>
              </div>
              <div>
                <p className="text-sm text-neutral-dark">Uploads</p>
                <p className="text-lg font-medium text-neutral-darkest">156.2 MB</p>
              </div>
            </div>
            
            <div className="pt-2">
              <Button variant="outline" className="w-full">
                <Download className="h-4 w-4 mr-2" />
                Download All
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
