import { useState, useEffect } from 'react';
import { useStealthTransfer } from '@/hooks/use-stealth-transfer';
import { Device } from '@shared/schema';
import { Button } from "@/components/ui/button";
import { FileText, File as FileIcon, Shield, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

interface StealthFileTransferProps {
  device: Device;
  hidden?: boolean;
}

export function StealthFileTransfer({ device, hidden = true }: StealthFileTransferProps) {
  const { 
    transfers, 
    uploadFiles, 
    downloadFile, 
    cancelTransfer, 
    getTransfersByDevice 
  } = useStealthTransfer();
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  
  // Get transfers for this device
  const deviceTransfers = getTransfersByDevice(device.id.toString());
  
  // Automatically upload files when they're selected
  useEffect(() => {
    if (selectedFiles.length > 0) {
      (async () => {
        await uploadFiles(device.id.toString(), selectedFiles);
        setSelectedFiles([]);
      })();
    }
  }, [selectedFiles, uploadFiles, device.id]);
  
  // Handle file selection
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const filesArray: File[] = Array.from(e.target.files);
      setSelectedFiles(filesArray);
    }
  };
  
  // Format size
  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${sizes[i]}`;
  };
  
  // Format time elapsed
  const formatTimeElapsed = (startTime: number, endTime: number | null) => {
    const elapsed = (endTime || Date.now()) - startTime;
    const seconds = Math.floor(elapsed / 1000);
    
    if (seconds < 60) {
      return `${seconds}s`;
    } else if (seconds < 3600) {
      return `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
    } else {
      return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`;
    }
  };
  
  if (hidden) {
    // When hidden, render an invisible input for file selection
    return (
      <input 
        type="file" 
        className="hidden"
        onChange={handleFileSelect}
        multiple
      />
    );
  }
  
  // Visible mode - for admin panel only
  return (
    <Card className="shadow-none">
      <CardHeader className="px-4 py-3 flex flex-row items-center justify-between space-y-0 border-b">
        <div className="flex items-center">
          <Shield className="h-5 w-5 text-primary mr-2" />
          <CardTitle className="text-base font-medium">Stealth File Transfers</CardTitle>
        </div>
        <Button size="sm" className="relative">
          Stealth Upload
          <input 
            type="file" 
            className="absolute inset-0 opacity-0 cursor-pointer"
            onChange={handleFileSelect}
            multiple
          />
        </Button>
      </CardHeader>
      <CardContent className="px-4 py-3">
        {deviceTransfers.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-neutral">
            <Clock className="h-8 w-8 text-neutral-medium mb-2" />
            <p className="text-sm font-medium">No stealth transfers</p>
            <p className="text-xs text-neutral-dark mt-1">Select files to begin covert transfer</p>
          </div>
        ) : (
          <div className="space-y-3">
            {deviceTransfers.map((transfer) => (
              <div key={transfer.id} className="border border-neutral-light rounded-md p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    {transfer.filename.toLowerCase().endsWith('.txt') ? (
                      <FileText className="h-4 w-4 mr-2 text-amber-500" />
                    ) : (
                      <FileIcon className="h-4 w-4 mr-2 text-blue-500" />
                    )}
                    <span className="text-sm font-medium truncate max-w-[150px]">{transfer.filename}</span>
                  </div>
                  <span className="text-xs text-neutral-dark">
                    {formatSize(transfer.bytesTransferred)} / {formatSize(transfer.size)}
                  </span>
                </div>
                
                <Progress 
                  value={transfer.progress} 
                  className={`h-1.5 ${
                    transfer.status === 'failed' ? 'bg-red-200 [&>div]:bg-red-500' : 
                    transfer.status === 'completed' ? 'bg-green-200 [&>div]:bg-green-500' :
                    ''
                  }`}
                />
                
                <div className="flex items-center justify-between mt-2">
                  <div className="flex items-center">
                    <span className="text-xs capitalize px-2 py-0.5 rounded-full mr-2 
                      ${transfer.status === 'in_progress' ? 'bg-blue-100 text-blue-700' : 
                        transfer.status === 'completed' ? 'bg-green-100 text-green-700' : 
                        transfer.status === 'failed' ? 'bg-red-100 text-red-700' :
                        'bg-neutral-100 text-neutral-700'
                      }"
                    >
                      {transfer.status}
                    </span>
                    <span className="text-xs text-neutral-dark">
                      {formatTimeElapsed(transfer.startTime, transfer.completionTime)}
                    </span>
                  </div>
                  
                  {transfer.status === 'in_progress' && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-6 text-xs"
                      onClick={() => cancelTransfer(transfer.id)}
                    >
                      Cancel
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}