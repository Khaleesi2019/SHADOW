import { useState } from "react";
import { useLocation } from "wouter";
import { 
  Smartphone, 
  User, 
  Eye, 
  Folder, 
  MapPin, 
  MoreHorizontal,
  AlertTriangle,
  BatteryCharging,
  Battery,
  BatteryLow,
  BatteryWarning,
  BatteryFull,
  BatteryMedium,
  Clock
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Device } from "@shared/schema";
import { cn } from "@/lib/utils";

interface DeviceCardProps {
  device: Device;
  onMonitorClick?: (device: Device) => void;
  onFilesClick?: (device: Device) => void;
  onLocationClick?: (device: Device) => void;
  onMoreClick?: (device: Device) => void;
}

export function DeviceCard({
  device,
  onMonitorClick,
  onFilesClick,
  onLocationClick,
  onMoreClick
}: DeviceCardProps) {
  const [, setLocation] = useLocation();

  // Format time for last active
  const formatLastActive = (date: Date | undefined) => {
    if (!date) return "Unknown";
    
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / 1000); // seconds
    
    if (diff < 60) return "Just now";
    if (diff < 3600) return `${Math.floor(diff / 60)} min ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} hours ago`;
    return `${Math.floor(diff / 86400)} days ago`;
  };

  // Battery icon based on level
  const getBatteryIcon = (level: number | undefined, status: string | undefined) => {
    if (!level) return <BatteryWarning className="h-4 w-4 text-neutral-dark" />;
    
    if (status === "charging") return <BatteryCharging className="h-4 w-4 text-green-500" />;
    
    if (level < 20) return <BatteryLow className="h-4 w-4 text-red-500" />;
    if (level < 50) return <Battery className="h-4 w-4 text-orange-500" />;
    if (level < 80) return <BatteryMedium className="h-4 w-4 text-green-500" />;
    return <BatteryFull className="h-4 w-4 text-green-500" />;
  };

  // Status indicator
  const getStatusIndicator = () => {
    switch (device.status) {
      case "online":
        return (
          <div className="flex items-center">
            <span className="inline-block w-2 h-2 rounded-full bg-green-500 mr-2"></span>
            <span className="text-sm text-green-600">Online</span>
          </div>
        );
      case "alert":
        return (
          <div className="flex items-center">
            <span className="inline-block w-2 h-2 rounded-full bg-red-500 mr-2"></span>
            <span className="text-sm text-red-600">Alert</span>
          </div>
        );
      default:
        return (
          <div className="flex items-center">
            <span className="inline-block w-2 h-2 rounded-full bg-neutral-dark mr-2"></span>
            <span className="text-sm text-neutral-dark">Offline</span>
          </div>
        );
    }
  };

  const handleCardClick = (e: React.MouseEvent) => {
    // Only navigate if not clicking a button
    if (!(e.target as HTMLElement).closest('button')) {
      setLocation(`/device/${device.id}`);
    }
  };

  return (
    <Card 
      className={cn(
        "transition-all hover:shadow-md hover:-translate-y-1 cursor-pointer",
        device.status === "alert" ? "border-red-300" : "border-neutral-medium"
      )}
      onClick={handleCardClick}
    >
      <CardHeader className="p-4 border-b border-neutral-medium space-y-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Smartphone className="mr-2 h-5 w-5 text-primary" />
            <h3 className="font-medium text-neutral-darkest">{device.name}</h3>
          </div>
          {getStatusIndicator()}
        </div>
        <div className="mt-3 flex items-center text-sm text-neutral-dark">
          <User className="mr-1 h-4 w-4" />
          <span>{device.userId} - {device.department}</span>
        </div>
        
        {/* Alert message if present */}
        {device.status === "alert" && device.alertMessage && (
          <div className="mt-2 p-2 bg-red-50 text-red-700 text-xs rounded flex items-center">
            <AlertTriangle className="mr-1 h-4 w-4 text-red-600" />
            {device.alertMessage}
          </div>
        )}
      </CardHeader>
      
      <div className="grid grid-cols-2 text-center border-b border-neutral-medium divide-x divide-neutral-medium">
        <div className="p-3">
          <p className="text-xs text-neutral">Last Active</p>
          <div className="flex items-center justify-center">
            <Clock className="mr-1 h-4 w-4 text-neutral-dark" />
            <p className="text-sm font-medium text-neutral-darkest">
              {formatLastActive(device.lastActive ? new Date(device.lastActive) : undefined)}
            </p>
          </div>
        </div>
        <div className="p-3">
          <p className="text-xs text-neutral">Battery</p>
          <div className="flex items-center justify-center">
            {getBatteryIcon(device.batteryLevel, device.batteryStatus)}
            <p className="text-sm font-medium text-neutral-darkest ml-1">
              {device.batteryLevel !== null && device.batteryLevel !== undefined 
                ? `${device.batteryLevel}%` 
                : "Unknown"}
            </p>
          </div>
        </div>
      </div>
      
      <CardFooter className="p-3 grid grid-cols-4 gap-1">
        <Button 
          variant="ghost" 
          size="sm" 
          className="flex flex-col items-center justify-center h-auto py-2"
          onClick={(e) => {
            e.stopPropagation();
            if (device.status !== "offline" && onMonitorClick) onMonitorClick(device);
          }}
          disabled={device.status === "offline"}
        >
          <Eye className={cn(
            "h-5 w-5 mb-1",
            device.status === "offline" ? "text-neutral-dark" : "text-primary"
          )} />
          <span className="text-xs text-neutral-dark">Monitor</span>
        </Button>
        
        <Button 
          variant="ghost" 
          size="sm" 
          className="flex flex-col items-center justify-center h-auto py-2"
          onClick={(e) => {
            e.stopPropagation();
            if (device.status !== "offline" && onFilesClick) onFilesClick(device);
          }}
          disabled={device.status === "offline"}
        >
          <Folder className={cn(
            "h-5 w-5 mb-1",
            device.status === "offline" ? "text-neutral-dark" : "text-primary"
          )} />
          <span className="text-xs text-neutral-dark">Files</span>
        </Button>
        
        <Button 
          variant="ghost" 
          size="sm" 
          className="flex flex-col items-center justify-center h-auto py-2"
          onClick={(e) => {
            e.stopPropagation();
            if (device.status !== "offline" && onLocationClick) onLocationClick(device);
          }}
          disabled={device.status === "offline"}
        >
          <MapPin className={cn(
            "h-5 w-5 mb-1",
            device.status === "offline" ? "text-neutral-dark" : "text-primary"
          )} />
          <span className="text-xs text-neutral-dark">Location</span>
        </Button>
        
        <Button 
          variant="ghost" 
          size="sm" 
          className="flex flex-col items-center justify-center h-auto py-2"
          onClick={(e) => {
            e.stopPropagation();
            if (onMoreClick) onMoreClick(device);
          }}
        >
          <MoreHorizontal className="h-5 w-5 mb-1 text-primary" />
          <span className="text-xs text-neutral-dark">More</span>
        </Button>
      </CardFooter>
    </Card>
  );
}
