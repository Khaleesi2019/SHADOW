import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Shield, Smartphone, BarChart, Folder, MapPin, Activity, Settings, LogOut, Menu, X } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  
  // Close sidebar on mobile when location changes
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const navItems = [
    { href: "/", label: "Dashboard", icon: <BarChart className="mr-3 h-5 w-5" /> },
    { href: "/devices", label: "Devices", icon: <Smartphone className="mr-3 h-5 w-5" /> },
    { href: "/monitoring", label: "Monitoring", icon: <Activity className="mr-3 h-5 w-5" /> },
    { href: "/files", label: "File Transfer", icon: <Folder className="mr-3 h-5 w-5" /> },
    { href: "/location", label: "Location", icon: <MapPin className="mr-3 h-5 w-5" /> },
    { href: "/reports", label: "Reports", icon: <BarChart className="mr-3 h-5 w-5" /> },
    { href: "/settings", label: "Settings", icon: <Settings className="mr-3 h-5 w-5" /> },
  ];

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
  };

  // Create initials for avatar
  const initials = user?.username ? user.username.substring(0, 2).toUpperCase() : "??";

  return (
    <>
      {/* Mobile Menu Button */}
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setIsOpen(true)}
        className="md:hidden fixed top-4 left-4 z-40"
      >
        <Menu className="h-5 w-5" />
      </Button>

      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={cn(
        "flex flex-col w-64 bg-white border-r border-neutral-medium shadow-sm h-full",
        "transition-all duration-300 ease-in-out z-50",
        "fixed md:static top-0 left-0",
        isOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0",
      )}>
        <div className="flex items-center justify-between p-4 border-b border-neutral-medium">
          <div className="flex items-center space-x-2">
            <Shield className="h-5 w-5 text-primary" />
            <h1 className="text-lg font-medium text-neutral-darkest">SecureMonitor</h1>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            className="md:hidden"
            onClick={() => setIsOpen(false)}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="overflow-y-auto flex-grow">
          <nav className="p-2">
            <ul>
              {navItems.map((item) => (
                <li key={item.href} className="mb-1">
                  <Link href={item.href}>
                    <a className={cn(
                      "flex items-center p-3 rounded-lg text-neutral-darkest hover:bg-neutral-light group transition-all",
                      location === item.href && "bg-primary-light/10 text-primary"
                    )}>
                      {item.icon}
                      <span>{item.label}</span>
                    </a>
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </div>
        
        <div className="p-4 border-t border-neutral-medium">
          <div className="flex items-center">
            <Avatar>
              <AvatarFallback className="bg-primary text-white">{initials}</AvatarFallback>
            </Avatar>
            <div className="ml-3">
              <p className="text-sm font-medium text-neutral-darkest">{user?.username || "User"}</p>
              <p className="text-xs text-neutral-dark">{user?.email || "admin@company.com"}</p>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              className="ml-auto"
              onClick={handleLogout}
              disabled={logoutMutation.isPending}
            >
              <LogOut className="h-5 w-5 text-neutral-dark" />
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
