import { useState } from "react";
import { useLocation } from "wouter";
import { 
  X, 
  Smartphone, 
  User, 
  Check, 
  Info,
  RefreshCw,
  Maximize2,
  VideoIcon,
  LockIcon,
  ClockIcon,
  PanelLeftClose,
  ArrowLeft
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Device } from "@shared/schema";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";

interface DeviceDetailsProps {
  device: Device | null;
  isOpen: boolean;
  onClose: () => void;
  onTakeControl: (device: Device) => void;
  onLockDevice: (device: Device) => void;
  onRefreshScreen: () => void;
  isLoading?: boolean;
}

export function DeviceDetails({
  device,
  isOpen,
  onClose,
  onTakeControl,
  onLockDevice,
  onRefreshScreen,
  isLoading = false
}: DeviceDetailsProps) {
  const [, setLocation] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState("screen");

  // We can't render if we don't have a device
  if (!device) return null;

  // Get user initials from the userId for the avatar
  const getUserInitials = (userId: string) => {
    return userId.split(' ').map(name => name[0]).join('').substr(0, 2).toUpperCase();
  };

  // Format date for better readability
  const formatDate = (dateString?: string | Date) => {
    if (!dateString) return "Unknown";
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online": return "text-green-500";
      case "alert": return "text-red-500";
      default: return "text-neutral-dark";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "online": return <Check className="h-4 w-4 text-green-500" />;
      case "alert": return <Info className="h-4 w-4 text-red-500" />;
      default: return <Info className="h-4 w-4 text-neutral-dark" />;
    }
  };

  // Calculate storage percentage if available
  const getStoragePercentage = () => {
    if (!device.storage) return 0;
    
    try {
      const [used, total] = device.storage.split('/').map(part => 
        parseFloat(part.trim().replace('GB', ''))
      );
      return (used / total) * 100;
    } catch (e) {
      return 0;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-5xl h-[90vh] p-0 flex flex-col" onInteractOutside={(e) => e.preventDefault()}>
        <DialogHeader className="p-4 border-b border-neutral-medium flex-row items-center justify-between space-y-0">
          <div className="flex items-center">
            <Smartphone className="h-5 w-5 text-primary mr-2" />
            <DialogTitle className="text-lg font-medium text-neutral-darkest">
              {device.name}
            </DialogTitle>
            <Badge 
              variant="outline" 
              className={cn(
                "ml-3 flex items-center gap-1",
                getStatusColor(device.status || "offline")
              )}
            >
              {getStatusIcon(device.status || "offline")}
              <span className={getStatusColor(device.status || "offline")}>
                {device.status === "online" ? "Online" : device.status === "alert" ? "Alert" : "Offline"}
              </span>
            </Badge>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </DialogHeader>

        <div className="flex flex-1 overflow-hidden">
          {/* Device Info Sidebar */}
          <div 
            className={cn(
              "bg-neutral-lightest border-r border-neutral-medium transition-all ease-in-out duration-300",
              sidebarOpen ? "w-64" : "w-0 overflow-hidden"
            )}
          >
            {sidebarOpen && (
              <ScrollArea className="h-full p-4">
                {/* Device User */}
                <div className="mb-4">
                  <p className="text-sm text-neutral mb-1">Device User</p>
                  <div className="flex items-center">
                    <Avatar>
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {getUserInitials(device.userId || "User")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="ml-2">
                      <p className="text-sm font-medium text-neutral-darkest">{device.userId}</p>
                      <p className="text-xs text-neutral-dark">{device.department}</p>
                    </div>
                  </div>
                </div>

                {/* Device Info */}
                <div className="mb-4">
                  <p className="text-sm text-neutral mb-1">Device Info</p>
                  <div className="text-sm space-y-1">
                    <div className="flex justify-between">
                      <span className="text-neutral-dark">Model:</span>
                      <span className="text-neutral-darkest">{device.model}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-dark">OS:</span>
                      <span className="text-neutral-darkest">{`${device.os} ${device.osVersion || ''}`}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-dark">IMEI:</span>
                      <span className="text-neutral-darkest">{device.identifier}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-dark">IP Address:</span>
                      <span className="text-neutral-darkest">{device.ipAddress || 'Unknown'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-dark">Last Active:</span>
                      <span className="text-neutral-darkest">{formatDate(device.lastActive)}</span>
                    </div>
                    
                    {/* Storage with progress bar */}
                    {device.storage && (
                      <div className="space-y-1">
                        <div className="flex justify-between">
                          <span className="text-neutral-dark">Storage:</span>
                          <span className="text-neutral-darkest">{device.storage}</span>
                        </div>
                        <Progress value={getStoragePercentage()} className="h-2" />
                      </div>
                    )}
                    
                    <div className="flex justify-between items-center">
                      <span className="text-neutral-dark">Battery:</span>
                      <div className="flex items-center">
                        {device.batteryStatus === "charging" ? (
                          <span className="inline-block w-2 h-2 rounded-full bg-green-500 mr-2"></span>
                        ) : null}
                        <span className="text-neutral-darkest">
                          {device.batteryLevel !== null && device.batteryLevel !== undefined 
                            ? `${device.batteryLevel}%` 
                            : "Unknown"}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Status Checks */}
                <div className="mb-4">
                  <p className="text-sm text-neutral mb-1">Status</p>
                  <div className="text-sm space-y-1">
                    <div className="flex items-center">
                      <Check className={cn(
                        "h-4 w-4 mr-1",
                        device.status === "online" ? "text-green-500" : "text-neutral-dark"
                      )} />
                      <span className="text-neutral-darkest">Device monitoring active</span>
                    </div>
                    <div className="flex items-center">
                      <Check className={cn(
                        "h-4 w-4 mr-1",
                        device.locationEnabled ? "text-green-500" : "text-neutral-dark"
                      )} />
                      <span className="text-neutral-darkest">Location services enabled</span>
                    </div>
                    <div className="flex items-center">
                      <Check className={cn(
                        "h-4 w-4 mr-1",
                        device.isMonitored ? "text-green-500" : "text-neutral-dark"
                      )} />
                      <span className="text-neutral-darkest">Background service running</span>
                    </div>
                    {device.alertStatus && (
                      <div className="flex items-center">
                        <Info className="h-4 w-4 mr-1 text-orange-500" />
                        <span className="text-neutral-darkest">{device.alertStatus}</span>
                      </div>
                    )}
                  </div>
                </div>
              </ScrollArea>
            )}
          </div>

          {/* Main Content Area */}
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Tabs */}
            <div className="border-b border-neutral-medium">
              <div className="flex items-center">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => setSidebarOpen(!sidebarOpen)} 
                  className="ml-2"
                >
                  <PanelLeftClose className={cn(
                    "h-4 w-4 transition-transform",
                    !sidebarOpen && "rotate-180"
                  )} />
                </Button>
                <Tabs 
                  defaultValue="screen" 
                  value={activeTab} 
                  onValueChange={setActiveTab}
                  className="flex-1"
                >
                  <TabsList className="bg-transparent border-b-0 px-2">
                    <TabsTrigger value="screen" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none rounded-none">
                      Screen
                    </TabsTrigger>
                    <TabsTrigger value="files" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none rounded-none">
                      Files
                    </TabsTrigger>
                    <TabsTrigger value="apps" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none rounded-none">
                      Apps
                    </TabsTrigger>
                    <TabsTrigger value="location" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none rounded-none">
                      Location
                    </TabsTrigger>
                    <TabsTrigger value="logs" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none rounded-none">
                      Logs
                    </TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </div>

            {/* Tab Content */}
            <div className="flex-1 overflow-hidden">
              <TabsContent value="screen" className="h-full m-0 p-4 flex flex-col items-center justify-center bg-neutral-darkest">
                {/* Screen Mockup */}
                <div className="relative max-w-[300px] mx-auto">
                  <div className="w-[300px] h-[600px] bg-black rounded-[36px] p-3 shadow-xl relative overflow-hidden">
                    <div className="absolute top-0 left-0 right-0 h-10 bg-black rounded-t-[36px] flex justify-center items-end pb-1">
                      <div className="w-32 h-6 bg-black rounded-b-xl"></div>
                    </div>
                    
                    {/* Phone screen content */}
                    <div className="w-full h-full rounded-[30px] bg-white overflow-hidden relative">
                      {isLoading ? (
                        <div className="flex items-center justify-center h-full bg-neutral-light">
                          <RefreshCw className="h-8 w-8 animate-spin text-primary" />
                        </div>
                      ) : (
                        <>
                          {/* Header */}
                          <div className="h-12 bg-primary flex items-center px-4 text-white">
                            <ArrowLeft className="h-5 w-5 mr-2" />
                            <div className="flex items-center">
                              <Avatar className="h-8 w-8 mr-2">
                                <AvatarFallback className="bg-white text-primary text-sm">JD</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="text-sm font-medium">John Doe</p>
                                <p className="text-xs opacity-80">Online</p>
                              </div>
                            </div>
                          </div>
                          
                          {/* Chat content */}
                          <div className="p-4 bg-gray-100 h-[calc(100%-12rem)]">
                            <div className="mb-4 flex justify-start">
                              <div className="bg-white p-3 rounded-lg rounded-tl-none max-w-[80%] shadow-sm">
                                <p className="text-sm">Hey, I need the presentation for tomorrow's meeting.</p>
                                <p className="text-xs text-neutral-dark text-right">10:42 AM</p>
                              </div>
                            </div>
                            
                            <div className="mb-4 flex justify-end">
                              <div className="bg-primary p-3 rounded-lg rounded-tr-none max-w-[80%] shadow-sm text-white">
                                <p className="text-sm">I'm working on it, will send it in an hour.</p>
                                <p className="text-xs opacity-80 text-right">10:45 AM</p>
                              </div>
                            </div>
                            
                            <div className="mb-4 flex justify-start">
                              <div className="bg-white p-3 rounded-lg rounded-tl-none max-w-[80%] shadow-sm">
                                <p className="text-sm">Great, thanks! Also, did you finish the sales report?</p>
                                <p className="text-xs text-neutral-dark text-right">10:47 AM</p>
                              </div>
                            </div>
                            
                            <div className="mb-4 flex justify-end">
                              <div className="bg-primary p-3 rounded-lg rounded-tr-none max-w-[80%] shadow-sm text-white">
                                <p className="text-sm">Yes, it's ready. I'll include it with the presentation.</p>
                                <p className="text-xs opacity-80 text-right">10:49 AM</p>
                              </div>
                            </div>
                          </div>
                          
                          {/* Chat input */}
                          <div className="absolute bottom-0 left-0 right-0 bg-white p-3 border-t border-neutral-medium">
                            <div className="flex items-center">
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <Plus className="h-5 w-5 text-neutral" />
                              </Button>
                              <Input
                                placeholder="Type a message"
                                className="mx-2 bg-neutral-light rounded-full text-sm"
                              />
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <SendIcon className="h-5 w-5 text-primary" />
                              </Button>
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="mt-4 flex gap-4 justify-center">
                  <Button
                    variant="default"
                    size="sm"
                    onClick={onRefreshScreen}
                    className="flex items-center"
                    disabled={isLoading}
                  >
                    <RefreshCw className={cn("h-4 w-4 mr-1", isLoading && "animate-spin")} />
                    Refresh
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex items-center"
                  >
                    <Maximize2 className="h-4 w-4 mr-1" />
                    Fullscreen
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex items-center"
                  >
                    <VideoIcon className="h-4 w-4 mr-1" />
                    Record
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="files" className="h-full m-0 p-4 overflow-auto">
                <div className="text-center text-neutral-dark py-12">
                  <FolderIcon className="h-16 w-16 mx-auto text-neutral-medium" />
                  <h3 className="mt-4 text-lg font-medium">File Manager</h3>
                  <p className="mt-2">Connect to this device to browse files</p>
                  <Button className="mt-4">Connect to Device</Button>
                </div>
              </TabsContent>

              <TabsContent value="apps" className="h-full m-0 p-4 overflow-auto">
                <div className="text-center text-neutral-dark py-12">
                  <LayoutGridIcon className="h-16 w-16 mx-auto text-neutral-medium" />
                  <h3 className="mt-4 text-lg font-medium">App Usage</h3>
                  <p className="mt-2">Connect to this device to view app usage</p>
                  <Button className="mt-4">Connect to Device</Button>
                </div>
              </TabsContent>

              <TabsContent value="location" className="h-full m-0 p-4 overflow-auto">
                <div className="text-center text-neutral-dark py-12">
                  <MapPinIcon className="h-16 w-16 mx-auto text-neutral-medium" />
                  <h3 className="mt-4 text-lg font-medium">Location Tracking</h3>
                  <p className="mt-2">Connect to this device to view location</p>
                  <Button className="mt-4">Connect to Device</Button>
                </div>
              </TabsContent>

              <TabsContent value="logs" className="h-full m-0 p-4 overflow-auto">
                <div className="text-center text-neutral-dark py-12">
                  <ClipboardList className="h-16 w-16 mx-auto text-neutral-medium" />
                  <h3 className="mt-4 text-lg font-medium">Activity Logs</h3>
                  <p className="mt-2">Connect to this device to view logs</p>
                  <Button className="mt-4">Connect to Device</Button>
                </div>
              </TabsContent>
            </div>
          </div>
        </div>

        <DialogFooter className="p-4 border-t border-neutral-medium">
          <div className="flex justify-between w-full">
            <Button
              variant="outline"
              className="text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700"
              onClick={() => onLockDevice(device)}
            >
              <LockIcon className="h-4 w-4 mr-1" />
              Lock Device
            </Button>
            
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setLocation(`/device/${device.id}`)}
              >
                <ClockIcon className="h-4 w-4 mr-1" />
                History
              </Button>
              <Button
                variant="default"
                onClick={() => onTakeControl(device)}
                disabled={device.status !== "online"}
              >
                <MousePointerClick className="h-4 w-4 mr-1" />
                Take Control
              </Button>
            </div>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Import icons that aren't from lucide-react
function Plus({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M12 5v14M5 12h14" />
    </svg>
  );
}

function SendIcon({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="m22 2-7 20-4-9-9-4Z" />
      <path d="M22 2 11 13" />
    </svg>
  );
}

function FolderIcon({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z" />
    </svg>
  );
}

function LayoutGridIcon({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <rect width="7" height="7" x="3" y="3" rx="1" />
      <rect width="7" height="7" x="14" y="3" rx="1" />
      <rect width="7" height="7" x="14" y="14" rx="1" />
      <rect width="7" height="7" x="3" y="14" rx="1" />
    </svg>
  );
}

function MapPinIcon({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}

function ClipboardList({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <rect width="8" height="4" x="8" y="2" rx="1" ry="1" />
      <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" />
      <path d="M12 11h4" />
      <path d="M12 16h4" />
      <path d="M8 11h.01" />
      <path d="M8 16h.01" />
    </svg>
  );
}

function MousePointerClick({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="m9 9 5 12 1.8-5.2L21 14Z" />
      <path d="M7.2 2.2 8 5.1" />
      <path d="m5.1 8-2.9-.8" />
      <path d="M14 4.1 12 6" />
      <path d="m6 12-1.9 2" />
    </svg>
  );
}

function Input({ className, ...props }: React.InputHTMLAttributes<HTMLInputElement> & { className?: string }) {
  return (
    <input
      className={cn(
        "flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors",
        "file:border-0 file:bg-transparent file:text-sm file:font-medium",
        "placeholder:text-muted-foreground",
        "focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring",
        "disabled:cursor-not-allowed disabled:opacity-50",
        className
      )}
      {...props}
    />
  );
}
