import { useState } from "react";
import { Filter, CheckCircle, BatteryLow, AlertTriangle, Grid, List } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export type DeviceFilterValue = "all" | "online" | "offline" | "alert";
export type DeviceViewMode = "grid" | "list";
export type DeviceSortOption = "lastActive" | "name" | "status" | "type";

interface DeviceFiltersProps {
  onFilterChange: (value: DeviceFilterValue) => void;
  onViewModeChange: (mode: DeviceViewMode) => void;
  onSortChange: (sortBy: DeviceSortOption) => void;
  activeFilter: DeviceFilterValue;
  viewMode: DeviceViewMode;
  sortBy: DeviceSortOption;
}

export function DeviceFilters({
  onFilterChange,
  onViewModeChange,
  onSortChange,
  activeFilter = "all",
  viewMode = "grid",
  sortBy = "lastActive"
}: DeviceFiltersProps) {
  const handleSortChange = (value: string) => {
    onSortChange(value as DeviceSortOption);
  };

  return (
    <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
      <div className="flex flex-wrap items-center gap-2">
        <Button
          variant={activeFilter === "all" ? "default" : "outline"}
          size="sm"
          onClick={() => onFilterChange("all")}
          className="flex items-center gap-1"
        >
          <Filter className="h-4 w-4" />
          All Devices
        </Button>
        
        <Button
          variant={activeFilter === "online" ? "default" : "outline"}
          size="sm"
          onClick={() => onFilterChange("online")}
          className="flex items-center gap-1"
        >
          <CheckCircle className="h-4 w-4 text-green-500" />
          Online
        </Button>
        
        <Button
          variant={activeFilter === "offline" ? "default" : "outline"}
          size="sm"
          onClick={() => onFilterChange("offline")}
          className="flex items-center gap-1"
        >
          <BatteryLow className="h-4 w-4 text-neutral" />
          Offline
        </Button>
        
        <Button
          variant={activeFilter === "alert" ? "default" : "outline"}
          size="sm"
          onClick={() => onFilterChange("alert")}
          className="flex items-center gap-1"
        >
          <AlertTriangle className="h-4 w-4 text-red-500" />
          Alerts
        </Button>
      </div>
      
      <div className="flex items-center gap-2">
        <Select value={sortBy} onValueChange={handleSortChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="lastActive">Sort by: Last Active</SelectItem>
            <SelectItem value="name">Sort by: Name</SelectItem>
            <SelectItem value="status">Sort by: Status</SelectItem>
            <SelectItem value="type">Sort by: Device Type</SelectItem>
          </SelectContent>
        </Select>
        
        <Button
          variant={viewMode === "grid" ? "secondary" : "outline"}
          size="icon"
          onClick={() => onViewModeChange("grid")}
        >
          <Grid className="h-4 w-4" />
        </Button>
        
        <Button
          variant={viewMode === "list" ? "secondary" : "outline"}
          size="icon"
          onClick={() => onViewModeChange("list")}
        >
          <List className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
