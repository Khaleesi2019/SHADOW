import { useState } from "react";
import { MapPin, Navigation, History, Search, RefreshCw, Home, Building, FileText } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Device, DeviceLocation } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

interface LocationPoint {
  id: number;
  deviceId: number;
  latitude: string;
  longitude: string;
  timestamp: Date;
  accuracy?: number;
}

interface LocationTrackerProps {
  devices: Device[];
  selectedDevice: Device | null;
  locations: DeviceLocation[];
  isLoading?: boolean;
  onDeviceSelect: (deviceId: string) => void;
  onRefresh: () => void;
  onTimeframeChange: (timeframe: string) => void;
}

export function LocationTracker({
  devices,
  selectedDevice,
  locations,
  isLoading = false,
  onDeviceSelect,
  onRefresh,
  onTimeframeChange
}: LocationTrackerProps) {
  const [selectedTimeframe, setSelectedTimeframe] = useState("today");
  const [searchQuery, setSearchQuery] = useState("");

  const handleTimeframeChange = (value: string) => {
    setSelectedTimeframe(value);
    onTimeframeChange(value);
  };

  const formatDate = (dateString: string | Date) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  // Filter devices based on search
  const filteredDevices = devices.filter(device =>
    device.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    device.userId.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Left sidebar - Device list */}
      <Card className="lg:col-span-1">
        <CardHeader className="p-4 space-y-3">
          <CardTitle className="text-lg font-medium flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary" />
            Devices
          </CardTitle>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral" />
            <Input
              placeholder="Search devices..."
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent className="px-2 py-0">
          <div className="max-h-[calc(100vh-22rem)] overflow-y-auto">
            {filteredDevices.map(device => (
              <Button
                key={device.id}
                variant="ghost"
                onClick={() => onDeviceSelect(device.id.toString())}
                className={cn(
                  "flex items-center justify-start w-full p-3 mb-1 text-left",
                  selectedDevice?.id === device.id && "bg-primary-light/10 text-primary"
                )}
              >
                <div className="mr-3 relative">
                  <Smartphone className="h-8 w-8 text-neutral-dark" />
                  <span 
                    className={cn(
                      "absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full",
                      device.status === "online" ? "bg-green-500" : 
                      device.status === "alert" ? "bg-red-500" : "bg-neutral-dark"
                    )}
                  ></span>
                </div>
                <div className="text-left">
                  <div className="font-medium text-sm text-neutral-darkest">
                    {device.name}
                  </div>
                  <div className="text-xs text-neutral">
                    {device.userId}
                  </div>
                </div>
              </Button>
            ))}

            {filteredDevices.length === 0 && (
              <div className="flex flex-col items-center justify-center py-8 text-neutral">
                <MapPin className="h-10 w-10 text-neutral-medium mb-2" />
                <p className="text-sm font-medium">No devices found</p>
                <p className="text-xs mt-1">Try a different search term</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Main map area */}
      <div className="lg:col-span-2 space-y-4">
        <Card>
          <CardHeader className="p-4 flex-row items-center justify-between space-y-0">
            <div className="flex items-center">
              <Navigation className="h-5 w-5 text-primary mr-2" />
              <CardTitle className="text-lg font-medium">
                {selectedDevice ? `${selectedDevice.name} Location` : 'Device Location'}
              </CardTitle>
              {selectedDevice && (
                <Badge variant="secondary" className="ml-2">
                  {selectedDevice.status === "online" ? "Online" : "Offline"}
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Select value={selectedTimeframe} onValueChange={handleTimeframeChange}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select timeframe" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">Last 7 days</SelectItem>
                  <SelectItem value="month">Last 30 days</SelectItem>
                  <SelectItem value="all">All time</SelectItem>
                </SelectContent>
              </Select>
              
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={onRefresh}
                disabled={isLoading}
              >
                <RefreshCw className={cn("h-4 w-4", isLoading && "animate-spin")} />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-[500px] bg-neutral-lightest relative">
              {isLoading ? (
                <div className="absolute inset-0 flex items-center justify-center bg-white/80 z-10">
                  <RefreshCw className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : !selectedDevice ? (
                <div className="flex flex-col items-center justify-center h-full text-neutral">
                  <MapPin className="h-12 w-12 text-neutral-medium mb-2" />
                  <p className="text-lg font-medium">Select a device</p>
                  <p className="text-sm mt-1">Choose a device to view its location</p>
                </div>
              ) : locations.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-neutral">
                  <History className="h-12 w-12 text-neutral-medium mb-2" />
                  <p className="text-lg font-medium">No location data</p>
                  <p className="text-sm mt-1">This device has no recorded locations</p>
                </div>
              ) : (
                <div className="h-full w-full bg-neutral-lightest relative">
                  {/* Map placeholder */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <MapPin className="h-12 w-12 text-primary mx-auto animate-bounce" />
                      <p className="mt-2 text-neutral-dark">
                        Map interface would be displayed here with {locations.length} location points
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Location history */}
        <Card>
          <CardHeader className="p-4 flex-row items-center justify-between space-y-0">
            <div className="flex items-center">
              <History className="h-5 w-5 text-primary mr-2" />
              <CardTitle className="text-base font-medium">Location History</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <Tabs defaultValue="timeline">
              <div className="border-b">
                <TabsList className="w-full justify-start rounded-none h-10 bg-transparent pl-4">
                  <TabsTrigger 
                    value="timeline" 
                    className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none rounded-none"
                  >
                    Timeline
                  </TabsTrigger>
                  <TabsTrigger 
                    value="geofence" 
                    className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none rounded-none"
                  >
                    Geofencing
                  </TabsTrigger>
                </TabsList>
              </div>
              
              <TabsContent value="timeline" className="p-0 m-0">
                <div className="max-h-[200px] overflow-y-auto p-2">
                  {locations.length > 0 ? (
                    <div className="space-y-3">
                      {locations.map((location, index) => (
                        <div key={location.id} className="flex items-start p-2 hover:bg-neutral-light rounded-md transition-colors">
                          <div className="mr-3 flex flex-col items-center">
                            <div className={cn(
                              "w-8 h-8 rounded-full flex items-center justify-center",
                              index === 0 ? "bg-primary text-white" : "bg-neutral-light text-neutral-dark"
                            )}>
                              {index === 0 ? (
                                <Navigation className="h-4 w-4" />
                              ) : (
                                <MapPin className="h-4 w-4" />
                              )}
                            </div>
                            {index < locations.length - 1 && (
                              <div className="w-0.5 h-6 bg-neutral-medium"></div>
                            )}
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-neutral-darkest">
                              {index === 0 ? "Current Location" : `Location Point ${index + 1}`}
                            </p>
                            <p className="text-xs text-neutral-dark">{formatDate(location.timestamp)}</p>
                            <div className="flex items-center mt-1 text-xs text-neutral">
                              <span className="inline-flex items-center">
                                <Building className="h-3 w-3 mr-1" />
                                {location.latitude}, {location.longitude}
                              </span>
                              {location.accuracy && (
                                <span className="ml-3 inline-flex items-center">
                                  <Navigation className="h-3 w-3 mr-1" />
                                  Accuracy: {location.accuracy}m
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-40 text-neutral">
                      <History className="h-8 w-8 text-neutral-medium mb-2" />
                      <p className="text-sm font-medium">No location history</p>
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="geofence" className="p-4 m-0">
                <div className="space-y-4">
                  <div className="flex flex-col space-y-1">
                    <label className="text-sm font-medium">Active Geofences</label>
                    <div className="flex flex-wrap gap-2 mt-1">
                      <Badge variant="outline" className="flex items-center gap-1 py-1 px-3">
                        <Home className="h-3 w-3" />
                        Office Building
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1 py-1 px-3">
                        <Building className="h-3 w-3" />
                        Warehouse
                      </Badge>
                      <Button variant="ghost" size="sm" className="h-7 text-xs">
                        + Add Geofence
                      </Button>
                    </div>
                  </div>
                  
                  <div>
                    <Button variant="outline" className="w-full flex items-center gap-2 justify-center">
                      <FileText className="h-4 w-4" />
                      Generate Location Report
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// Smartphone icon for device list
function Smartphone({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <rect width="14" height="20" x="5" y="2" rx="2" ry="2" />
      <path d="M12 18h.01" />
    </svg>
  );
}
