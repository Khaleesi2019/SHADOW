import { Smartphone, CheckCircle, AlertCircle, HardDrive } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface StatsCardProps {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  iconBackgroundClass?: string;
}

const StatsCard = ({ icon, label, value, iconBackgroundClass = "bg-primary-light/10" }: StatsCardProps) => (
  <Card className="bg-white shadow-sm border border-neutral-medium">
    <CardContent className="p-4">
      <div className="flex items-center">
        <div className={`p-2 rounded-md ${iconBackgroundClass}`}>
          {icon}
        </div>
        <div className="ml-3">
          <p className="text-sm text-neutral">{label}</p>
          <p className="text-xl font-medium text-neutral-darkest">{value}</p>
        </div>
      </div>
    </CardContent>
  </Card>
);

interface DeviceStatsProps {
  totalDevices: number;
  onlineDevices: number;
  alertsCount: number;
  dataTransferred: string;
  isLoading?: boolean;
}

export function DeviceStats({
  totalDevices,
  onlineDevices,
  alertsCount,
  dataTransferred,
  isLoading = false,
}: DeviceStatsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="bg-white shadow-sm border border-neutral-medium">
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="p-2 rounded-md bg-neutral-light animate-pulse h-10 w-10"></div>
                <div className="ml-3 w-full">
                  <div className="h-4 bg-neutral-light animate-pulse rounded mb-2 w-20"></div>
                  <div className="h-6 bg-neutral-light animate-pulse rounded w-12"></div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <StatsCard
        icon={<Smartphone className="h-5 w-5 text-primary" />}
        label="Total Devices"
        value={totalDevices}
        iconBackgroundClass="bg-primary-light/10"
      />
      
      <StatsCard
        icon={<CheckCircle className="h-5 w-5 text-green-600" />}
        label="Online"
        value={onlineDevices}
        iconBackgroundClass="bg-green-100"
      />
      
      <StatsCard
        icon={<AlertCircle className="h-5 w-5 text-red-600" />}
        label="Alerts"
        value={alertsCount}
        iconBackgroundClass="bg-red-100"
      />
      
      <StatsCard
        icon={<HardDrive className="h-5 w-5 text-purple-600" />}
        label="Data Transferred"
        value={dataTransferred}
        iconBackgroundClass="bg-purple-100"
      />
    </div>
  );
}
