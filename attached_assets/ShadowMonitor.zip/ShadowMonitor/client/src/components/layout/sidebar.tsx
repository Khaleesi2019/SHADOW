import { useLocation, Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  PanelsTopLeft, 
  Smartphone, 
  Activity, 
  Folder, 
  MapPin, 
  BarChart, 
  Settings, 
  LogOut, 
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const navItems = [
  { path: "/", label: "PanelsTopLeft", icon: <PanelsTopLeft className="mr-3 h-5 w-5" /> },
  { path: "/devices", label: "Devices", icon: <Smartphone className="mr-3 h-5 w-5" /> },
  { path: "/monitoring", label: "Monitoring", icon: <Activity className="mr-3 h-5 w-5" /> },
  { path: "/files", label: "File Transfer", icon: <Folder className="mr-3 h-5 w-5" /> },
  { path: "/location", label: "Location", icon: <MapPin className="mr-3 h-5 w-5" /> },
  { path: "/reports", label: "Reports", icon: <BarChart className="mr-3 h-5 w-5" /> },
  { path: "/settings", label: "Settings", icon: <Settings className="mr-3 h-5 w-5" /> }
];

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  const sidebarClasses = isOpen
    ? "fixed inset-0 z-50 block md:relative md:flex w-64 bg-white border-r border-neutral-medium shadow-sm"
    : "hidden md:flex flex-col w-64 bg-white border-r border-neutral-medium shadow-sm";
    
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  if (!user) return null;
  
  return (
    <div id="sidebar" className={sidebarClasses}>
      <div className="flex items-center justify-between p-4 border-b border-neutral-medium">
        <div className="flex items-center space-x-2">
          <div className="p-1 rounded bg-primary text-white">
            <Shield className="h-5 w-5" />
          </div>
          <h1 className="text-lg font-medium text-neutral-darkest">SecureMonitor</h1>
        </div>
        <button 
          id="mobile-close" 
          className="md:hidden"
          onClick={onClose}
        >
          <X className="h-5 w-5 text-neutral-dark" />
        </button>
      </div>
      
      <div className="overflow-y-auto flex-grow">
        <nav className="p-2">
          <ul>
            {navItems.map((item) => (
              <li className="mb-1" key={item.path}>
                <Link href={item.path}>
                  <a 
                    className={`flex items-center p-3 rounded-lg group transition-all ${
                      location === item.path 
                        ? "bg-primary-light/10 text-primary" 
                        : "text-neutral-darkest hover:bg-neutral-light"
                    }`}
                  >
                    <span className={location === item.path ? "text-primary" : "text-neutral-dark group-hover:text-primary"}>
                      {item.icon}
                    </span>
                    <span>{item.label}</span>
                  </a>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
      
      <div className="p-4 border-t border-neutral-medium">
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white text-sm">
            <span>{user.name?.split(' ').map(n => n[0]).join('').toUpperCase() || 'U'}</span>
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-neutral-darkest">{user.name}</p>
            <p className="text-xs text-neutral-dark">{user.email}</p>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            className="ml-auto" 
            onClick={handleLogout}
          >
            <LogOut className="h-5 w-5 text-neutral-dark" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function Shield(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      {...props}
    >
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
    </svg>
  );
}
