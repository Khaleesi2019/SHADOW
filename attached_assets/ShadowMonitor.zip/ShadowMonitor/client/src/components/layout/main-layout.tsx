import { ReactNode, useState } from "react";
import Sidebar from "./sidebar";
import Header from "./header";

interface MainLayoutProps {
  children: ReactNode;
  title: string;
}

export default function MainLayout({ children, title }: MainLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  return (
    <div className="flex h-screen overflow-hidden bg-neutral-lightest">
      <Sidebar isOpen={sidebarOpen} onClose={toggleSidebar} />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title={title} onMenuClick={toggleSidebar} />
        
        <main className="flex-1 overflow-y-auto p-4 bg-neutral-lightest">
          {children}
        </main>
      </div>
    </div>
  );
}
