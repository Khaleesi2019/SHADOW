import { Bell, Menu, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useWebsocketStatus } from "@/lib/websocket";

interface HeaderProps {
  title: string;
  onMenuClick: () => void;
}

export default function Header({ title, onMenuClick }: HeaderProps) {
  const isWebsocketConnected = useWebsocketStatus();
  
  return (
    <header className="bg-white border-b border-neutral-medium shadow-sm">
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="icon" 
            className="md:hidden mr-4" 
            onClick={onMenuClick}
          >
            <Menu className="h-5 w-5 text-neutral-dark" />
          </Button>
          <h1 className="text-lg font-medium text-neutral-darkest">{title}</h1>
          
          {!isWebsocketConnected && (
            <div className="ml-4 flex items-center text-xs text-orange-600 bg-orange-50 px-2 py-1 rounded-full">
              <span className="mr-1 inline-block w-2 h-2 rounded-full bg-orange-500"></span>
              Reconnecting...
            </div>
          )}
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral" />
            <Input 
              type="text" 
              placeholder="Search devices..." 
              className="py-2 px-4 pl-10 bg-neutral-light w-48 md:w-64"
            />
          </div>
          
          <Button 
            variant="ghost" 
            size="icon" 
            className="relative"
          >
            <Bell className="h-5 w-5 text-neutral-dark" />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-secondary"></span>
          </Button>
        </div>
      </div>
    </header>
  );
}
