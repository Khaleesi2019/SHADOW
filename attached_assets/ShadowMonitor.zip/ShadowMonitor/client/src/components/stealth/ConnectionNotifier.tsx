import { useEffect, useState } from 'react';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/hooks/use-toast';
import { Device } from '@shared/schema';
import { useWebsocket } from '@/lib/websocket';
import { Bell } from 'lucide-react';

/**
 * Este componente escucha las conexiones de dispositivos y envía
 * notificaciones cuando alguno está en línea.
 */
export function ConnectionNotifier() {
  const { toast } = useToast();
  const [connectedDevices, setConnectedDevices] = useState<string[]>([]);
  
  // Escuchar mensajes de conexión de dispositivo
  useWebsocket<any>('device_update', (message) => {
    if (message.payload?.isOnline && !connectedDevices.includes(message.payload.deviceId)) {
      // Nuevo dispositivo conectado
      notifyDeviceConnected(message.payload);
      setConnectedDevices(prev => [...prev, message.payload.deviceId]);
    }
  });
  
  // Escuchar mensajes de heartbeat de dispositivo
  useWebsocket<any>('heartbeat', (message) => {
    if (message.payload?.deviceId && !connectedDevices.includes(message.payload.deviceId)) {
      // Dispositivo envió heartbeat pero no lo teníamos registrado
      notifyDeviceConnected(message.payload);
      setConnectedDevices(prev => [...prev, message.payload.deviceId]);
    }
  });
  
  // Notificar al administrador cuando un dispositivo se conecta
  const notifyDeviceConnected = (device: Partial<Device>) => {
    toast({
      title: "Dispositivo conectado",
      description: `${device.name || device.deviceId} está en línea y listo para conectarse.`,
      variant: "default",
      duration: 5000,
      action: (
        <div className="bg-green-500 text-white p-1 rounded-full">
          <Bell className="h-4 w-4" />
        </div>
      )
    });
    
    // También podemos enviar una notificación nativa si el navegador lo soporta
    if ('Notification' in window) {
      if (Notification.permission === 'granted') {
        new Notification('Dispositivo TattooMaster Conectado', {
          body: `${device.name || device.deviceId} está en línea y listo para conectarse.`,
          icon: '/assets/logo.png',
        });
      } else if (Notification.permission !== 'denied') {
        Notification.requestPermission();
      }
    }
    
    // Y un sonido de alerta
    const audio = new Audio('/assets/notification.mp3');
    audio.play().catch(e => console.log('No se pudo reproducir el sonido de notificación'));
  };
  
  // Efecto para solicitar permisos de notificación al inicio
  useEffect(() => {
    if ('Notification' in window && Notification.permission !== 'denied') {
      Notification.requestPermission();
    }
  }, []);
  
  // Este componente no renderiza nada visible, solo gestiona las notificaciones
  return null;
}