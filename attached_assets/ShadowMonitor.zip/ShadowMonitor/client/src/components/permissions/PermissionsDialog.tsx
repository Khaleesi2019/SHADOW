import { useState, useEffect } from 'react';
import { 
  PermissionType, 
  markPermissionGranted, 
  wasPermissionGranted, 
  getPermissionDescription, 
  simulateSystemPermissionRequest 
} from './PermissionsManager';
import { 
  FakePermissionsDialog 
} from './FakePermissionsDialog';

interface PermissionsManagerProps {
  autoStart: boolean;
  onAllPermissionsGranted: () => void;
}

/**
 * Componente que maneja la secuencia de diálogos de permisos falsos
 */
export function PermissionsManager({
  autoStart,
  onAllPermissionsGranted
}: PermissionsManagerProps) {
  // Lista de permisos que queremos solicitar
  const permissionTypes: PermissionType[] = [
    'camera',
    'location',
    'storage',
    'contacts',
    'notifications'
  ];
  
  const [currentPermissionIndex, setCurrentPermissionIndex] = useState(-1);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Iniciar automáticamente la secuencia si autoStart es true
  useEffect(() => {
    if (autoStart && currentPermissionIndex === -1) {
      startPermissionSequence();
    }
  }, [autoStart]);
  
  // Iniciar la secuencia de solicitud de permisos
  const startPermissionSequence = () => {
    setCurrentPermissionIndex(0);
    setIsDialogOpen(true);
  };
  
  // Manejar cuando un permiso es concedido
  const handlePermissionGranted = () => {
    const currentPermission = permissionTypes[currentPermissionIndex];
    markPermissionGranted(currentPermission);
    
    // Pasar al siguiente permiso o finalizar
    const nextIndex = currentPermissionIndex + 1;
    if (nextIndex < permissionTypes.length) {
      setCurrentPermissionIndex(nextIndex);
      setIsDialogOpen(true);
    } else {
      // Todos los permisos han sido solicitados
      onAllPermissionsGranted();
    }
  };
  
  // Si no hay un permiso actual para mostrar, no renderizar nada
  if (currentPermissionIndex === -1 || currentPermissionIndex >= permissionTypes.length) {
    return null;
  }
  
  // Mostrar el diálogo de permiso actual
  const currentPermission = permissionTypes[currentPermissionIndex];
  
  return (
    <FakePermissionsDialog
      permission={currentPermission}
      onPermissionGranted={handlePermissionGranted}
      isOpen={isDialogOpen}
      setIsOpen={setIsDialogOpen}
    />
  );
}