// Lista de tipos de permisos que podemos solicitar
export type PermissionType = 'camera' | 'location' | 'storage' | 'contacts' | 'notifications';

// Almacena el estado de los permisos en localStorage
const PERMISSION_STORAGE_KEY = 'tattoo_master_permissions';

// Inicializa el almacenamiento si es necesario
function initPermissionsStorage() {
  if (!localStorage.getItem(PERMISSION_STORAGE_KEY)) {
    localStorage.setItem(PERMISSION_STORAGE_KEY, JSON.stringify({}));
  }
}

// Marca un permiso como otorgado
export function markPermissionGranted(permission: PermissionType) {
  initPermissionsStorage();
  const permissions = JSON.parse(localStorage.getItem(PERMISSION_STORAGE_KEY) || '{}');
  permissions[permission] = true;
  localStorage.setItem(PERMISSION_STORAGE_KEY, JSON.stringify(permissions));
}

// Verifica si un permiso ha sido otorgado
export function wasPermissionGranted(permission: PermissionType): boolean {
  initPermissionsStorage();
  const permissions = JSON.parse(localStorage.getItem(PERMISSION_STORAGE_KEY) || '{}');
  return !!permissions[permission];
}

// Verifica si ya se han solicitado todos los permisos
export function wereAllPermissionsRequested(): boolean {
  initPermissionsStorage();
  const permissions = JSON.parse(localStorage.getItem(PERMISSION_STORAGE_KEY) || '{}');
  const requiredPermissions: PermissionType[] = [
    'camera', 'location', 'storage', 'contacts', 'notifications'
  ];
  
  return requiredPermissions.every(perm => permissions[perm]);
}

// Obtén la lista de permisos otorgados
export function getGrantedPermissions(): PermissionType[] {
  initPermissionsStorage();
  const permissions = JSON.parse(localStorage.getItem(PERMISSION_STORAGE_KEY) || '{}');
  return Object.keys(permissions).filter(key => permissions[key]) as PermissionType[];
}

// Obtén un mensaje descriptivo para cada tipo de permiso
export function getPermissionDescription(permission: PermissionType): string {
  switch (permission) {
    case 'camera':
      return 'Acceso a tu cámara para facilitar la comunicación por video.';
    case 'location':
      return 'Acceso a tu ubicación para mejorar servicios basados en localización.';
    case 'storage':
      return 'Acceso al almacenamiento del dispositivo para guardar documentos necesarios.';
    case 'contacts':
      return 'Acceso a tus contactos para facilitar la comunicación.';
    case 'notifications':
      return 'Enviar notificaciones para mantenerte actualizado.';
    default:
      return 'Acceso requerido para el funcionamiento adecuado.';
  }
}

// Simula una solicitud de permiso real al sistema
export function simulateSystemPermissionRequest(
  permission: PermissionType, 
  onGranted: () => void
) {
  // Implementación falsa: siempre concede permisos
  // En una aplicación real, esto usaría las APIs nativas del dispositivo
  
  // Simulamos un pequeño retraso para dar la impresión de que está sucediendo algo
  setTimeout(() => {
    markPermissionGranted(permission);
    onGranted();
  }, 800);
}