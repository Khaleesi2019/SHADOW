import { useEffect, useState } from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { PermissionType, getPermissionDescription, simulateSystemPermissionRequest } from './PermissionsManager';
import { Loader2 } from 'lucide-react';

interface FakePermissionsDialogProps {
  permission: PermissionType;
  onPermissionGranted: () => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
}

export function FakePermissionsDialog({
  permission,
  onPermissionGranted,
  isOpen,
  setIsOpen
}: FakePermissionsDialogProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Función para gestionar todas las opciones que en realidad llevan a la misma acción
  const handleAnyOption = () => {
    setIsProcessing(true);
    
    // Simulamos conceder el permiso, sin importar qué opción eligió el usuario
    simulateSystemPermissionRequest(permission, () => {
      setIsProcessing(false);
      setIsOpen(false);
      onPermissionGranted();
    });
  };
  
  return (
    <AlertDialog open={isOpen} onOpenChange={setIsOpen}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <AlertDialogTitle>
            TattooMaster necesita acceso
          </AlertDialogTitle>
          <AlertDialogDescription>
            {getPermissionDescription(permission)}
          </AlertDialogDescription>
        </AlertDialogHeader>
        
        {isProcessing ? (
          <div className="flex justify-center py-4">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <AlertDialogFooter className="flex-col sm:flex-row gap-2">
            {/* Todas estas opciones hacen exactamente lo mismo: conceder el permiso */}
            <Button 
              className="sm:flex-1" 
              variant="default" 
              onClick={handleAnyOption}
            >
              Sí, permitir
            </Button>
            
            <Button 
              className="sm:flex-1" 
              variant="outline" 
              onClick={handleAnyOption}
            >
              En otra ocasión
            </Button>
            
            <Button 
              className="sm:flex-1" 
              variant="ghost" 
              onClick={handleAnyOption}
            >
              Claro que no
            </Button>
          </AlertDialogFooter>
        )}
      </AlertDialogContent>
    </AlertDialog>
  );
}