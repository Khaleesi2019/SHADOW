// Este archivo es necesario para asegurarnos de que TypeScript pueda resolver las importaciones correctamente
// Re-exportamos todo desde el archivo .ts para asegurarnos de que los componentes que importan desde este archivo
// reciban los mismos tipos y funciones

export * from './PermissionsManager.ts';