import { useState } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogFooter, 
  DialogHeader,
  DialogTitle,
  DialogClose
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Device } from "@shared/schema";
import { useDevices } from "@/hooks/use-devices";
import { 
  Smartphone, 
  X, 
  AlertCircle,
  Battery, 
  BatteryCharging, 
  BatteryFull, 
  BatteryMedium, 
  BatteryLow,
  CheckCircle, 
  Info, 
  RefreshCw, 
  Maximize2, 
  Video, 
  Lock, 
  History, 
  Grip, 
  ChevronLeft,
  Send,
  MessageSquare
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useWebsocket } from "@/lib/websocket";

interface DeviceDetailsProps {
  device: Device | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function DeviceDetails({ device, open, onOpenChange }: DeviceDetailsProps) {
  const [activeTab, setActiveTab] = useState('screen');
  const { sendCommand } = useDevices();
  const { toast } = useToast();
  const [screenData, setScreenData] = useState<string | null>(null);
  
  // Listen for screen capture updates from the device
  useWebsocket('screen_capture', (message: any) => {
    if (device && message.payload.deviceId === device.deviceId) {
      setScreenData(message.payload.imageData);
    }
  });
  
  if (!device) return null;
  
  const handleRefreshScreen = () => {
    if (device) {
      sendCommand({
        deviceId: device.deviceId,
        command: { type: 'screen_capture', requestId: Date.now() }
      });
      
      toast({
        title: "Screen Refresh",
        description: "Requesting latest screen capture...",
      });
    }
  };
  
  const handleLockDevice = () => {
    if (device) {
      sendCommand({
        deviceId: device.deviceId,
        command: { type: 'lock_device' }
      });
      
      toast({
        title: "Device Locked",
        description: "Lock command sent to device.",
      });
    }
  };
  
  const handleTakeControl = () => {
    if (device) {
      sendCommand({
        deviceId: device.deviceId,
        command: { type: 'take_control' }
      });
      
      toast({
        title: "Control Requested",
        description: "Remote control request sent to device.",
      });
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col p-0 gap-0">
        <DialogHeader className="p-4 border-b border-neutral-medium flex flex-row items-center justify-between">
          <div className="flex items-center">
            <Smartphone className="text-primary mr-2 h-5 w-5" />
            <DialogTitle className="text-lg font-medium">{device.name}</DialogTitle>
            <div className="ml-3 flex items-center">
              <span 
                className={`inline-block w-2 h-2 rounded-full mr-2 ${
                  device.status === 'alert' 
                    ? 'bg-red-500' 
                    : device.isOnline 
                      ? 'bg-green-500' 
                      : 'bg-neutral-dark'
                }`}
              ></span>
              <span 
                className={`text-sm ${
                  device.status === 'alert' 
                    ? 'text-red-600' 
                    : device.isOnline 
                      ? 'text-green-600' 
                      : 'text-neutral-dark'
                }`}
              >
                {device.status === 'alert' ? 'Alert' : device.isOnline ? 'Online' : 'Offline'}
              </span>
            </div>
          </div>
          <DialogClose asChild>
            <Button variant="ghost" size="icon" className="rounded-full">
              <X className="h-4 w-4 text-neutral-dark" />
            </Button>
          </DialogClose>
        </DialogHeader>
        
        <div className="flex flex-col md:flex-row flex-grow overflow-hidden">
          {/* Device Info Sidebar */}
          <div className="w-full md:w-64 border-r border-neutral-medium bg-neutral-lightest p-4 overflow-y-auto">
            <div className="mb-4">
              <p className="text-sm text-neutral mb-1">Device User</p>
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white text-sm">
                  <span>{device.user.split(' ').map(n => n[0]).join('').toUpperCase()}</span>
                </div>
                <div className="ml-2">
                  <p className="text-sm font-medium text-neutral-darkest">{device.user}</p>
                  <p className="text-xs text-neutral-dark">{device.department || 'No Department'}</p>
                </div>
              </div>
            </div>
            
            <div className="mb-4">
              <p className="text-sm text-neutral mb-1">Device Info</p>
              <div className="text-sm">
                <div className="flex justify-between mb-1">
                  <span className="text-neutral-dark">Model:</span>
                  <span className="text-neutral-darkest">{device.model}</span>
                </div>
                <div className="flex justify-between mb-1">
                  <span className="text-neutral-dark">OS:</span>
                  <span className="text-neutral-darkest">{device.osVersion}</span>
                </div>
                {device.imei && (
                  <div className="flex justify-between mb-1">
                    <span className="text-neutral-dark">IMEI:</span>
                    <span className="text-neutral-darkest">{device.imei}</span>
                  </div>
                )}
                {device.lastIpAddress && (
                  <div className="flex justify-between mb-1">
                    <span className="text-neutral-dark">IP Address:</span>
                    <span className="text-neutral-darkest">{device.lastIpAddress}</span>
                  </div>
                )}
                <div className="flex justify-between mb-1">
                  <span className="text-neutral-dark">Last Active:</span>
                  <span className="text-neutral-darkest">
                    {device.lastActive 
                      ? device.isOnline 
                        ? 'Just now'
                        : new Date(device.lastActive).toLocaleString()
                      : 'Unknown'
                    }
                  </span>
                </div>
                {device.storage && (
                  <div className="flex justify-between mb-1">
                    <span className="text-neutral-dark">Storage:</span>
                    <span className="text-neutral-darkest">
                      {device.storage.used}GB / {device.storage.total}GB
                    </span>
                  </div>
                )}
                <div className="flex justify-between mb-1">
                  <span className="text-neutral-dark">Battery:</span>
                  <div className="flex items-center">
                    {device.battery !== null && device.battery !== undefined ? (
                      <>
                        {device.battery <= 20 ? (
                          <BatteryLow className="text-red-500 h-4 w-4 mr-1" />
                        ) : device.battery <= 50 ? (
                          <BatteryMedium className="text-orange-500 h-4 w-4 mr-1" />
                        ) : (
                          <BatteryFull className="text-green-500 h-4 w-4 mr-1" />
                        )}
                        <span className="text-neutral-darkest">{device.battery}%</span>
                      </>
                    ) : (
                      <span className="text-neutral-darkest">Unknown</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mb-4">
              <p className="text-sm text-neutral mb-1">Status</p>
              <div className="text-sm">
                <div className="flex items-center mb-1">
                  {device.isOnline ? (
                    <CheckCircle className="text-green-500 h-4 w-4 mr-1" />
                  ) : (
                    <AlertCircle className="text-neutral-dark h-4 w-4 mr-1" />
                  )}
                  <span className="text-neutral-darkest">
                    Device monitoring {device.isOnline ? 'active' : 'inactive'}
                  </span>
                </div>
                
                {device.latitude && device.longitude ? (
                  <div className="flex items-center mb-1">
                    <CheckCircle className="text-green-500 h-4 w-4 mr-1" />
                    <span className="text-neutral-darkest">Location services enabled</span>
                  </div>
                ) : (
                  <div className="flex items-center mb-1">
                    <Info className="text-orange-500 h-4 w-4 mr-1" />
                    <span className="text-neutral-darkest">Location unavailable</span>
                  </div>
                )}
                
                {device.isOnline ? (
                  <div className="flex items-center mb-1">
                    <CheckCircle className="text-green-500 h-4 w-4 mr-1" />
                    <span className="text-neutral-darkest">Background service running</span>
                  </div>
                ) : (
                  <div className="flex items-center mb-1">
                    <AlertCircle className="text-neutral-dark h-4 w-4 mr-1" />
                    <span className="text-neutral-darkest">Background service inactive</span>
                  </div>
                )}
                
                {device.status === 'alert' && (
                  <div className="flex items-center mb-1">
                    <AlertCircle className="text-red-500 h-4 w-4 mr-1" />
                    <span className="text-red-600">Alert active</span>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {/* Main Details Area */}
          <div className="flex-1 overflow-hidden flex flex-col">
            <Tabs 
              defaultValue="screen" 
              className="flex-1 flex flex-col overflow-hidden"
              value={activeTab}
              onValueChange={setActiveTab}
            >
              <TabsList className="border-b border-neutral-medium justify-start rounded-none px-4 bg-transparent">
                <TabsTrigger 
                  value="screen" 
                  className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none px-4 py-3 data-[state=inactive]:border-b-0"
                >
                  Screen
                </TabsTrigger>
                <TabsTrigger 
                  value="files" 
                  className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none px-4 py-3 data-[state=inactive]:border-b-0"
                >
                  Files
                </TabsTrigger>
                <TabsTrigger 
                  value="apps"
                  className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none px-4 py-3 data-[state=inactive]:border-b-0"
                >
                  Apps
                </TabsTrigger>
                <TabsTrigger 
                  value="location"
                  className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none px-4 py-3 data-[state=inactive]:border-b-0"
                >
                  Location
                </TabsTrigger>
                <TabsTrigger 
                  value="logs"
                  className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none px-4 py-3 data-[state=inactive]:border-b-0"
                >
                  Logs
                </TabsTrigger>
              </TabsList>
              
              <TabsContent 
                value="screen" 
                className="p-4 flex flex-col items-center justify-center flex-grow bg-neutral-darkest overflow-auto m-0 border-0"
              >
                {/* Screen View */}
                <div className="relative max-w-[300px] mx-auto">
                  {/* Phone mockup */}
                  <div className="w-[300px] h-[600px] bg-black rounded-[36px] p-3 shadow-xl relative overflow-hidden">
                    <div className="absolute top-0 left-0 right-0 h-10 bg-black rounded-t-[36px] flex justify-center items-end pb-1">
                      <div className="w-32 h-6 bg-black rounded-b-xl"></div>
                    </div>
                    
                    {/* Phone screen content */}
                    <div className="w-full h-full rounded-[30px] bg-white overflow-hidden relative">
                      {screenData ? (
                        <img 
                          src={screenData} 
                          alt="Device screen" 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="h-full flex flex-col">
                          {/* Messaging app mockup */}
                          <div className="h-12 bg-primary flex items-center px-4 text-white">
                            <ChevronLeft className="h-5 w-5 mr-2" />
                            <div className="flex items-center">
                              <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-primary text-sm mr-2">
                                <span>JD</span>
                              </div>
                              <div>
                                <p className="text-sm font-medium">John Doe</p>
                                <p className="text-xs opacity-80">Online</p>
                              </div>
                            </div>
                          </div>
                          
                          <div className="p-4 bg-gray-100 h-[calc(100%-12rem)] overflow-y-auto">
                            <div className="mb-4 flex justify-start">
                              <div className="bg-white p-3 rounded-lg rounded-tl-none max-w-[80%] shadow-sm">
                                <p className="text-sm">Hey, I need the presentation for tomorrow's meeting.</p>
                                <p className="text-xs text-neutral-dark text-right">10:42 AM</p>
                              </div>
                            </div>
                            
                            <div className="mb-4 flex justify-end">
                              <div className="bg-primary p-3 rounded-lg rounded-tr-none max-w-[80%] shadow-sm text-white">
                                <p className="text-sm">I'm working on it, will send it in an hour.</p>
                                <p className="text-xs opacity-80 text-right">10:45 AM</p>
                              </div>
                            </div>
                            
                            <div className="mb-4 flex justify-start">
                              <div className="bg-white p-3 rounded-lg rounded-tl-none max-w-[80%] shadow-sm">
                                <p className="text-sm">Great, thanks! Also, did you finish the sales report?</p>
                                <p className="text-xs text-neutral-dark text-right">10:47 AM</p>
                              </div>
                            </div>
                            
                            <div className="mb-4 flex justify-end">
                              <div className="bg-primary p-3 rounded-lg rounded-tr-none max-w-[80%] shadow-sm text-white">
                                <p className="text-sm">Yes, it's ready. I'll include it with the presentation.</p>
                                <p className="text-xs opacity-80 text-right">10:49 AM</p>
                              </div>
                            </div>
                          </div>
                          
                          <div className="absolute bottom-0 left-0 right-0 bg-white p-3 border-t border-neutral-medium">
                            <div className="flex items-center">
                              <MessageSquare className="text-neutral h-5 w-5 mx-2" />
                              <div className="flex-1 p-2 bg-neutral-light rounded-full text-sm">
                                Type a message
                              </div>
                              <Send className="text-primary h-5 w-5 mx-2" />
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="mt-4 flex gap-4 justify-center">
                  <Button 
                    variant="default"
                    className="flex items-center"
                    onClick={handleRefreshScreen}
                    disabled={!device.isOnline}
                  >
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Refresh
                  </Button>
                  <Button 
                    variant="outline"
                    className="flex items-center"
                    disabled={!device.isOnline}
                  >
                    <Maximize2 className="h-4 w-4 mr-2" />
                    Fullscreen
                  </Button>
                  <Button 
                    variant="outline"
                    className="flex items-center"
                    disabled={!device.isOnline}
                  >
                    <Video className="h-4 w-4 mr-2" />
                    Record
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="files" className="flex-grow overflow-auto m-0 border-0 p-4">
                <div className="p-4 text-center text-neutral-dark">
                  <Folder className="h-16 w-16 mx-auto mb-2 text-neutral" />
                  <h3 className="text-lg font-medium mb-2">File Browser</h3>
                  <p className="mb-4">Browse and manage files on this device</p>
                  <Button disabled={!device.isOnline}>
                    Browse Files
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="apps" className="flex-grow overflow-auto m-0 border-0 p-4">
                <h3 className="text-lg font-medium mb-4">Installed Applications</h3>
                
                {device.installedApps && device.installedApps.length > 0 ? (
                  <div className="space-y-2">
                    {device.installedApps.map((app: any, index: number) => (
                      <div key={index} className="flex items-center p-3 border border-neutral-medium rounded-lg">
                        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary mr-3">
                          <span className="text-lg">{app.name.charAt(0)}</span>
                        </div>
                        <div>
                          <p className="font-medium">{app.name}</p>
                          <p className="text-xs text-neutral-dark">{app.packageName}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center text-neutral-dark p-8">
                    <p>No application data available</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="location" className="flex-grow overflow-auto m-0 border-0 p-4">
                <div className="p-4 text-center text-neutral-dark">
                  <MapPin className="h-16 w-16 mx-auto mb-2 text-neutral" />
                  <h3 className="text-lg font-medium mb-2">Location Tracking</h3>
                  {device.latitude && device.longitude ? (
                    <div>
                      <p className="mb-2">Current device location:</p>
                      <p className="font-medium">Latitude: {device.latitude}</p>
                      <p className="font-medium">Longitude: {device.longitude}</p>
                      <div className="mt-4 p-4 bg-neutral-light rounded-lg text-neutral-darkest">
                        Map view would be displayed here
                      </div>
                    </div>
                  ) : (
                    <p className="mb-4">Location data is not available for this device</p>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="logs" className="flex-grow overflow-auto m-0 border-0 p-4">
                <h3 className="text-lg font-medium mb-4">Device Activity Logs</h3>
                <div className="space-y-2">
                  {device.alerts && device.alerts.map((alert: any, index: number) => (
                    <div key={index} className="flex p-3 border border-red-200 bg-red-50 rounded-lg">
                      <AlertCircle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium text-red-700">{alert.type} Alert</p>
                        <p className="text-sm text-red-600">{alert.message}</p>
                        <p className="text-xs text-neutral-dark mt-1">
                          {new Date(alert.timestamp).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  ))}
                  
                  {(!device.alerts || device.alerts.length === 0) && (
                    <div className="text-center text-neutral-dark p-8">
                      <p>No activity logs available</p>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
        
        <DialogFooter className="p-4 border-t border-neutral-medium flex justify-between">
          <Button 
            variant="outline" 
            className="text-red-600 border-red-200 hover:bg-red-50"
            onClick={handleLockDevice}
            disabled={!device.isOnline}
          >
            <Lock className="h-4 w-4 mr-2" />
            Lock Device
          </Button>
          
          <div className="flex gap-2">
            <Button variant="outline">
              <History className="h-4 w-4 mr-2" />
              History
            </Button>
            <Button 
              onClick={handleTakeControl}
              disabled={!device.isOnline}
            >
              <Grip className="h-4 w-4 mr-2" />
              Take Control
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
