import { Device } from "@shared/schema";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Smartphone, User, Battery, BatteryWarning, BatteryCharging, BatteryFull, BatteryMedium, BatteryLow, Eye, Folder, MapPin, MoreHorizontal, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";

interface DeviceCardProps {
  device: Device;
  onMonitor: () => void;
  onFiles: () => void;
  onLocation: () => void;
  onMore: () => void;
  onClick: () => void;
}

export default function DeviceCard({ 
  device, 
  onMonitor, 
  onFiles, 
  onLocation, 
  onMore,
  onClick
}: DeviceCardProps) {
  
  const handleCardClick = (e: React.MouseEvent) => {
    // Only trigger onClick if not clicking a button
    if (!(e.target as HTMLElement).closest('button')) {
      onClick();
    }
  };
  
  const getBatteryIcon = () => {
    if (!device.battery && !device.isOnline) return <Battery className="text-neutral-dark" />;
    if (!device.battery) return <Battery className="text-neutral-dark" />;
    
    if (device.battery <= 20) return <BatteryLow className="text-red-500" />;
    if (device.battery <= 50) return <BatteryMedium className="text-orange-500" />;
    if (device.battery <= 80) return <BatteryMedium className="text-green-500" />;
    return <BatteryFull className="text-green-500" />;
  };
  
  const getLastActiveText = () => {
    if (!device.lastActive) return 'Unknown';
    if (!device.isOnline) return formatDistanceToNow(new Date(device.lastActive), { addSuffix: true });
    return 'Just now';
  };
  
  return (
    <Card 
      className={`device-card overflow-hidden transition-all cursor-pointer ${
        device.status === 'alert' ? 'border-red-300' : 'border-neutral-medium'
      }`}
      onClick={handleCardClick}
    >
      <CardContent className="p-4 border-b border-neutral-medium">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Smartphone className="text-primary mr-2 h-5 w-5" />
            <h3 className="font-medium text-neutral-darkest">{device.name}</h3>
          </div>
          <div className="flex items-center">
            <span 
              className={`inline-block w-2 h-2 rounded-full mr-2 ${
                device.status === 'alert' 
                  ? 'bg-red-500' 
                  : device.isOnline 
                    ? 'bg-green-500' 
                    : 'bg-neutral-dark'
              }`}
            ></span>
            <span 
              className={`text-sm ${
                device.status === 'alert' 
                  ? 'text-red-600' 
                  : device.isOnline 
                    ? 'text-green-600' 
                    : 'text-neutral-dark'
              }`}
            >
              {device.status === 'alert' ? 'Alert' : device.isOnline ? 'Online' : 'Offline'}
            </span>
          </div>
        </div>
        
        <div className="mt-3 flex items-center text-sm text-neutral-dark">
          <User className="h-4 w-4 mr-1" />
          <span>{device.user}{device.department ? ` - ${device.department}` : ''}</span>
        </div>
        
        {device.status === 'alert' && device.alerts && device.alerts.length > 0 && (
          <div className="mt-2 p-2 bg-red-50 text-red-700 text-xs rounded flex items-center">
            <AlertTriangle className="text-red-600 h-4 w-4 mr-1" />
            {device.alerts[device.alerts.length - 1].message}
          </div>
        )}
      </CardContent>
      
      <div className="grid grid-cols-2 text-center border-b border-neutral-medium divide-x divide-neutral-medium">
        <div className="p-3">
          <p className="text-xs text-neutral">Last Active</p>
          <p className="text-sm font-medium text-neutral-darkest">{getLastActiveText()}</p>
        </div>
        <div className="p-3">
          <p className="text-xs text-neutral">Battery</p>
          <div className="flex items-center justify-center">
            {getBatteryIcon()}
            <p className="text-sm font-medium text-neutral-darkest ml-1">
              {device.battery !== null && device.battery !== undefined ? `${device.battery}%` : 'Unknown'}
            </p>
          </div>
        </div>
      </div>
      
      <CardFooter className="p-3 grid grid-cols-4 gap-1">
        <Button 
          variant="ghost" 
          size="sm" 
          className="flex flex-col items-center justify-center p-2 h-auto rounded"
          disabled={!device.isOnline}
          onClick={onMonitor}
        >
          <Eye className={`h-5 w-5 ${device.isOnline ? 'text-primary' : 'text-neutral-dark'}`} />
          <span className="text-xs mt-1 text-neutral-dark">Monitor</span>
        </Button>
        
        <Button 
          variant="ghost" 
          size="sm" 
          className="flex flex-col items-center justify-center p-2 h-auto rounded"
          disabled={!device.isOnline}
          onClick={onFiles}
        >
          <Folder className={`h-5 w-5 ${device.isOnline ? 'text-primary' : 'text-neutral-dark'}`} />
          <span className="text-xs mt-1 text-neutral-dark">Files</span>
        </Button>
        
        <Button 
          variant="ghost" 
          size="sm" 
          className="flex flex-col items-center justify-center p-2 h-auto rounded"
          disabled={!device.isOnline}
          onClick={onLocation}
        >
          <MapPin className={`h-5 w-5 ${device.isOnline ? 'text-primary' : 'text-neutral-dark'}`} />
          <span className="text-xs mt-1 text-neutral-dark">Location</span>
        </Button>
        
        <Button 
          variant="ghost" 
          size="sm" 
          className="flex flex-col items-center justify-center p-2 h-auto rounded"
          onClick={onMore}
        >
          <MoreHorizontal className="h-5 w-5 text-primary" />
          <span className="text-xs mt-1 text-neutral-dark">More</span>
        </Button>
      </CardFooter>
    </Card>
  );
}
