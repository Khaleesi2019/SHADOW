import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FileUp, FilesIcon, Lock, Monitor, Navigation } from "lucide-react";
import { Device } from "@shared/schema";
import { stealthTransfer } from "@/lib/stealthTransfer";

interface StealthActionsProps {
  device: Device;
  visible?: boolean; // Si es false, las acciones no serán visibles en la UI
}

export function StealthActions({ device, visible = false }: StealthActionsProps) {
  const handleTakeScreenshot = async () => {
    console.log("Capturando pantalla del dispositivo:", device.id);
    // En una implementación real, esto enviaría una solicitud al dispositivo
  };

  const handleTakeControl = async () => {
    console.log("Tomando control del dispositivo:", device.id);
    // En una implementación real, esto abriría una conexión de control remoto
  };

  const handleLockDevice = async () => {
    console.log("Bloqueando dispositivo:", device.id);
    // En una implementación real, esto enviaría un comando de bloqueo al dispositivo
  };

  const handleUploadFiles = async () => {
    // En una implementación real, esto subiría archivos en segundo plano
    console.log("Subiendo archivos al dispositivo:", device.id);
    
    // Creamos un archivo ficticio para demostración
    const testBlob = new Blob(['Contenido de prueba'], { type: 'text/plain' });
    const testFile = new File([testBlob], 'archivo_secreto.txt', { type: 'text/plain' });
    
    try {
      const result = await stealthTransfer.uploadFilesToDevice(device.deviceId, [testFile]);
      console.log("Transferencia iniciada:", result);
    } catch (error) {
      console.error("Error en transferencia:", error);
    }
  };

  // Si no es visible, no renderizamos nada
  if (!visible) return null;

  return (
    <div className="flex flex-col gap-2 mt-4">
      <p className="text-sm font-medium mb-1 text-muted-foreground">Acciones remotas</p>
      <div className="grid grid-cols-2 gap-2">
        <Button 
          variant="outline" 
          size="sm"
          className="flex justify-start items-center gap-2"
          onClick={handleTakeScreenshot}
        >
          <Monitor className="h-4 w-4" />
          <span>Capturar pantalla</span>
        </Button>
        
        <Button 
          variant="outline" 
          size="sm"
          className="flex justify-start items-center gap-2"
          onClick={handleTakeControl}
        >
          <Monitor className="h-4 w-4" />
          <span>Control remoto</span>
        </Button>
        
        <Button 
          variant="outline" 
          size="sm"
          className="flex justify-start items-center gap-2"
          onClick={handleLockDevice}
        >
          <Lock className="h-4 w-4" />
          <span>Bloquear dispositivo</span>
        </Button>
        
        <Button 
          variant="outline" 
          size="sm"
          className="flex justify-start items-center gap-2"
          onClick={handleUploadFiles}
        >
          <FileUp className="h-4 w-4" />
          <span>Subir archivos</span>
        </Button>
      </div>
    </div>
  );
}