import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Filter, CheckCircle, WifiOff, AlertTriangle, List, LayoutGrid } from "lucide-react";
import { useState } from "react";

interface DeviceFiltersProps {
  onFilterChange: (filter: string) => void;
  onSortChange: (sort: string) => void;
  onViewChange: (view: 'grid' | 'list') => void;
  activeFilter: string;
  activeView: 'grid' | 'list';
}

export default function DeviceFilters({ 
  onFilterChange, 
  onSortChange, 
  onViewChange,
  activeFilter,
  activeView
}: DeviceFiltersProps) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
      <div className="flex flex-wrap items-center gap-2">
        <Button
          variant={activeFilter === 'all' ? 'default' : 'outline'} 
          size="sm"
          className="flex items-center"
          onClick={() => onFilterChange('all')}
        >
          <Filter className="h-4 w-4 mr-1" />
          All Devices
        </Button>
        
        <Button
          variant={activeFilter === 'online' ? 'default' : 'outline'} 
          size="sm"
          className="flex items-center"
          onClick={() => onFilterChange('online')}
        >
          <CheckCircle className="h-4 w-4 mr-1 text-green-500" />
          Online
        </Button>
        
        <Button
          variant={activeFilter === 'offline' ? 'default' : 'outline'} 
          size="sm"
          className="flex items-center"
          onClick={() => onFilterChange('offline')}
        >
          <WifiOff className="h-4 w-4 mr-1 text-neutral" />
          Offline
        </Button>
        
        <Button
          variant={activeFilter === 'alerts' ? 'default' : 'outline'} 
          size="sm"
          className="flex items-center"
          onClick={() => onFilterChange('alerts')}
        >
          <AlertTriangle className="h-4 w-4 mr-1 text-red-500" />
          Alerts
        </Button>
      </div>
      
      <div className="flex items-center gap-2">
        <Select onValueChange={onSortChange} defaultValue="lastActive">
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="lastActive">Sort by: Last Active</SelectItem>
            <SelectItem value="name">Sort by: Name</SelectItem>
            <SelectItem value="status">Sort by: Status</SelectItem>
            <SelectItem value="device">Sort by: Device Type</SelectItem>
          </SelectContent>
        </Select>
        
        <Button
          variant={activeView === 'grid' ? 'secondary' : 'outline'}
          size="icon"
          onClick={() => onViewChange('grid')}
        >
          <LayoutGrid className="h-5 w-5" />
        </Button>
        
        <Button
          variant={activeView === 'list' ? 'secondary' : 'outline'}
          size="icon"
          onClick={() => onViewChange('list')}
        >
          <List className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
}
