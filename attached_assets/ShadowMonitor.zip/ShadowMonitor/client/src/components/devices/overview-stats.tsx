import { Device } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Smartphone, CheckCircle, AlertTriangle, Database } from "lucide-react";

interface OverviewStatsProps {
  devices: Device[];
}

export default function OverviewStats({ devices }: OverviewStatsProps) {
  // Calculate stats
  const totalDevices = devices.length;
  const onlineDevices = devices.filter(device => device.isOnline).length;
  const alertDevices = devices.filter(device => device.status === 'alert').length;
  
  // Calculate total data transferred (placeholder logic)
  const dataTransferred = "1.2 GB";
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <Card className="border-neutral-medium shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center">
            <div className="p-2 rounded-md bg-primary-light/10">
              <Smartphone className="h-5 w-5 text-primary" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-neutral">Total Devices</p>
              <p className="text-xl font-medium text-neutral-darkest">{totalDevices}</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="border-neutral-medium shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center">
            <div className="p-2 rounded-md bg-green-100">
              <CheckCircle className="h-5 w-5 text-green-600" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-neutral">Online</p>
              <p className="text-xl font-medium text-neutral-darkest">{onlineDevices}</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="border-neutral-medium shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center">
            <div className="p-2 rounded-md bg-red-100">
              <AlertTriangle className="h-5 w-5 text-red-600" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-neutral">Alerts</p>
              <p className="text-xl font-medium text-neutral-darkest">{alertDevices}</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="border-neutral-medium shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center">
            <div className="p-2 rounded-md bg-purple-100">
              <Database className="h-5 w-5 text-purple-600" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-neutral">Data Transferred</p>
              <p className="text-xl font-medium text-neutral-darkest">{dataTransferred}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
