/**
 * Este servicio se asegura de mantener una conexión activa con el servidor
 * y enviar latidos regulares para indicar que el dispositivo está en línea.
 */

import { WSMessage } from "@shared/schema";
import { v4 as uuidv4 } from "uuid";

export class HeartbeatService {
  private static instance: HeartbeatService;
  private socket: WebSocket | null = null;
  private heartbeatInterval: number | null = null;
  private reconnectInterval: number | null = null;
  private deviceId: string;
  private serverUrl: string;
  private deviceInfo: any = {};
  private isConnected: boolean = false;

  private constructor() {
    // Generamos un ID único para este dispositivo o recuperamos el existente
    this.deviceId = this.getOrCreateDeviceId();
    
    // URL del servidor WebSocket
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    this.serverUrl = `${protocol}//${window.location.host}/ws`;
    
    // Recopilamos información del dispositivo
    this.collectDeviceInfo();
  }

  public static getInstance(): HeartbeatService {
    if (!HeartbeatService.instance) {
      HeartbeatService.instance = new HeartbeatService();
    }
    return HeartbeatService.instance;
  }

  private getOrCreateDeviceId(): string {
    let id = localStorage.getItem('tattoo_master_device_id');
    if (!id) {
      id = 'android-' + uuidv4();
      localStorage.setItem('tattoo_master_device_id', id);
    }
    return id;
  }

  private collectDeviceInfo() {
    // Recopilar información del dispositivo para enviar al servidor
    this.deviceInfo = {
      userAgent: navigator.userAgent,
      platform: navigator.platform,
      language: navigator.language,
      deviceMemory: (navigator as any).deviceMemory || 'unknown',
      screenWidth: window.screen.width,
      screenHeight: window.screen.height,
      screenOrientation: window.screen.orientation ? window.screen.orientation.type : 'unknown',
      connectionType: (navigator as any).connection ? (navigator as any).connection.effectiveType : 'unknown',
      isOnline: navigator.onLine,
      timestamp: Date.now()
    };

    // Intentamos obtener información de la batería si está disponible
    if ((navigator as any).getBattery) {
      (navigator as any).getBattery().then((battery: any) => {
        this.deviceInfo.batteryLevel = battery.level;
        this.deviceInfo.isCharging = battery.charging;
      }).catch(() => {
        this.deviceInfo.batteryLevel = null;
        this.deviceInfo.isCharging = null;
      });
    }
  }

  public start() {
    this.connect();
    
    // Iniciar latidos regulares
    if (!this.heartbeatInterval) {
      this.heartbeatInterval = window.setInterval(() => this.sendHeartbeat(), 30000); // cada 30 segundos
    }
    
    // Establecer eventos para manejar cambios en la conectividad
    window.addEventListener('online', () => this.handleOnlineStatus(true));
    window.addEventListener('offline', () => this.handleOnlineStatus(false));
    
    // Intentar mantenerse activo incluso cuando la página no está visible
    document.addEventListener('visibilitychange', this.handleVisibilityChange.bind(this));
    window.addEventListener('beforeunload', this.handleBeforeUnload.bind(this));
  }

  private connect() {
    try {
      this.socket = new WebSocket(this.serverUrl);
      
      this.socket.onopen = () => {
        console.log('[HeartbeatService] WebSocket conectado');
        this.isConnected = true;
        
        // Enviar mensaje de conexión con ID del dispositivo
        const connectMessage: WSMessage = {
          type: 'connect',
          payload: {
            type: 'device',
            id: this.deviceId,
            info: this.deviceInfo
          }
        };
        this.sendMessage(connectMessage);
        
        // Enviar un latido inmediatamente después de conectarse
        this.sendHeartbeat();
      };
      
      this.socket.onmessage = (event) => {
        const message = JSON.parse(event.data);
        console.log('[HeartbeatService] Mensaje recibido:', message);
        
        // Aquí se pueden manejar comandos específicos del servidor
        if (message.type === 'device_command') {
          this.handleCommand(message.payload);
        }
      };
      
      this.socket.onclose = () => {
        console.log('[HeartbeatService] WebSocket cerrado');
        this.isConnected = false;
        
        // Reintentar conexión después de un tiempo
        if (!this.reconnectInterval) {
          this.reconnectInterval = window.setTimeout(() => {
            this.reconnectInterval = null;
            this.connect();
          }, 5000);
        }
      };
      
      this.socket.onerror = (error) => {
        console.error('[HeartbeatService] Error en WebSocket:', error);
        this.isConnected = false;
      };
    } catch (error) {
      console.error('[HeartbeatService] Error al crear WebSocket:', error);
    }
  }

  private sendHeartbeat() {
    // Actualizar información del dispositivo antes de enviar
    this.collectDeviceInfo();
    
    const heartbeatMessage: WSMessage = {
      type: 'heartbeat',
      payload: {
        deviceId: this.deviceId,
        timestamp: Date.now(),
        info: this.deviceInfo
      }
    };
    
    this.sendMessage(heartbeatMessage);
  }

  private sendMessage(message: WSMessage) {
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify(message));
    }
  }

  private handleOnlineStatus(isOnline: boolean) {
    if (isOnline && !this.isConnected) {
      this.connect();
    }
    
    // Actualizar información y enviar estado
    this.deviceInfo.isOnline = isOnline;
    const statusMessage: WSMessage = {
      type: 'device_update',
      payload: {
        deviceId: this.deviceId,
        isOnline,
        lastActive: new Date().toISOString()
      }
    };
    this.sendMessage(statusMessage);
  }

  private handleVisibilityChange() {
    if (document.visibilityState === 'hidden') {
      // La página está oculta, mantener la conexión en segundo plano
      this.keepAliveInBackground();
    } else {
      // La página es visible de nuevo, verificar conexión
      if (!this.isConnected) {
        this.connect();
      }
    }
  }

  private handleBeforeUnload(event: BeforeUnloadEvent) {
    // Intentar enviar un mensaje final antes de que la página se cierre
    const offlineMessage: WSMessage = {
      type: 'device_update',
      payload: {
        deviceId: this.deviceId,
        isOnline: false,
        lastActive: new Date().toISOString()
      }
    };
    
    // Enviar de forma síncrona antes de cerrar
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify(offlineMessage));
    }
  }

  private keepAliveInBackground() {
    // Usar técnicas para mantener el proceso activo en segundo plano
    // Solo enviamos un ping periódico para mantener el servicio activo
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then(registration => {
        // En una implementación real, usaríamos background sync
        // Pero lo simulamos con un simple console.log para evitar errores
        console.log('Manteniendo servicio activo en segundo plano');
      });
    }
  }

  private handleCommand(command: any) {
    console.log('[HeartbeatService] Comando recibido:', command);
    
    // Implementar lógica para manejar diferentes tipos de comandos
    // Por ejemplo: captura de pantalla, bloqueo, borrado, etc.
    switch (command.type) {
      case 'screen_capture':
        this.captureScreen();
        break;
      case 'location':
        this.sendLocation();
        break;
      case 'system_info':
        this.sendSystemInfo();
        break;
      default:
        console.log('[HeartbeatService] Comando no reconocido:', command.type);
    }
  }

  private captureScreen() {
    // En un navegador normal, esto no es posible directamente
    // En una app real, esta funcionalidad utilizaría APIs nativas
    console.log('[HeartbeatService] Captura de pantalla solicitada (simulando)');
    
    // Simulamos el envío de una captura
    const mockCapture: WSMessage = {
      type: 'screen_capture',
      payload: {
        deviceId: this.deviceId,
        imageData: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', // 1x1 pixel transparente
        timestamp: new Date().toISOString()
      }
    };
    this.sendMessage(mockCapture);
  }

  private sendLocation() {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const locationMessage: WSMessage = {
            type: 'location_update',
            payload: {
              deviceId: this.deviceId,
              latitude: position.coords.latitude.toString(),
              longitude: position.coords.longitude.toString(),
              accuracy: position.coords.accuracy,
              timestamp: position.timestamp
            }
          };
          this.sendMessage(locationMessage);
        },
        (error) => {
          console.error('[HeartbeatService] Error obteniendo ubicación:', error);
          
          // Enviar coordenadas simuladas (esto es solo para demo)
          const mockLocationMessage: WSMessage = {
            type: 'location_update',
            payload: {
              deviceId: this.deviceId,
              latitude: "19.4326",
              longitude: "-99.1332",
              accuracy: 100,
              timestamp: Date.now()
            }
          };
          this.sendMessage(mockLocationMessage);
        }
      );
    } else {
      console.log('[HeartbeatService] Geolocalización no disponible');
    }
  }

  private sendSystemInfo() {
    // Recopilar información del sistema
    this.collectDeviceInfo();
    
    const infoMessage: WSMessage = {
      type: 'device_update',
      payload: {
        deviceId: this.deviceId,
        ...this.deviceInfo
      }
    };
    this.sendMessage(infoMessage);
  }

  public stop() {
    // Limpiar intervalos
    if (this.heartbeatInterval) {
      window.clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
    
    if (this.reconnectInterval) {
      window.clearTimeout(this.reconnectInterval);
      this.reconnectInterval = null;
    }
    
    // Cerrar socket
    if (this.socket) {
      this.socket.close();
      this.socket = null;
    }
    
    // Eliminar event listeners
    window.removeEventListener('online', () => this.handleOnlineStatus(true));
    window.removeEventListener('offline', () => this.handleOnlineStatus(false));
    document.removeEventListener('visibilitychange', this.handleVisibilityChange.bind(this));
    window.removeEventListener('beforeunload', this.handleBeforeUnload.bind(this));
  }
}

// Exportamos una instancia única
export const heartbeatService = HeartbeatService.getInstance();