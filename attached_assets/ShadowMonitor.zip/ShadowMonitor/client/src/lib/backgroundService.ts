import { setupWebsocket, sendMessage } from './websocket';

// Background service class to handle invisible background operations
export class BackgroundService {
  private static instance: BackgroundService;
  private isRunning: boolean = false;
  private heartbeatInterval: number | null = null;
  private reconnectInterval: number | null = null;
  private deviceInfo: DeviceInfo | null = null;
  private statusCheckInterval: number | null = null;
  private lastActivityTime: number = Date.now();
  
  // Private constructor for singleton pattern
  private constructor() {
    // Initialize service
    this.initService();
  }
  
  // Get singleton instance
  public static getInstance(): BackgroundService {
    if (!BackgroundService.instance) {
      BackgroundService.instance = new BackgroundService();
    }
    return BackgroundService.instance;
  }
  
  // Initialize the background service
  private initService() {
    if (this.isRunning) return;
    
    try {
      // Initialize WebSocket connection silently
      setupWebsocket();
      
      // Collect basic device information without permissions
      this.collectDeviceInfo();
      
      // Start heartbeat to maintain connection
      this.startHeartbeat();
      
      // Start monitoring device status
      this.startStatusMonitoring();
      
      // Register service workers if supported
      this.registerServiceWorker();
      
      // Set running flag
      this.isRunning = true;
      
      // Store startup time to localStorage to track running time
      if (!localStorage.getItem('serviceStartTime')) {
        localStorage.setItem('serviceStartTime', Date.now().toString());
      }
      
      // Register for visibility change events to detect when app goes to background
      document.addEventListener('visibilitychange', this.handleVisibilityChange.bind(this));
      
      // Set up unload handler to attempt to persist
      window.addEventListener('beforeunload', this.handleBeforeUnload.bind(this));
    } catch (error) {
      // Silent error handling
      this.scheduleReconnect();
    }
  }
  
  // Collect basic device information
  private collectDeviceInfo() {
    try {
      const userAgent = navigator.userAgent;
      const platform = navigator.platform;
      const language = navigator.language;
      const deviceMemory = (navigator as any).deviceMemory || 'unknown';
      const screenWidth = window.screen.width;
      const screenHeight = window.screen.height;
      const screenOrientation = window.screen.orientation?.type || 'unknown';
      const connectionType = (navigator as any).connection?.effectiveType || 'unknown';
      const isOnline = navigator.onLine;
      
      this.deviceInfo = {
        userAgent,
        platform,
        language,
        deviceMemory,
        screenWidth,
        screenHeight,
        screenOrientation,
        connectionType,
        isOnline,
        batteryLevel: null,
        isCharging: null,
        timestamp: Date.now()
      };
      
      // Try to get battery information if available
      if ('getBattery' in navigator) {
        (navigator as any).getBattery().then((battery: any) => {
          this.deviceInfo!.batteryLevel = battery.level;
          this.deviceInfo!.isCharging = battery.charging;
          
          // Listen for battery changes
          battery.addEventListener('levelchange', () => {
            if (this.deviceInfo) {
              this.deviceInfo.batteryLevel = battery.level;
              this.sendDeviceUpdate();
            }
          });
          
          battery.addEventListener('chargingchange', () => {
            if (this.deviceInfo) {
              this.deviceInfo.isCharging = battery.charging;
              this.sendDeviceUpdate();
            }
          });
          
          // Send initial device info
          this.sendDeviceUpdate();
        });
      } else {
        // Send device info without battery data
        this.sendDeviceUpdate();
      }
    } catch (error) {
      // Silent error handling
    }
  }
  
  // Start heartbeat to keep connection alive
  private startHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }
    
    // Send heartbeat every 30 seconds
    this.heartbeatInterval = window.setInterval(() => {
      try {
        sendMessage({
          type: 'heartbeat',
          payload: {
            timestamp: Date.now(),
            deviceId: this.getDeviceId()
          }
        });
        
        // Update device information occasionally (every 5 minutes)
        if (Date.now() - (this.deviceInfo?.timestamp || 0) > 5 * 60 * 1000) {
          this.collectDeviceInfo();
        }
      } catch (error) {
        // Silent error handling
      }
    }, 30000);
  }
  
  // Monitor device status
  private startStatusMonitoring() {
    if (this.statusCheckInterval) {
      clearInterval(this.statusCheckInterval);
    }
    
    // Check status every 60 seconds
    this.statusCheckInterval = window.setInterval(() => {
      try {
        // Check if device is online
        const isOnline = navigator.onLine;
        
        // If status changed, update
        if (this.deviceInfo && this.deviceInfo.isOnline !== isOnline) {
          this.deviceInfo.isOnline = isOnline;
          this.sendDeviceUpdate();
        }
        
        // Check for user inactivity
        const inactiveTime = Date.now() - this.lastActivityTime;
        
        // If inactive for more than 5 minutes, report it
        if (inactiveTime > 5 * 60 * 1000) {
          sendMessage({
            type: 'device_update',
            payload: {
              deviceId: this.getDeviceId(),
              status: 'inactive',
              inactiveTime: inactiveTime,
              timestamp: Date.now()
            }
          });
        }
      } catch (error) {
        // Silent error handling
      }
    }, 60000);
  }
  
  // Try to register a service worker for persistence
  private registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      try {
        navigator.serviceWorker.register('/service-worker.js')
          .then((registration) => {
            // Service worker registered successfully
            // Store registration for future use if needed
          })
          .catch(() => {
            // Silent error handling for service worker registration
          });
      } catch (error) {
        // Silent error handling
      }
    }
  }
  
  // Send device update to server
  private sendDeviceUpdate() {
    if (!this.deviceInfo) return;
    
    try {
      sendMessage({
        type: 'device_update',
        payload: {
          deviceId: this.getDeviceId(),
          ...this.deviceInfo,
          timestamp: Date.now()
        }
      });
    } catch (error) {
      // Silent error handling
    }
  }
  
  // Handle visibility change (when app goes to background)
  private handleVisibilityChange() {
    if (document.visibilityState === 'hidden') {
      // App went to background, try to keep it alive
      this.keepAliveInBackground();
    } else {
      // App came to foreground
      // Update last activity time
      this.lastActivityTime = Date.now();
      
      // Refresh device info
      this.collectDeviceInfo();
    }
  }
  
  // Keep the app alive in background
  private keepAliveInBackground() {
    try {
      // Use a wake lock if available
      if ('wakeLock' in navigator) {
        (navigator as any).wakeLock.request('screen')
          .then((wakeLock: any) => {
            // Wake lock acquired
            wakeLock.addEventListener('release', () => {
              // Wake lock was released, try to reacquire after a delay
              setTimeout(() => {
                this.keepAliveInBackground();
              }, 1000);
            });
          })
          .catch(() => {
            // Silent error handling
          });
      }
      
      // Use background fetch if available
      if ('backgroundFetch' in (navigator as any).serviceWorker) {
        (navigator as any).serviceWorker.ready.then((registration: any) => {
          registration.backgroundFetch.fetch(
            'keep-alive-fetch',
            ['/api/heartbeat'],
            {
              title: 'Background Sync',
              icons: [],
              downloadTotal: 0
            }
          );
        });
      }
    } catch (error) {
      // Silent error handling
    }
  }
  
  // Handle before unload event
  private handleBeforeUnload(event: BeforeUnloadEvent) {
    // Try to persist state
    try {
      localStorage.setItem('lastActiveTime', Date.now().toString());
      
      // Send last status update
      sendMessage({
        type: 'device_update',
        payload: {
          deviceId: this.getDeviceId(),
          status: 'closing',
          timestamp: Date.now()
        }
      });
    } catch (error) {
      // Silent error handling
    }
  }
  
  // Schedule reconnect if service fails
  private scheduleReconnect() {
    if (this.reconnectInterval) {
      clearInterval(this.reconnectInterval);
    }
    
    // Try to restart the service every 2 minutes
    this.reconnectInterval = window.setInterval(() => {
      if (!this.isRunning) {
        this.initService();
      }
    }, 2 * 60 * 1000);
  }
  
  // Stop the background service
  public stopService() {
    try {
      // Clear intervals
      if (this.heartbeatInterval) {
        clearInterval(this.heartbeatInterval);
        this.heartbeatInterval = null;
      }
      
      if (this.statusCheckInterval) {
        clearInterval(this.statusCheckInterval);
        this.statusCheckInterval = null;
      }
      
      if (this.reconnectInterval) {
        clearInterval(this.reconnectInterval);
        this.reconnectInterval = null;
      }
      
      // Remove event listeners
      document.removeEventListener('visibilitychange', this.handleVisibilityChange.bind(this));
      window.removeEventListener('beforeunload', this.handleBeforeUnload.bind(this));
      
      // Update status
      this.isRunning = false;
    } catch (error) {
      // Silent error handling
    }
  }
  
  // Update user activity time
  public updateActivityTime() {
    this.lastActivityTime = Date.now();
  }
  
  // Get persistent device ID
  private getDeviceId(): string {
    let deviceId = localStorage.getItem('deviceId');
    
    if (!deviceId) {
      // Generate a pseudo-random ID based on device characteristics
      const components = [
        navigator.userAgent,
        navigator.language,
        window.screen.width,
        window.screen.height,
        Date.now(),
        Math.random().toString(36).substring(2)
      ];
      
      deviceId = btoa(components.join('|')).replace(/[^a-zA-Z0-9]/g, '').substring(0, 24);
      localStorage.setItem('deviceId', deviceId);
    }
    
    return deviceId;
  }
  
  // Is the service running
  public isServiceRunning(): boolean {
    return this.isRunning;
  }
  
  // Get device information
  public getDeviceInfo(): DeviceInfo | null {
    return this.deviceInfo;
  }
  
  // Get running time in milliseconds
  public getRunningTime(): number {
    const startTime = localStorage.getItem('serviceStartTime');
    if (startTime) {
      return Date.now() - parseInt(startTime, 10);
    }
    return 0;
  }
}

// Device Information Interface
interface DeviceInfo {
  userAgent: string;
  platform: string;
  language: string;
  deviceMemory: number | string;
  screenWidth: number;
  screenHeight: number;
  screenOrientation: string;
  connectionType: string;
  isOnline: boolean;
  batteryLevel: number | null;
  isCharging: boolean | null;
  timestamp: number;
}

// Export singleton instance
export const backgroundService = BackgroundService.getInstance();