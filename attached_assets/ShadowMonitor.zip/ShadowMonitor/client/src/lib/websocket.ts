import { useEffect, useRef, useState } from 'react';
import { WSMessage } from '@shared/schema';

let websocket: WebSocket | null = null;
const messageListeners: ((message: WSMessage) => void)[] = [];
// Flag to track if the connection is currently being established
let connectionInProgress = false;
// Track reconnection attempts
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 20; // Maximum number of reconnect attempts
const INITIAL_RECONNECT_DELAY = 1000; // Start with 1 second
let reconnectDelay = INITIAL_RECONNECT_DELAY;

export function setupWebsocket() {
  // Prevent multiple simultaneous connection attempts
  if (websocket || connectionInProgress) return;
  
  connectionInProgress = true;
  
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}/ws`;
  
  try {
    websocket = new WebSocket(wsUrl);
    
    websocket.onopen = () => {
      // Connection successful - reset reconnect parameters
      reconnectAttempts = 0;
      reconnectDelay = INITIAL_RECONNECT_DELAY;
      connectionInProgress = false;
      
      // Identify as admin silently
      sendMessage({
        type: 'connect',
        payload: {
          type: 'admin',
          id: 'admin-' + Math.random().toString(36).substring(2, 10)
        }
      });
    };
    
    websocket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data) as WSMessage;
        
        // Notify all listeners silently
        messageListeners.forEach(listener => {
          listener(message);
        });
      } catch (error) {
        // Silent error handling
      }
    };
    
    websocket.onclose = () => {
      websocket = null;
      connectionInProgress = false;
      
      // Implement exponential backoff for reconnection attempts
      if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
        reconnectAttempts++;
        // Double the delay with each attempt (with a maximum limit)
        reconnectDelay = Math.min(reconnectDelay * 1.5, 30000); // max 30 seconds
        
        setTimeout(() => {
          setupWebsocket();
        }, reconnectDelay);
      } else {
        // After maximum attempts, try again less frequently
        setTimeout(() => {
          reconnectAttempts = 0;
          reconnectDelay = INITIAL_RECONNECT_DELAY;
          setupWebsocket();
        }, 60000); // Try again after 1 minute
      }
    };
    
    websocket.onerror = () => {
      // Silent error handling
      websocket?.close();
    };
  } catch (e) {
    // Silent error handling for any connection setup errors
    connectionInProgress = false;
    
    // Try to reconnect after a delay
    setTimeout(() => {
      setupWebsocket();
    }, reconnectDelay);
  }
}

export function sendMessage(message: WSMessage) {
  if (websocket && websocket.readyState === WebSocket.OPEN) {
    websocket.send(JSON.stringify(message));
    return true;
  }
  return false;
}

export function useWebsocket<T extends WSMessage>(
  messageType: WSMessage['type'],
  callback: (message: T) => void
) {
  useEffect(() => {
    // Ensure WebSocket is setup
    setupWebsocket();
    
    // Create listener function
    const listener = (message: WSMessage) => {
      if (message.type === messageType) {
        callback(message as T);
      }
    };
    
    // Register listener
    messageListeners.push(listener);
    
    // Clean up listener on unmount
    return () => {
      const index = messageListeners.indexOf(listener);
      if (index !== -1) {
        messageListeners.splice(index, 1);
      }
    };
  }, [messageType, callback]);
}

export function useWebsocketStatus() {
  const [isConnected, setIsConnected] = useState(false);
  const checkIntervalRef = useRef<number | null>(null);
  
  useEffect(() => {
    // Initial setup
    setupWebsocket();
    
    // Check connection status
    const checkConnection = () => {
      const connected = websocket && websocket.readyState === WebSocket.OPEN;
      setIsConnected(!!connected);
    };
    
    // Initial check
    checkConnection();
    
    // Setup interval to check connection status
    checkIntervalRef.current = window.setInterval(checkConnection, 2000);
    
    return () => {
      if (checkIntervalRef.current) {
        clearInterval(checkIntervalRef.current);
      }
    };
  }, []);
  
  return isConnected;
}
