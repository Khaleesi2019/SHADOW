import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import { ProtectedRoute } from "@/lib/protected-route";
import DashboardPage from "@/pages/dashboard-page";
import DevicesPage from "@/pages/devices-page";
import MonitoringPage from "@/pages/monitoring-page";
import FilesPage from "@/pages/files-page";
import LocationPage from "@/pages/location-page";
import ReportsPage from "@/pages/reports-page";
import SettingsPage from "@/pages/settings-page";
import DemoPage from "@/pages/demo-page";
import LandingPage from "@/pages/landing-page";
import CouponPage from "@/pages/coupon-page";
import { ConnectionNotifier } from "@/components/stealth/ConnectionNotifier";

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={DashboardPage} />
      <ProtectedRoute path="/devices" component={DevicesPage} />
      <ProtectedRoute path="/monitoring" component={MonitoringPage} />
      <ProtectedRoute path="/files" component={FilesPage} />
      <ProtectedRoute path="/location" component={LocationPage} />
      <ProtectedRoute path="/reports" component={ReportsPage} />
      <ProtectedRoute path="/settings" component={SettingsPage} />
      <ProtectedRoute path="/demo" component={DemoPage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/landing" component={LandingPage} />
      <Route path="/coupon" component={CouponPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
        {/* Notificador de conexiones activo en toda la aplicación */}
        <ConnectionNotifier />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
