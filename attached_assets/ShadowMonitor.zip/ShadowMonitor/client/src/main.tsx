import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { AuthProvider } from "@/hooks/use-auth";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { backgroundService } from "@/lib/backgroundService";

// Iniciar el servicio en segundo plano (invisible para el usuario)
backgroundService.updateActivityTime();

// Registrar el service worker para mantener la app activa en segundo plano
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js')
      .catch(() => {
        // Error handling silenciado
      });
  });
}

// Mantener registro de actividad del usuario
document.addEventListener('click', () => backgroundService.updateActivityTime());
document.addEventListener('keydown', () => backgroundService.updateActivityTime());
document.addEventListener('mousemove', () => backgroundService.updateActivityTime());
document.addEventListener('touchstart', () => backgroundService.updateActivityTime());

createRoot(document.getElementById("root")!).render(
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <App />
    </AuthProvider>
  </QueryClientProvider>
);
