import { useState, useEffect } from "react";
import MainLayout from "@/components/layout/main-layout";
import { useDevices } from "@/hooks/use-devices";
import { setupWebsocket } from "@/lib/websocket";
import { useWebsocket } from "@/lib/websocket";
import { Device } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  MapPin, 
  Locate, 
  RefreshCw, 
  AlertCircle, 
  CheckCircle, 
  Clock, 
  Search, 
  Smartphone,
  FileWarning,
  Home,
  Building,
  Factory,
  MapPinned
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface GeofenceArea {
  id: string;
  name: string;
  type: 'home' | 'office' | 'warehouse' | 'custom';
  radius: number; // in meters
  center: {
    lat: number;
    lng: number;
  };
}

const sampleGeofences: GeofenceArea[] = [
  {
    id: '1',
    name: 'Office Headquarters',
    type: 'office',
    radius: 200,
    center: { lat: 37.7749, lng: -122.4194 }
  },
  {
    id: '2',
    name: 'Warehouse District',
    type: 'warehouse',
    radius: 500,
    center: { lat: 37.7833, lng: -122.4167 }
  },
  {
    id: '3',
    name: 'Sales Department',
    type: 'office',
    radius: 150,
    center: { lat: 37.7900, lng: -122.4100 }
  }
];

export default function LocationPage() {
  const { devices, isLoading, sendCommand } = useDevices();
  const { toast } = useToast();
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [activeTab, setActiveTab] = useState("map");
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredDevices, setFilteredDevices] = useState<Device[]>([]);
  const [geofences, setGeofences] = useState<GeofenceArea[]>(sampleGeofences);
  const [selectedGeofence, setSelectedGeofence] = useState<string>('');
  const [trackingEnabled, setTrackingEnabled] = useState(false);
  const [locationUpdateFrequency, setLocationUpdateFrequency] = useState('normal');
  
  // Setup WebSocket connection
  useEffect(() => {
    setupWebsocket();
  }, []);
  
  // Filter devices based on search query
  useEffect(() => {
    const filtered = devices.filter(device => 
      device.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      device.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (device.department && device.department.toLowerCase().includes(searchQuery.toLowerCase()))
    );
    setFilteredDevices(filtered);
  }, [devices, searchQuery]);
  
  // Listen for location updates
  useWebsocket('location_update', (message: any) => {
    if (selectedDevice && message.payload.deviceId === selectedDevice.deviceId) {
      toast({
        title: "Location Updated",
        description: `Device location has been updated.`
      });
    }
  });
  
  const handleDeviceSelect = (deviceId: number) => {
    const device = devices.find(d => d.id === Number(deviceId)) || null;
    setSelectedDevice(device);
    setTrackingEnabled(false);
  };
  
  const handleRequestLocation = () => {
    if (!selectedDevice) return;
    
    sendCommand({
      deviceId: selectedDevice.deviceId,
      command: { type: 'request_location' }
    });
    
    toast({
      title: "Location Requested",
      description: "Requesting current device location..."
    });
  };
  
  const handleStartTracking = () => {
    if (!selectedDevice) return;
    
    sendCommand({
      deviceId: selectedDevice.deviceId,
      command: { 
        type: 'start_location_tracking',
        frequency: locationUpdateFrequency
      }
    });
    
    setTrackingEnabled(true);
    
    toast({
      title: "Location Tracking Started",
      description: `Tracking frequency: ${locationUpdateFrequency}`
    });
  };
  
  const handleStopTracking = () => {
    if (!selectedDevice) return;
    
    sendCommand({
      deviceId: selectedDevice.deviceId,
      command: { type: 'stop_location_tracking' }
    });
    
    setTrackingEnabled(false);
    
    toast({
      title: "Location Tracking Stopped",
      description: "Device location tracking has been disabled"
    });
  };
  
  const handleSetGeofence = () => {
    if (!selectedDevice || !selectedGeofence) return;
    
    const geofence = geofences.find(g => g.id === selectedGeofence);
    if (!geofence) return;
    
    sendCommand({
      deviceId: selectedDevice.deviceId,
      command: { 
        type: 'set_geofence',
        geofence: {
          id: geofence.id,
          name: geofence.name,
          radius: geofence.radius,
          center: geofence.center
        }
      }
    });
    
    toast({
      title: "Geofence Applied",
      description: `${geofence.name} has been applied to this device`
    });
  };
  
  const getGeofenceIcon = (type: string) => {
    switch (type) {
      case 'home':
        return <Home className="h-4 w-4" />;
      case 'office':
        return <Building className="h-4 w-4" />;
      case 'warehouse':
        return <Factory className="h-4 w-4" />;
      default:
        return <MapPinned className="h-4 w-4" />;
    }
  };
  
  return (
    <MainLayout title="Location Tracking">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Device selection sidebar */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">Select Device</CardTitle>
            <CardDescription>Choose a device to track location</CardDescription>
            
            <div className="relative mt-2">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral" />
              <Input 
                placeholder="Search devices..." 
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </CardHeader>
          
          <CardContent className="space-y-4">
            {filteredDevices.length > 0 ? (
              filteredDevices.map((device) => (
                <Card 
                  key={device.id}
                  className={`cursor-pointer hover:bg-neutral-light transition-all ${selectedDevice?.id === device.id ? 'border-primary' : 'border-neutral-medium'}`}
                  onClick={() => handleDeviceSelect(device.id)}
                >
                  <CardContent className="p-3 flex justify-between items-center">
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary mr-3">
                        <Smartphone className="h-4 w-4" />
                      </div>
                      <div>
                        <p className="font-medium">{device.name}</p>
                        <p className="text-xs text-neutral-dark">{device.user}</p>
                      </div>
                    </div>
                    
                    <div>
                      {!device.isOnline ? (
                        <Badge variant="outline" className="flex items-center">Offline</Badge>
                      ) : device.latitude && device.longitude ? (
                        <Badge variant="default" className="bg-green-600 flex items-center">
                          <MapPin className="h-3 w-3 mr-1" />
                          Located
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="flex items-center">
                          <FileWarning className="h-3 w-3 mr-1" />
                          No Location
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center py-8">
                <AlertCircle className="h-12 w-12 mx-auto text-neutral mb-2" />
                <p className="text-neutral-dark">No devices match your search</p>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Location tracking area */}
        <Card className="lg:col-span-2">
          {!selectedDevice ? (
            <div className="flex flex-col items-center justify-center h-[60vh]">
              <MapPin className="h-20 w-20 text-neutral-light mb-4" />
              <h3 className="text-xl font-medium text-neutral-dark">Select a device to track</h3>
              <p className="text-neutral mt-2">Choose a device from the list on the left</p>
            </div>
          ) : !selectedDevice.isOnline ? (
            <div className="flex flex-col items-center justify-center h-[60vh]">
              <AlertCircle className="h-20 w-20 text-red-200 mb-4" />
              <h3 className="text-xl font-medium text-neutral-dark">Device is offline</h3>
              <p className="text-neutral mt-2">Location tracking is unavailable when the device is offline</p>
            </div>
          ) : (
            <>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg flex items-center">
                      <Smartphone className="h-5 w-5 mr-2 text-primary" />
                      {selectedDevice.name}
                    </CardTitle>
                    <CardDescription>{selectedDevice.user}{selectedDevice.department ? ` - ${selectedDevice.department}` : ''}</CardDescription>
                  </div>
                  
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleRequestLocation}
                  >
                    <Locate className="h-4 w-4 mr-1" />
                    Get Current Location
                  </Button>
                </div>
              </CardHeader>
              
              <Tabs 
                value={activeTab} 
                onValueChange={setActiveTab}
                className="flex-1"
              >
                <div className="px-6">
                  <TabsList className="grid grid-cols-3 w-full">
                    <TabsTrigger value="map">Map View</TabsTrigger>
                    <TabsTrigger value="tracking">Tracking Settings</TabsTrigger>
                    <TabsTrigger value="geofence">Geofence</TabsTrigger>
                  </TabsList>
                </div>
                
                <TabsContent value="map" className="m-0 p-4">
                  <div className="bg-neutral-light h-[400px] rounded-lg flex items-center justify-center">
                    {selectedDevice.latitude && selectedDevice.longitude ? (
                      <div className="text-center">
                        <div className="inline-block bg-white p-4 rounded-lg shadow-sm">
                          <p className="text-lg font-medium mb-2">Device Location</p>
                          <p className="mb-1">Latitude: {selectedDevice.latitude}</p>
                          <p className="mb-1">Longitude: {selectedDevice.longitude}</p>
                          <p className="text-sm text-neutral-dark flex items-center justify-center mt-2">
                            <Clock className="h-4 w-4 mr-1" />
                            Last update: {selectedDevice.lastActive ? new Date(selectedDevice.lastActive).toLocaleString() : 'Unknown'}
                          </p>
                        </div>
                        
                        <p className="mt-4 text-neutral-dark">
                          Interactive map would be displayed here
                        </p>
                      </div>
                    ) : (
                      <div className="text-center">
                        <MapPin className="h-12 w-12 mx-auto text-neutral-dark mb-2" />
                        <p className="font-medium mb-2">No location data available</p>
                        <Button 
                          variant="default" 
                          size="sm"
                          onClick={handleRequestLocation}
                        >
                          <Locate className="h-4 w-4 mr-1" />
                          Request Location
                        </Button>
                      </div>
                    )}
                  </div>
                </TabsContent>
                
                <TabsContent value="tracking" className="m-0 p-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Location Tracking Settings</CardTitle>
                      <CardDescription>Configure how location data is collected</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">Location Tracking</h3>
                          <p className="text-sm text-neutral-dark">Continuously track device location</p>
                        </div>
                        <Switch 
                          checked={trackingEnabled} 
                          onCheckedChange={(checked) => {
                            if (checked) {
                              handleStartTracking();
                            } else {
                              handleStopTracking();
                            }
                          }} 
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="frequency">Update Frequency</Label>
                        <Select 
                          value={locationUpdateFrequency} 
                          onValueChange={setLocationUpdateFrequency}
                          disabled={trackingEnabled}
                        >
                          <SelectTrigger id="frequency">
                            <SelectValue placeholder="Select frequency" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Low (Battery Saving) - Every 30 min</SelectItem>
                            <SelectItem value="normal">Normal - Every 10 min</SelectItem>
                            <SelectItem value="high">High - Every 5 min</SelectItem>
                            <SelectItem value="realtime">Real-time - Every 1 min</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="accuracy">Location Accuracy</Label>
                        <Select defaultValue="balanced" disabled={trackingEnabled}>
                          <SelectTrigger id="accuracy">
                            <SelectValue placeholder="Select accuracy" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Low Accuracy (Battery Saving)</SelectItem>
                            <SelectItem value="balanced">Balanced</SelectItem>
                            <SelectItem value="high">High Accuracy</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </CardContent>
                    <CardFooter className="border-t border-neutral-medium pt-4 flex justify-between">
                      <p className="text-sm text-neutral-dark">
                        {trackingEnabled ? (
                          <span className="flex items-center">
                            <CheckCircle className="h-4 w-4 mr-1 text-green-600" />
                            Tracking active
                          </span>
                        ) : (
                          <span className="flex items-center">
                            <AlertCircle className="h-4 w-4 mr-1 text-orange-500" />
                            Tracking disabled
                          </span>
                        )}
                      </p>
                      
                      {trackingEnabled ? (
                        <Button 
                          variant="destructive" 
                          size="sm"
                          onClick={handleStopTracking}
                        >
                          Stop Tracking
                        </Button>
                      ) : (
                        <Button 
                          variant="default" 
                          size="sm"
                          onClick={handleStartTracking}
                        >
                          Start Tracking
                        </Button>
                      )}
                    </CardFooter>
                  </Card>
                </TabsContent>
                
                <TabsContent value="geofence" className="m-0 p-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Geofence Settings</CardTitle>
                      <CardDescription>Set up allowed areas for this device</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="space-y-2">
                        <Label htmlFor="geofence">Select Geofence Area</Label>
                        <Select 
                          value={selectedGeofence} 
                          onValueChange={setSelectedGeofence}
                        >
                          <SelectTrigger id="geofence">
                            <SelectValue placeholder="Select a geofence area" />
                          </SelectTrigger>
                          <SelectContent>
                            {geofences.map(geofence => (
                              <SelectItem key={geofence.id} value={geofence.id}>
                                <div className="flex items-center">
                                  {getGeofenceIcon(geofence.type)}
                                  <span className="ml-2">{geofence.name}</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      {selectedGeofence && (
                        <Card className="border-dashed">
                          <CardContent className="p-4">
                            <div className="space-y-3">
                              {(() => {
                                const geofence = geofences.find(g => g.id === selectedGeofence);
                                if (!geofence) return null;
                                
                                return (
                                  <>
                                    <div className="flex justify-between">
                                      <span className="text-sm text-neutral-dark">Area:</span>
                                      <span className="text-sm font-medium">{geofence.name}</span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span className="text-sm text-neutral-dark">Type:</span>
                                      <span className="text-sm font-medium flex items-center">
                                        {getGeofenceIcon(geofence.type)}
                                        <span className="ml-1">{geofence.type.charAt(0).toUpperCase() + geofence.type.slice(1)}</span>
                                      </span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span className="text-sm text-neutral-dark">Radius:</span>
                                      <span className="text-sm font-medium">{geofence.radius} meters</span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span className="text-sm text-neutral-dark">Coordinates:</span>
                                      <span className="text-sm font-medium">{geofence.center.lat.toFixed(6)}, {geofence.center.lng.toFixed(6)}</span>
                                    </div>
                                  </>
                                );
                              })()}
                            </div>
                          </CardContent>
                        </Card>
                      )}
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">Alert on Exit</h3>
                          <p className="text-sm text-neutral-dark">Notify when device leaves geofence</p>
                        </div>
                        <Switch defaultChecked={true} />
                      </div>
                    </CardContent>
                    <CardFooter className="border-t border-neutral-medium pt-4 flex justify-end space-x-2">
                      <Button variant="outline">Cancel</Button>
                      <Button 
                        variant="default"
                        onClick={handleSetGeofence}
                        disabled={!selectedGeofence}
                      >
                        Apply Geofence
                      </Button>
                    </CardFooter>
                  </Card>
                </TabsContent>
              </Tabs>
              
              <CardFooter className="border-t border-neutral-medium mt-4 pt-4 flex justify-between">
                <div className="text-sm text-neutral-dark flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  Last update: {selectedDevice.lastActive ? new Date(selectedDevice.lastActive).toLocaleString() : 'Unknown'}
                </div>
                
                <Button 
                  variant="default" 
                  size="sm"
                  onClick={handleRequestLocation}
                >
                  <RefreshCw className="h-4 w-4 mr-1" />
                  Update Location
                </Button>
              </CardFooter>
            </>
          )}
        </Card>
      </div>
    </MainLayout>
  );
}
