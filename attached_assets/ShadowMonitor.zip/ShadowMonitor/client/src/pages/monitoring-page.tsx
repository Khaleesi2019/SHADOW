import { useState, useEffect } from "react";
import MainLayout from "@/components/layout/main-layout";
import { useDevices } from "@/hooks/use-devices";
import { setupWebsocket } from "@/lib/websocket";
import { useWebsocket } from "@/lib/websocket";
import { Device } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { 
  RefreshCw, 
  Monitor, 
  Search, 
  Clock, 
  PlayCircle, 
  StopCircle, 
  Smartphone, 
  AlertTriangle, 
  CheckCircle, 
  Lock, 
  UserCheck, 
  Battery, 
  BatteryCharging, 
  BatteryFull, 
  BatteryMedium, 
  BatteryLow, 
  Wifi, 
  WifiOff, 
  X 
} from "lucide-react";

export default function MonitoringPage() {
  const { devices, isLoading, sendCommand } = useDevices();
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [monitoringActive, setMonitoringActive] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("realtime");
  const [screenData, setScreenData] = useState<string | null>(null);
  const [screenUpdateTime, setScreenUpdateTime] = useState<Date | null>(null);
  const [filteredDevices, setFilteredDevices] = useState<Device[]>([]);
  
  // Setup WebSocket connection
  useEffect(() => {
    setupWebsocket();
  }, []);
  
  // Filter devices based on search query
  useEffect(() => {
    const filtered = devices.filter(device => 
      device.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      device.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (device.department && device.department.toLowerCase().includes(searchQuery.toLowerCase()))
    );
    setFilteredDevices(filtered);
  }, [devices, searchQuery]);
  
  // Subscribe to screen capture updates
  useWebsocket('screen_capture', (message: any) => {
    if (selectedDevice && message.payload.deviceId === selectedDevice.deviceId) {
      setScreenData(message.payload.imageData);
      setScreenUpdateTime(new Date());
    }
  });
  
  const handleStartMonitoring = () => {
    if (!selectedDevice) return;
    
    sendCommand({
      deviceId: selectedDevice.deviceId,
      command: { type: 'start_monitoring' }
    });
    
    // Request initial screen capture
    sendCommand({
      deviceId: selectedDevice.deviceId,
      command: { type: 'screen_capture', requestId: Date.now() }
    });
    
    setMonitoringActive(true);
  };
  
  const handleStopMonitoring = () => {
    if (!selectedDevice) return;
    
    sendCommand({
      deviceId: selectedDevice.deviceId,
      command: { type: 'stop_monitoring' }
    });
    
    setMonitoringActive(false);
  };
  
  const handleRefreshScreen = () => {
    if (!selectedDevice) return;
    
    sendCommand({
      deviceId: selectedDevice.deviceId,
      command: { type: 'screen_capture', requestId: Date.now() }
    });
  };
  
  const handleLockDevice = () => {
    if (!selectedDevice) return;
    
    sendCommand({
      deviceId: selectedDevice.deviceId,
      command: { type: 'lock_device' }
    });
  };
  
  const handleDeviceSelect = (deviceId: number) => {
    const device = devices.find(d => d.id === Number(deviceId)) || null;
    setSelectedDevice(device);
    
    // Reset monitoring state when changing devices
    setMonitoringActive(false);
    setScreenData(null);
    setScreenUpdateTime(null);
  };
  
  // Format date to readable string
  const formatDate = (date: Date | null): string => {
    if (!date) return 'Never';
    return date.toLocaleTimeString();
  };
  
  return (
    <MainLayout title="Device Monitoring">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Device selection sidebar */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">Available Devices</CardTitle>
            <CardDescription>Select a device to monitor</CardDescription>
            
            <div className="relative mt-2">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral" />
              <Input 
                placeholder="Search devices..." 
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </CardHeader>
          
          <CardContent className="p-0">
            <ScrollArea className="h-[60vh]">
              <div className="px-4 py-2">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Device</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredDevices.length > 0 ? (
                      filteredDevices.map((device) => (
                        <TableRow 
                          key={device.id}
                          className={`cursor-pointer hover:bg-neutral-light ${selectedDevice?.id === device.id ? 'bg-primary-light/10' : ''}`}
                          onClick={() => handleDeviceSelect(device.id)}
                        >
                          <TableCell className="py-2">
                            <div className="flex flex-col">
                              <span className="font-medium">{device.name}</span>
                              <span className="text-xs text-neutral-dark">{device.user}</span>
                            </div>
                          </TableCell>
                          <TableCell className="py-2">
                            {device.status === 'alert' ? (
                              <Badge variant="destructive" className="flex items-center">
                                <AlertTriangle className="h-3 w-3 mr-1" />
                                Alert
                              </Badge>
                            ) : device.isOnline ? (
                              <Badge variant="default" className="bg-green-600 flex items-center">
                                <CheckCircle className="h-3 w-3 mr-1" />
                                Online
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="flex items-center">
                                <WifiOff className="h-3 w-3 mr-1" />
                                Offline
                              </Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={2} className="text-center py-4 text-neutral-dark">
                          No devices match your search
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
        
        {/* Monitoring area */}
        <Card className="lg:col-span-2">
          {!selectedDevice ? (
            <div className="flex flex-col items-center justify-center h-[60vh]">
              <Monitor className="h-20 w-20 text-neutral-light mb-4" />
              <h3 className="text-xl font-medium text-neutral-dark">Select a device to start monitoring</h3>
              <p className="text-neutral mt-2">Choose a device from the list on the left</p>
            </div>
          ) : (
            <>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle className="text-lg flex items-center">
                    <Smartphone className="h-5 w-5 mr-2 text-primary" />
                    {selectedDevice.name}
                    {selectedDevice.status === 'alert' && (
                      <Badge variant="destructive" className="ml-2">
                        Alert
                      </Badge>
                    )}
                  </CardTitle>
                  <CardDescription>{selectedDevice.user}{selectedDevice.department ? ` - ${selectedDevice.department}` : ''}</CardDescription>
                </div>
                
                <div className="flex items-center space-x-2">
                  {!selectedDevice.isOnline ? (
                    <Badge variant="outline" className="flex items-center">
                      <WifiOff className="h-3 w-3 mr-1" />
                      Offline
                    </Badge>
                  ) : monitoringActive ? (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="text-red-600"
                      onClick={handleStopMonitoring}
                    >
                      <StopCircle className="h-4 w-4 mr-1" />
                      Stop Monitoring
                    </Button>
                  ) : (
                    <Button 
                      variant="default" 
                      size="sm"
                      onClick={handleStartMonitoring}
                    >
                      <PlayCircle className="h-4 w-4 mr-1" />
                      Start Monitoring
                    </Button>
                  )}
                </div>
              </CardHeader>
              
              <Tabs 
                value={activeTab} 
                onValueChange={setActiveTab}
                className="flex-1"
              >
                <div className="px-6">
                  <TabsList className="grid grid-cols-3 w-full">
                    <TabsTrigger value="realtime">Real-time View</TabsTrigger>
                    <TabsTrigger value="details">Device Details</TabsTrigger>
                    <TabsTrigger value="controls">Controls</TabsTrigger>
                  </TabsList>
                </div>
                
                <TabsContent value="realtime" className="m-0">
                  <div className="p-4 flex flex-col items-center justify-center bg-neutral-darkest min-h-[400px]">
                    {/* Phone mockup */}
                    <div className="relative max-w-[300px] mx-auto">
                      <div className="w-[300px] h-[600px] bg-black rounded-[36px] p-3 shadow-xl relative overflow-hidden">
                        <div className="absolute top-0 left-0 right-0 h-10 bg-black rounded-t-[36px] flex justify-center items-end pb-1">
                          <div className="w-32 h-6 bg-black rounded-b-xl"></div>
                        </div>
                        
                        {/* Phone screen content */}
                        <div className="w-full h-full rounded-[30px] bg-white overflow-hidden relative">
                          {screenData ? (
                            <img 
                              src={screenData} 
                              alt="Device screen" 
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="flex items-center justify-center h-full bg-neutral-light flex-col">
                              <Monitor className="h-16 w-16 text-neutral mb-4" />
                              {selectedDevice.isOnline ? (
                                <p className="text-center text-neutral-dark px-8">
                                  {monitoringActive ? 
                                    "Waiting for screen data..." : 
                                    "Click 'Start Monitoring' to view the device screen"}
                                </p>
                              ) : (
                                <p className="text-center text-neutral-dark px-8">
                                  Device is offline. Cannot access screen.
                                </p>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex gap-4 justify-center">
                      <div className="text-white text-sm flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        Last update: {formatDate(screenUpdateTime)}
                      </div>
                      
                      <Button 
                        variant="outline" 
                        className="bg-white"
                        onClick={handleRefreshScreen}
                        disabled={!selectedDevice.isOnline || !monitoringActive}
                      >
                        <RefreshCw className="h-4 w-4 mr-2" />
                        Refresh
                      </Button>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="details" className="m-0 p-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-4">
                      <div className="bg-neutral-light p-4 rounded-lg">
                        <h3 className="font-medium mb-2">Device Information</h3>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-neutral-dark">Model:</span>
                            <span className="font-medium">{selectedDevice.model}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-neutral-dark">OS Version:</span>
                            <span className="font-medium">{selectedDevice.osVersion}</span>
                          </div>
                          {selectedDevice.imei && (
                            <div className="flex justify-between">
                              <span className="text-neutral-dark">IMEI:</span>
                              <span className="font-medium">{selectedDevice.imei}</span>
                            </div>
                          )}
                          <div className="flex justify-between">
                            <span className="text-neutral-dark">Last IP:</span>
                            <span className="font-medium">{selectedDevice.lastIpAddress || 'Unknown'}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-neutral-light p-4 rounded-lg">
                        <h3 className="font-medium mb-2">Status</h3>
                        <div className="space-y-2">
                          <div className="flex items-center">
                            {selectedDevice.isOnline ? (
                              <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                            ) : (
                              <X className="h-4 w-4 text-red-600 mr-2" />
                            )}
                            <span>{selectedDevice.isOnline ? 'Online' : 'Offline'}</span>
                          </div>
                          
                          <div className="flex items-center">
                            {selectedDevice.battery !== null && selectedDevice.battery !== undefined ? (
                              <>
                                {selectedDevice.battery <= 20 ? (
                                  <BatteryLow className="h-4 w-4 text-red-600 mr-2" />
                                ) : selectedDevice.battery <= 50 ? (
                                  <BatteryMedium className="h-4 w-4 text-orange-500 mr-2" />
                                ) : (
                                  <BatteryFull className="h-4 w-4 text-green-600 mr-2" />
                                )}
                                <span>Battery: {selectedDevice.battery}%</span>
                              </>
                            ) : (
                              <>
                                <Battery className="h-4 w-4 text-neutral-dark mr-2" />
                                <span>Battery: Unknown</span>
                              </>
                            )}
                          </div>
                          
                          {selectedDevice.storage && (
                            <div className="flex items-center">
                              <div className="flex-1 flex items-center">
                                <span className="mr-2">Storage:</span>
                                <div className="w-full bg-neutral-medium rounded-full h-2">
                                  <div 
                                    className="bg-primary rounded-full h-2" 
                                    style={{ width: `${(selectedDevice.storage.used / selectedDevice.storage.total) * 100}%` }}
                                  ></div>
                                </div>
                                <span className="ml-2 text-sm">
                                  {selectedDevice.storage.used} / {selectedDevice.storage.total} GB
                                </span>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="bg-neutral-light p-4 rounded-lg">
                        <h3 className="font-medium mb-2">User Information</h3>
                        <div className="flex items-center mb-4">
                          <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white">
                            <span>{selectedDevice.user.split(' ').map(n => n[0]).join('').toUpperCase()}</span>
                          </div>
                          <div className="ml-3">
                            <p className="font-medium">{selectedDevice.user}</p>
                            <p className="text-sm text-neutral-dark">{selectedDevice.department || 'No Department'}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center">
                          <UserCheck className="h-4 w-4 mr-2 text-neutral-dark" />
                          <span className="text-sm">Employee verified</span>
                        </div>
                      </div>
                      
                      {selectedDevice.installedApps && selectedDevice.installedApps.length > 0 && (
                        <div className="bg-neutral-light p-4 rounded-lg">
                          <h3 className="font-medium mb-2">Installed Applications</h3>
                          <ScrollArea className="h-[200px]">
                            <div className="space-y-2">
                              {selectedDevice.installedApps.map((app: any, index: number) => (
                                <div key={index} className="flex items-center p-2 bg-white rounded">
                                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary mr-2">
                                    <span>{app.name.charAt(0)}</span>
                                  </div>
                                  <div>
                                    <p className="text-sm font-medium">{app.name}</p>
                                    <p className="text-xs text-neutral-dark">{app.packageName}</p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </ScrollArea>
                        </div>
                      )}
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="controls" className="m-0 p-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="p-4 text-center">
                        <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-primary/10 flex items-center justify-center">
                          <PlayCircle className="h-6 w-6 text-primary" />
                        </div>
                        <h3 className="font-medium mb-1">Remote Control</h3>
                        <p className="text-sm text-neutral-dark mb-4">Take control of the device remotely</p>
                        <Button 
                          className="w-full" 
                          disabled={!selectedDevice.isOnline}
                        >
                          Start Control
                        </Button>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4 text-center">
                        <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-red-100 flex items-center justify-center">
                          <Lock className="h-6 w-6 text-red-600" />
                        </div>
                        <h3 className="font-medium mb-1">Lock Device</h3>
                        <p className="text-sm text-neutral-dark mb-4">Remotely lock the device screen</p>
                        <Button 
                          className="w-full"
                          variant="destructive"
                          onClick={handleLockDevice}
                          disabled={!selectedDevice.isOnline}
                        >
                          Lock Now
                        </Button>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4 text-center">
                        <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-orange-100 flex items-center justify-center">
                          <AlertTriangle className="h-6 w-6 text-orange-600" />
                        </div>
                        <h3 className="font-medium mb-1">Send Alert</h3>
                        <p className="text-sm text-neutral-dark mb-4">Send alert notification to device</p>
                        <Select disabled={!selectedDevice.isOnline}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select alert type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="warning">Warning Alert</SelectItem>
                            <SelectItem value="critical">Critical Alert</SelectItem>
                            <SelectItem value="info">Information Alert</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button 
                          className="w-full mt-2"
                          variant="outline"
                          disabled={!selectedDevice.isOnline}
                        >
                          Send Alert
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
              </Tabs>
              
              <CardFooter className="border-t border-neutral-medium mt-4 pt-4 flex justify-between">
                <div className="text-sm text-neutral-dark flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  Last activity: {selectedDevice.lastActive ? new Date(selectedDevice.lastActive).toLocaleString() : 'Unknown'}
                </div>
                
                <div>
                  <Button 
                    variant="destructive"
                    size="sm"
                    onClick={handleLockDevice}
                    disabled={!selectedDevice.isOnline}
                  >
                    <Lock className="h-4 w-4 mr-1" />
                    Lock Device
                  </Button>
                </div>
              </CardFooter>
            </>
          )}
        </Card>
      </div>
    </MainLayout>
  );
}
