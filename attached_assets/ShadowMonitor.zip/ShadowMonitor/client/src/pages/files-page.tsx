import { useState, useEffect } from "react";
import MainLayout from "@/components/layout/main-layout";
import { useDevices } from "@/hooks/use-devices";
import { setupWebsocket } from "@/lib/websocket";
import { useWebsocket } from "@/lib/websocket";
import { Device } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Folder, 
  Upload, 
  Download, 
  FileText, 
  Image, 
  Film, 
  File, 
  ArrowUpDown, 
  Smartphone, 
  Clock, 
  RefreshCw, 
  CheckCircle, 
  AlertCircle,
  Search,
  XCircle
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface FileTransfer {
  id: number;
  deviceId: number;
  fileName: string;
  filePath: string;
  fileSize: number;
  direction: 'upload' | 'download';
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  createdAt: string;
  completedAt: string | null;
  progress?: number;
}

export default function FilesPage() {
  const { devices, isLoading } = useDevices();
  const { toast } = useToast();
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [fileTransfers, setFileTransfers] = useState<FileTransfer[]>([]);
  const [isLoadingTransfers, setIsLoadingTransfers] = useState(false);
  const [activeTab, setActiveTab] = useState("transfers");
  const [uploadFileName, setUploadFileName] = useState("");
  const [uploadFilePath, setUploadFilePath] = useState("/sdcard/Download");
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredDevices, setFilteredDevices] = useState<Device[]>([]);
  
  // Setup WebSocket connection
  useEffect(() => {
    setupWebsocket();
  }, []);
  
  // Filter devices based on search query
  useEffect(() => {
    const filtered = devices.filter(device => 
      device.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      device.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (device.department && device.department.toLowerCase().includes(searchQuery.toLowerCase()))
    );
    setFilteredDevices(filtered);
  }, [devices, searchQuery]);
  
  // Listen for file transfer updates
  useWebsocket('file_transfer', (message: any) => {
    if (selectedDevice && message.payload.deviceId === selectedDevice.deviceId) {
      setFileTransfers(prev => 
        prev.map(transfer => 
          transfer.id === message.payload.id 
            ? { ...transfer, status: message.payload.status, progress: message.payload.progress } 
            : transfer
        )
      );
      
      if (message.payload.status === 'completed') {
        toast({
          title: "File Transfer Complete",
          description: `${message.payload.fileName} has been successfully transferred.`,
        });
      } else if (message.payload.status === 'failed') {
        toast({
          title: "File Transfer Failed",
          description: `${message.payload.fileName} transfer failed.`,
          variant: "destructive",
        });
      }
    }
  });
  
  const loadFileTransfers = async (device: Device) => {
    if (!device) return;
    
    setIsLoadingTransfers(true);
    try {
      const response = await fetch(`/api/devices/${device.id}/files`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to load file transfers");
      }
      
      const data = await response.json();
      setFileTransfers(data);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load file transfers",
        variant: "destructive",
      });
      console.error(error);
    } finally {
      setIsLoadingTransfers(false);
    }
  };
  
  const handleDeviceSelect = (deviceId: number) => {
    const device = devices.find(d => d.id === Number(deviceId)) || null;
    setSelectedDevice(device);
    
    if (device) {
      loadFileTransfers(device);
    } else {
      setFileTransfers([]);
    }
  };
  
  const handleUploadFile = async () => {
    if (!selectedDevice || !uploadFileName || !uploadFilePath) return;
    
    try {
      // Create a file transfer record
      const response = await apiRequest("POST", `/api/devices/${selectedDevice.id}/files`, {
        fileName: uploadFileName,
        filePath: `${uploadFilePath}/${uploadFileName}`,
        fileSize: 1024, // Placeholder size
        direction: "upload",
        status: "pending"
      });
      
      const newTransfer = await response.json();
      
      // Add to the list
      setFileTransfers(prev => [newTransfer, ...prev]);
      
      toast({
        title: "Upload Initiated",
        description: `Starting upload of ${uploadFileName}`,
      });
      
      // Reset form fields
      setUploadFileName("");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to initiate file upload",
        variant: "destructive",
      });
      console.error(error);
    }
  };
  
  const handleDownloadFile = async (filePath: string) => {
    if (!selectedDevice) return;
    
    const fileName = filePath.split('/').pop() || 'unknown';
    
    try {
      // Create a file transfer record
      const response = await apiRequest("POST", `/api/devices/${selectedDevice.id}/files`, {
        fileName,
        filePath,
        fileSize: 1024, // Placeholder size
        direction: "download",
        status: "pending"
      });
      
      const newTransfer = await response.json();
      
      // Add to the list
      setFileTransfers(prev => [newTransfer, ...prev]);
      
      toast({
        title: "Download Initiated",
        description: `Starting download of ${fileName}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to initiate file download",
        variant: "destructive",
      });
      console.error(error);
    }
  };
  
  const getFileIcon = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase() || '';
    
    if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(extension)) {
      return <Image className="h-4 w-4" />;
    } else if (['mp4', 'avi', 'mov', 'mkv', 'webm'].includes(extension)) {
      return <Film className="h-4 w-4" />;
    } else if (['txt', 'doc', 'docx', 'pdf', 'csv', 'xls', 'xlsx', 'ppt', 'pptx'].includes(extension)) {
      return <FileText className="h-4 w-4" />;
    } else {
      return <File className="h-4 w-4" />;
    }
  };
  
  const getTransferStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="flex items-center">Pending</Badge>;
      case 'in_progress':
        return <Badge variant="secondary" className="flex items-center">In Progress</Badge>;
      case 'completed':
        return <Badge variant="default" className="bg-green-600 flex items-center">
          <CheckCircle className="h-3 w-3 mr-1" />
          Completed
        </Badge>;
      case 'failed':
        return <Badge variant="destructive" className="flex items-center">
          <XCircle className="h-3 w-3 mr-1" />
          Failed
        </Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
  };
  
  return (
    <MainLayout title="File Transfer">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Device selection sidebar */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">Select Device</CardTitle>
            <CardDescription>Choose a device to transfer files</CardDescription>
            
            <div className="relative mt-2">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral" />
              <Input 
                placeholder="Search devices..." 
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </CardHeader>
          
          <CardContent className="p-0">
            <div className="px-4 py-2">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Device</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDevices.length > 0 ? (
                    filteredDevices.map((device) => (
                      <TableRow 
                        key={device.id}
                        className={`cursor-pointer hover:bg-neutral-light ${selectedDevice?.id === device.id ? 'bg-primary-light/10' : ''}`}
                        onClick={() => handleDeviceSelect(device.id)}
                      >
                        <TableCell className="py-2">
                          <div className="flex flex-col">
                            <span className="font-medium">{device.name}</span>
                            <span className="text-xs text-neutral-dark">{device.user}</span>
                          </div>
                        </TableCell>
                        <TableCell className="py-2">
                          {!device.isOnline ? (
                            <Badge variant="outline" className="flex items-center">Offline</Badge>
                          ) : (
                            <Badge variant="default" className="bg-green-600 flex items-center">Online</Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={2} className="text-center py-4 text-neutral-dark">
                        No devices match your search
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
        
        {/* File transfer area */}
        <Card className="lg:col-span-2">
          {!selectedDevice ? (
            <div className="flex flex-col items-center justify-center h-[60vh]">
              <Folder className="h-20 w-20 text-neutral-light mb-4" />
              <h3 className="text-xl font-medium text-neutral-dark">Select a device to transfer files</h3>
              <p className="text-neutral mt-2">Choose a device from the list on the left</p>
            </div>
          ) : !selectedDevice.isOnline ? (
            <div className="flex flex-col items-center justify-center h-[60vh]">
              <AlertCircle className="h-20 w-20 text-red-200 mb-4" />
              <h3 className="text-xl font-medium text-neutral-dark">Device is offline</h3>
              <p className="text-neutral mt-2">File transfers are not available when the device is offline</p>
            </div>
          ) : (
            <>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle className="text-lg flex items-center">
                    <Smartphone className="h-5 w-5 mr-2 text-primary" />
                    {selectedDevice.name}
                  </CardTitle>
                  <CardDescription>{selectedDevice.user}{selectedDevice.department ? ` - ${selectedDevice.department}` : ''}</CardDescription>
                </div>
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex items-center"
                  onClick={() => loadFileTransfers(selectedDevice)}
                >
                  <RefreshCw className="h-4 w-4 mr-1" />
                  Refresh
                </Button>
              </CardHeader>
              
              <Tabs 
                value={activeTab} 
                onValueChange={setActiveTab}
                className="flex-1"
              >
                <div className="px-6">
                  <TabsList className="grid grid-cols-2 w-full">
                    <TabsTrigger value="transfers">Transfer History</TabsTrigger>
                    <TabsTrigger value="upload">Upload File</TabsTrigger>
                  </TabsList>
                </div>
                
                <TabsContent value="transfers" className="m-0 p-4">
                  {isLoadingTransfers ? (
                    <div className="flex justify-center items-center py-8">
                      <RefreshCw className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : fileTransfers.length === 0 ? (
                    <div className="text-center py-8">
                      <div className="mx-auto w-16 h-16 rounded-full bg-neutral-light flex items-center justify-center">
                        <ArrowUpDown className="h-8 w-8 text-neutral" />
                      </div>
                      <h3 className="mt-4 text-lg font-medium">No file transfers</h3>
                      <p className="mt-2 text-neutral-dark">Transfer history will appear here</p>
                    </div>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>File</TableHead>
                          <TableHead>Direction</TableHead>
                          <TableHead>Size</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Time</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {fileTransfers.map((transfer) => (
                          <TableRow key={transfer.id}>
                            <TableCell className="flex items-center">
                              {getFileIcon(transfer.fileName)}
                              <span className="ml-2">{transfer.fileName}</span>
                            </TableCell>
                            <TableCell>
                              {transfer.direction === 'upload' ? (
                                <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                                  <Upload className="h-3 w-3 mr-1" />
                                  Upload
                                </Badge>
                              ) : (
                                <Badge variant="outline" className="bg-secondary/10 text-secondary border-secondary/20">
                                  <Download className="h-3 w-3 mr-1" />
                                  Download
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell>{formatFileSize(transfer.fileSize)}</TableCell>
                            <TableCell>
                              {transfer.status === 'in_progress' && transfer.progress !== undefined ? (
                                <div className="w-[100px]">
                                  <Progress value={transfer.progress} className="h-2" />
                                  <div className="text-xs text-right mt-1">{transfer.progress}%</div>
                                </div>
                              ) : (
                                getTransferStatusBadge(transfer.status)
                              )}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center text-sm text-neutral-dark">
                                <Clock className="h-3 w-3 mr-1" />
                                {transfer.completedAt 
                                  ? new Date(transfer.completedAt).toLocaleString() 
                                  : new Date(transfer.createdAt).toLocaleString()
                                }
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </TabsContent>
                
                <TabsContent value="upload" className="m-0 p-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Upload File to Device</CardTitle>
                      <CardDescription>Send a file to the selected device</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                            File Name
                          </label>
                          <Input 
                            placeholder="Enter file name with extension"
                            className="mt-1"
                            value={uploadFileName}
                            onChange={(e) => setUploadFileName(e.target.value)}
                          />
                        </div>
                        
                        <div>
                          <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                            Destination Path
                          </label>
                          <Select 
                            value={uploadFilePath} 
                            onValueChange={setUploadFilePath}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue placeholder="Select destination folder" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="/sdcard/Download">Download Folder</SelectItem>
                              <SelectItem value="/sdcard/Documents">Documents Folder</SelectItem>
                              <SelectItem value="/sdcard/DCIM">Pictures Folder</SelectItem>
                              <SelectItem value="/sdcard/Movies">Movies Folder</SelectItem>
                              <SelectItem value="/sdcard/Music">Music Folder</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                            Select File
                          </label>
                          <div className="mt-1 border-2 border-dashed border-neutral-medium rounded-lg p-6 text-center">
                            <Upload className="h-8 w-8 mx-auto text-neutral-dark mb-2" />
                            <p className="text-sm text-neutral-dark mb-2">Drag & drop file here or click to browse</p>
                            <Button variant="outline" size="sm">
                              Browse Files
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="flex justify-between">
                      <Button variant="outline">Cancel</Button>
                      <Button 
                        variant="default"
                        onClick={handleUploadFile}
                        disabled={!uploadFileName}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Upload File
                      </Button>
                    </CardFooter>
                  </Card>
                </TabsContent>
              </Tabs>
              
              <CardFooter className="border-t border-neutral-medium mt-4 pt-4 flex justify-between">
                <div className="text-sm text-neutral-dark flex items-center">
                  <Folder className="h-4 w-4 mr-1" />
                  {fileTransfers.length} file transfers
                </div>
                
                <Button variant="outline" size="sm" onClick={() => setActiveTab("upload")}>
                  <Upload className="h-4 w-4 mr-1" />
                  New Upload
                </Button>
              </CardFooter>
            </>
          )}
        </Card>
      </div>
    </MainLayout>
  );
}
