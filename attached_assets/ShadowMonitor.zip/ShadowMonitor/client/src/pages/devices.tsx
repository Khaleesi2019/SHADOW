import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Device } from "@shared/schema";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { Header } from "@/components/dashboard/Header";
import { DeviceFilters, DeviceFilterValue, DeviceViewMode, DeviceSortOption } from "@/components/dashboard/DeviceFilters";
import { DeviceCard } from "@/components/dashboard/DeviceCard";
import { DeviceDetails } from "@/components/dashboard/DeviceDetails";
import { useToast } from "@/hooks/use-toast";
import { PageTitle } from "@/components/PageTitle";
import { useSocket } from "@/lib/socket";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Plus, 
  RefreshCw, 
  Download, 
  Smartphone,
  Trash2
} from "lucide-react";
import { 
  Button, 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter,
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
  Input,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertDeviceSchema } from "@shared/schema";

// Create a minimal device schema for the form
const deviceFormSchema = z.object({
  name: z.string().min(1, "Device name is required"),
  type: z.string().min(1, "Device type is required"),
  model: z.string().min(1, "Device model is required"),
  userId: z.string().min(1, "User is required"),
  department: z.string().optional(),
  identifier: z.string().min(1, "Device identifier is required"),
  os: z.string().optional(),
  osVersion: z.string().optional(),
});

type DeviceFormValues = z.infer<typeof deviceFormSchema>;

export default function Devices() {
  const { toast } = useToast();
  const socket = useSocket();
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [showDeviceDetails, setShowDeviceDetails] = useState(false);
  const [showAddDeviceDialog, setShowAddDeviceDialog] = useState(false);
  const [filter, setFilter] = useState<DeviceFilterValue>("all");
  const [viewMode, setViewMode] = useState<DeviceViewMode>("grid");
  const [sortBy, setSortBy] = useState<DeviceSortOption>("lastActive");
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: devices = [], isLoading, refetch } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
  });

  const form = useForm<DeviceFormValues>({
    resolver: zodResolver(deviceFormSchema),
    defaultValues: {
      name: "",
      type: "smartphone",
      model: "",
      userId: "",
      department: "",
      identifier: "",
      os: "",
      osVersion: "",
    },
  });

  const addDeviceMutation = useMutation({
    mutationFn: async (newDevice: DeviceFormValues) => {
      const res = await apiRequest("POST", "/api/devices", newDevice);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devices"] });
      setShowAddDeviceDialog(false);
      form.reset();
      toast({
        title: "Device Added",
        description: "New device has been successfully added to monitoring.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error Adding Device",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteDeviceMutation = useMutation({
    mutationFn: async (deviceId: number) => {
      await apiRequest("DELETE", `/api/devices/${deviceId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devices"] });
      toast({
        title: "Device Removed",
        description: "Device has been removed from monitoring.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error Removing Device",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function onSubmit(data: DeviceFormValues) {
    addDeviceMutation.mutate(data);
  }

  // Filter devices
  const filteredDevices = devices
    .filter(device => {
      // Apply search filter
      const matchesSearch = 
        searchQuery === "" || 
        device.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        device.userId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        device.department?.toLowerCase().includes(searchQuery.toLowerCase());
      
      // Apply status filter
      const matchesFilter = 
        filter === "all" || 
        (filter === "online" && device.status === "online") ||
        (filter === "offline" && device.status === "offline") ||
        (filter === "alert" && device.status === "alert");
      
      return matchesSearch && matchesFilter;
    })
    .sort((a, b) => {
      // Apply sorting
      switch (sortBy) {
        case "name":
          return a.name.localeCompare(b.name);
        case "status":
          return (a.status || "").localeCompare(b.status || "");
        case "type":
          return (a.type || "").localeCompare(b.type || "");
        case "lastActive":
        default:
          const dateA = a.lastActive ? new Date(a.lastActive).getTime() : 0;
          const dateB = b.lastActive ? new Date(b.lastActive).getTime() : 0;
          return dateB - dateA; // Most recent first
      }
    });

  const handleMonitorClick = (device: Device) => {
    setSelectedDevice(device);
    setShowDeviceDetails(true);
  };

  const handleFilesClick = (device: Device) => {
    // Navigate to file transfer page with this device selected
    window.location.href = `/files?deviceId=${device.id}`;
  };

  const handleLocationClick = (device: Device) => {
    // Navigate to location page with this device selected
    window.location.href = `/location?deviceId=${device.id}`;
  };

  const handleMoreClick = (device: Device) => {
    setSelectedDevice(device);
    setShowDeviceDetails(true);
  };

  const handleTakeControl = (device: Device) => {
    toast({
      title: "Taking Control",
      description: `Establishing connection to ${device.name}...`,
    });
    
    if (socket) {
      socket.emit("take-control", { deviceId: device.id });
    }
  };

  const handleLockDevice = (device: Device) => {
    toast({
      title: "Device Locked",
      description: `${device.name} has been locked remotely.`,
    });
    
    if (socket) {
      socket.emit("lock-device", { deviceId: device.id });
    }
  };

  const handleRefreshScreen = () => {
    toast({
      title: "Refreshing Screen",
      description: "Requesting latest screenshot...",
    });
    
    if (socket && selectedDevice) {
      socket.emit("refresh-screen", { deviceId: selectedDevice.id });
    }
  };

  const handleDeleteDevice = (deviceId: number) => {
    if (confirm("Are you sure you want to remove this device from monitoring?")) {
      deleteDeviceMutation.mutate(deviceId);
    }
  };

  const handleExportDevices = () => {
    const exportData = JSON.stringify(devices, null, 2);
    const blob = new Blob([exportData], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement("a");
    a.href = url;
    a.download = "devices_export.json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Export Complete",
      description: `Exported ${devices.length} devices to JSON file.`,
    });
  };

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-lightest">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="Devices" 
          onSearch={setSearchQuery}
          searchPlaceholder="Search by name, user, or department..."
          notificationCount={devices.filter(d => d.status === "alert").length}
        />
        
        <main className="flex-1 overflow-y-auto p-4 bg-neutral-lightest">
          <PageTitle 
            title="Monitored Devices" 
            description={`${devices.length} total devices, ${devices.filter(d => d.status === "online").length} online`}
          >
            <div className="flex gap-2">
              <Button 
                size="sm" 
                variant="outline" 
                className="gap-1"
                onClick={() => refetch()}
                disabled={isLoading}
              >
                <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} /> Refresh
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                className="gap-1"
                onClick={handleExportDevices}
              >
                <Download className="h-4 w-4" /> Export
              </Button>
              <Button 
                size="sm" 
                className="gap-1"
                onClick={() => setShowAddDeviceDialog(true)}
              >
                <Plus className="h-4 w-4" /> Add Device
              </Button>
            </div>
          </PageTitle>
          
          <DeviceFilters 
            onFilterChange={setFilter}
            onViewModeChange={setViewMode}
            onSortChange={setSortBy}
            activeFilter={filter}
            viewMode={viewMode}
            sortBy={sortBy}
          />
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <div 
                  key={i} 
                  className="bg-white rounded-lg shadow-sm border border-neutral-medium h-60 animate-pulse"
                ></div>
              ))}
            </div>
          ) : filteredDevices.length > 0 ? (
            <div className={`grid gap-4 ${viewMode === "grid" 
              ? "grid-cols-1 md:grid-cols-2 xl:grid-cols-3" 
              : "grid-cols-1"}`}
            >
              {filteredDevices.map((device) => (
                <DeviceCard 
                  key={device.id}
                  device={device}
                  onMonitorClick={handleMonitorClick}
                  onFilesClick={handleFilesClick}
                  onLocationClick={handleLocationClick}
                  onMoreClick={handleMoreClick}
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-neutral">
              <div className="bg-white p-8 rounded-lg shadow-sm border border-neutral-medium text-center">
                <svg className="mx-auto h-12 w-12 text-neutral" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 className="mt-2 text-sm font-medium text-neutral-darkest">No devices found</h3>
                <p className="mt-1 text-sm text-neutral-dark">
                  {searchQuery ? "Try adjusting your search or filter criteria" : "Add devices to start monitoring"}
                </p>
                <div className="mt-6">
                  <Button 
                    size="sm" 
                    className="gap-1"
                    onClick={() => setShowAddDeviceDialog(true)}
                  >
                    <Plus className="h-4 w-4" /> Add Device
                  </Button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
      
      {selectedDevice && (
        <DeviceDetails
          device={selectedDevice}
          isOpen={showDeviceDetails}
          onClose={() => setShowDeviceDetails(false)}
          onTakeControl={handleTakeControl}
          onLockDevice={handleLockDevice}
          onRefreshScreen={handleRefreshScreen}
        />
      )}

      {/* Add Device Dialog */}
      <Dialog open={showAddDeviceDialog} onOpenChange={setShowAddDeviceDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Smartphone className="h-5 w-5 text-primary" />
              Add New Device
            </DialogTitle>
            <DialogDescription>
              Register a new device for monitoring. The device will need to have the client app installed.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Device Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Samsung Galaxy S21" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Device Type</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select device type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="smartphone">Smartphone</SelectItem>
                          <SelectItem value="tablet">Tablet</SelectItem>
                          <SelectItem value="laptop">Laptop</SelectItem>
                          <SelectItem value="desktop">Desktop</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="model"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Model</FormLabel>
                      <FormControl>
                        <Input placeholder="Galaxy S21" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="identifier"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>IMEI / Unique ID</FormLabel>
                      <FormControl>
                        <Input placeholder="123456789012345" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="os"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Operating System</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select OS" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Android">Android</SelectItem>
                          <SelectItem value="iOS">iOS</SelectItem>
                          <SelectItem value="Windows">Windows</SelectItem>
                          <SelectItem value="macOS">macOS</SelectItem>
                          <SelectItem value="Linux">Linux</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="osVersion"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>OS Version</FormLabel>
                      <FormControl>
                        <Input placeholder="12.0" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="userId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>User Name</FormLabel>
                    <FormControl>
                      <Input placeholder="John Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="department"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Department</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Sales">Sales</SelectItem>
                        <SelectItem value="Marketing">Marketing</SelectItem>
                        <SelectItem value="IT">IT</SelectItem>
                        <SelectItem value="Finance">Finance</SelectItem>
                        <SelectItem value="HR">HR</SelectItem>
                        <SelectItem value="Operations">Operations</SelectItem>
                        <SelectItem value="Support">Support</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowAddDeviceDialog(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={addDeviceMutation.isPending}
                >
                  {addDeviceMutation.isPending ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Adding...
                    </>
                  ) : (
                    <>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Device
                    </>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
