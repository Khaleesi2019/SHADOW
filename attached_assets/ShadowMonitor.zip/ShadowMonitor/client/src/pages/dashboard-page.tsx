import { useEffect } from "react";
import MainLayout from "@/components/layout/main-layout";
import OverviewStats from "@/components/devices/overview-stats";
import { useDevices } from "@/hooks/use-devices";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { setupWebsocket } from "@/lib/websocket";
import { BarChart, LineChart, PieChart, Timer } from "lucide-react";
import { 
  ResponsiveContainer, 
  LineChart as RechartsLineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  BarChart as RechartsBarChart,
  Bar,
  PieChart as RechartsPieChart,
  Pie,
  Cell
} from "recharts";

const activityData = [
  { name: "Mon", value: 23 },
  { name: "Tue", value: 35 },
  { name: "Wed", value: 45 },
  { name: "Thu", value: 30 },
  { name: "Fri", value: 55 },
  { name: "Sat", value: 15 },
  { name: "Sun", value: 10 },
];

const deviceTypeData = [
  { name: "Samsung", value: 35 },
  { name: "iPhone", value: 25 },
  { name: "Xiaomi", value: 20 },
  { name: "Motorola", value: 10 },
  { name: "Other", value: 10 },
];

const DEVICE_TYPE_COLORS = ['#2196f3', '#4caf50', '#ff9800', '#f44336', '#9c27b0'];

const alertsPerDeviceData = [
  { name: "Samsung Galaxy A32", alerts: 3 },
  { name: "Xiaomi Redmi Note", alerts: 2 },
  { name: "iPhone 13", alerts: 1 },
  { name: "Google Pixel 6", alerts: 0 },
  { name: "Motorola G Power", alerts: 0 },
];

const usageHoursData = [
  { department: 'Sales', hours: 42 },
  { department: 'Marketing', hours: 28 },
  { department: 'Support', hours: 36 },
  { department: 'IT', hours: 45 },
  { department: 'Warehouse', hours: 22 },
];

export default function DashboardPage() {
  const { devices, isLoading, error } = useDevices();
  
  // Setup WebSocket connection when component mounts
  useEffect(() => {
    setupWebsocket();
  }, []);
  
  return (
    <MainLayout title="Dashboard">
      {isLoading ? (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-24 w-full" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Skeleton className="h-80 w-full" />
            <Skeleton className="h-80 w-full" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Skeleton className="h-80 w-full" />
            <Skeleton className="h-80 w-full" />
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <OverviewStats devices={devices} />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-md font-medium">
                  <LineChart className="h-4 w-4 inline mr-2 text-primary" />
                  Daily Activity
                </CardTitle>
                <Timer className="h-4 w-4 text-neutral" />
              </CardHeader>
              <CardContent className="pt-0">
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsLineChart data={activityData} margin={{ top: 20, right: 20, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                    <XAxis dataKey="name" stroke="#616161" />
                    <YAxis stroke="#616161" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'white', 
                        border: '1px solid #e0e0e0',
                        borderRadius: '0.5rem' 
                      }} 
                    />
                    <Line 
                      type="monotone" 
                      dataKey="value" 
                      name="Activities" 
                      stroke="#1976d2" 
                      strokeWidth={2}
                      activeDot={{ r: 8 }} 
                    />
                  </RechartsLineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-md font-medium">
                  <PieChart className="h-4 w-4 inline mr-2 text-primary" />
                  Device Types
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPieChart>
                    <Pie
                      data={deviceTypeData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {deviceTypeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={DEVICE_TYPE_COLORS[index % DEVICE_TYPE_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ 
                        backgroundColor: 'white', 
                        border: '1px solid #e0e0e0',
                        borderRadius: '0.5rem' 
                      }}
                      formatter={(value) => [`${value} devices`, 'Count']}
                    />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-md font-medium">
                  <BarChart className="h-4 w-4 inline mr-2 text-primary" />
                  Alerts by Device
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsBarChart
                    data={alertsPerDeviceData}
                    margin={{ top: 20, right: 20, left: 20, bottom: 60 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                    <XAxis 
                      dataKey="name" 
                      stroke="#616161"
                      tick={{ fontSize: 12 }}
                      angle={-45}
                      textAnchor="end"
                      height={80}
                    />
                    <YAxis stroke="#616161" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'white', 
                        border: '1px solid #e0e0e0',
                        borderRadius: '0.5rem' 
                      }} 
                    />
                    <Bar 
                      dataKey="alerts" 
                      name="Alerts" 
                      fill="#f50057" 
                      radius={[4, 4, 0, 0]} 
                    />
                  </RechartsBarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-md font-medium">
                  <BarChart className="h-4 w-4 inline mr-2 text-primary" />
                  Usage Hours by Department
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsBarChart
                    data={usageHoursData}
                    margin={{ top: 20, right: 20, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                    <XAxis dataKey="department" stroke="#616161" />
                    <YAxis stroke="#616161" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'white', 
                        border: '1px solid #e0e0e0',
                        borderRadius: '0.5rem' 
                      }} 
                    />
                    <Bar 
                      dataKey="hours" 
                      name="Hours" 
                      fill="#1976d2" 
                      radius={[4, 4, 0, 0]} 
                    />
                  </RechartsBarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </MainLayout>
  );
}
