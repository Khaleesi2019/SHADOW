import { useState, useEffect } from "react";
import MainLayout from "@/components/layout/main-layout";
import { useDevices } from "@/hooks/use-devices";
import DeviceCard from "@/components/devices/device-card";
import DeviceFilters from "@/components/devices/device-filters";
import DeviceDetails from "@/components/devices/device-details";
import OverviewStats from "@/components/devices/overview-stats";
import { Device } from "@shared/schema";
import { setupWebsocket } from "@/lib/websocket";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function DevicesPage() {
  const { devices, isLoading } = useDevices();
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [showDeviceDetails, setShowDeviceDetails] = useState(false);
  const [filteredDevices, setFilteredDevices] = useState<Device[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [filter, setFilter] = useState("all");
  const [sortBy, setSortBy] = useState("lastActive");
  const [viewType, setViewType] = useState<'grid' | 'list'>('grid');
  
  const ITEMS_PER_PAGE = 6;
  
  useEffect(() => {
    setupWebsocket();
  }, []);
  
  // Filter and sort devices when devices, filter or sortBy changes
  useEffect(() => {
    let result = [...devices];
    
    // Apply filter
    if (filter === "online") {
      result = result.filter(device => device.isOnline);
    } else if (filter === "offline") {
      result = result.filter(device => !device.isOnline);
    } else if (filter === "alerts") {
      result = result.filter(device => device.status === "alert");
    }
    
    // Apply sorting
    if (sortBy === "lastActive") {
      result.sort((a, b) => {
        if (!a.lastActive) return 1;
        if (!b.lastActive) return -1;
        return new Date(b.lastActive).getTime() - new Date(a.lastActive).getTime();
      });
    } else if (sortBy === "name") {
      result.sort((a, b) => a.name.localeCompare(b.name));
    } else if (sortBy === "status") {
      result.sort((a, b) => {
        if (a.status === "alert" && b.status !== "alert") return -1;
        if (a.status !== "alert" && b.status === "alert") return 1;
        if (a.isOnline && !b.isOnline) return -1;
        if (!a.isOnline && b.isOnline) return 1;
        return 0;
      });
    } else if (sortBy === "device") {
      result.sort((a, b) => a.model.localeCompare(b.model));
    }
    
    setFilteredDevices(result);
    setCurrentPage(1); // Reset to first page when filtering/sorting changes
  }, [devices, filter, sortBy]);
  
  // Calculate pagination
  const totalPages = Math.ceil(filteredDevices.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const paginatedDevices = filteredDevices.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  
  // Device card actions
  const handleMonitor = (device: Device) => {
    setSelectedDevice(device);
    setShowDeviceDetails(true);
  };
  
  const handleFiles = (device: Device) => {
    setSelectedDevice(device);
    setShowDeviceDetails(true);
  };
  
  const handleLocation = (device: Device) => {
    setSelectedDevice(device);
    setShowDeviceDetails(true);
  };
  
  const handleMore = (device: Device) => {
    setSelectedDevice(device);
    setShowDeviceDetails(true);
  };
  
  const handleDeviceClick = (device: Device) => {
    setSelectedDevice(device);
    setShowDeviceDetails(true);
  };
  
  return (
    <MainLayout title="Monitored Devices">
      {isLoading ? (
        <div className="flex justify-center items-center h-full">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <>
          <OverviewStats devices={devices} />
          
          <DeviceFilters 
            onFilterChange={setFilter} 
            onSortChange={setSortBy} 
            onViewChange={setViewType}
            activeFilter={filter}
            activeView={viewType}
          />
          
          {filteredDevices.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-lg border border-neutral-medium">
              <div className="mx-auto w-16 h-16 rounded-full bg-neutral-light flex items-center justify-center">
                <ChevronRight className="h-8 w-8 text-neutral" />
              </div>
              <h3 className="mt-4 text-lg font-medium">No devices found</h3>
              <p className="mt-2 text-neutral-dark">Try changing your filter criteria</p>
            </div>
          ) : (
            <>
              <div className={
                viewType === 'grid' 
                  ? "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4" 
                  : "space-y-4"
              }>
                {paginatedDevices.map((device) => (
                  <DeviceCard
                    key={device.id}
                    device={device}
                    onMonitor={() => handleMonitor(device)}
                    onFiles={() => handleFiles(device)}
                    onLocation={() => handleLocation(device)}
                    onMore={() => handleMore(device)}
                    onClick={() => handleDeviceClick(device)}
                  />
                ))}
              </div>
              
              {totalPages > 1 && (
                <Pagination className="mt-6">
                  <PaginationContent>
                    <PaginationItem>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                        disabled={currentPage === 1}
                      >
                        <ChevronLeft className="h-4 w-4" />
                      </Button>
                    </PaginationItem>
                    
                    {Array.from({ length: totalPages }).map((_, index) => (
                      <PaginationItem key={index}>
                        <PaginationLink
                          isActive={currentPage === index + 1}
                          onClick={() => setCurrentPage(index + 1)}
                        >
                          {index + 1}
                        </PaginationLink>
                      </PaginationItem>
                    ))}
                    
                    <PaginationItem>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                        disabled={currentPage === totalPages}
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              )}
            </>
          )}
          
          <DeviceDetails
            device={selectedDevice}
            open={showDeviceDetails}
            onOpenChange={setShowDeviceDetails}
          />
        </>
      )}
    </MainLayout>
  );
}
