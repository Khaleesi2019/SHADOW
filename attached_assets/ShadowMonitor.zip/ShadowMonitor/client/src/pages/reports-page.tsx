import { useState, useEffect } from "react";
import MainLayout from "@/components/layout/main-layout";
import { useDevices } from "@/hooks/use-devices";
import { setupWebsocket } from "@/lib/websocket";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { 
  BarChart as BarChartIcon, 
  DownloadCloud, 
  Calendar, 
  ClipboardList, 
  Clock, 
  Filter, 
  PieChart as PieChartIcon, 
  LineChart as LineChartIcon,
  Smartphone,
  User,
  FileText,
  Printer
} from "lucide-react";
import { 
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from "recharts";

// Sample report data
const deviceUsageData = [
  { name: "Samsung Galaxy S21", hours: 42 },
  { name: "iPhone 13", hours: 38 },
  { name: "Xiaomi Redmi Note", hours: 35 },
  { name: "Motorola G Power", hours: 27 },
  { name: "Samsung Galaxy A32", hours: 21 },
];

const alertsByDayData = [
  { name: "Mon", alerts: 2 },
  { name: "Tue", alerts: 1 },
  { name: "Wed", alerts: 3 },
  { name: "Thu", alerts: 0 },
  { name: "Fri", alerts: 2 },
  { name: "Sat", alerts: 0 },
  { name: "Sun", alerts: 1 },
];

const deviceStatusData = [
  { name: "Online", value: 8 },
  { name: "Offline", value: 4 },
  { name: "Alert", value: 2 },
];

const departmentUsageData = [
  { name: "Sales", online: 3, offline: 1, alerts: 1 },
  { name: "Marketing", online: 2, offline: 0, alerts: 0 },
  { name: "IT", online: 1, offline: 1, alerts: 0 },
  { name: "Support", online: 1, offline: 1, alerts: 0 },
  { name: "Warehouse", online: 1, offline: 1, alerts: 1 },
];

const recentAlertsData = [
  { 
    id: 1, 
    device: "Samsung Galaxy A32", 
    user: "Miguel Torres", 
    type: "location", 
    message: "Geofence violation: Outside of allowed perimeter", 
    timestamp: "2023-08-01T14:32:00Z" 
  },
  { 
    id: 2, 
    device: "Xiaomi Redmi Note", 
    user: "Juan Perez", 
    type: "security", 
    message: "Unusual activity detected: Accessing secure app storage", 
    timestamp: "2023-08-01T12:15:00Z" 
  },
  { 
    id: 3, 
    device: "Samsung Galaxy A32", 
    user: "Miguel Torres", 
    type: "battery", 
    message: "Battery critically low (5%)", 
    timestamp: "2023-07-31T18:45:00Z" 
  },
  { 
    id: 4, 
    device: "iPhone 13", 
    user: "Carlos Mendez", 
    type: "security", 
    message: "Multiple failed login attempts detected", 
    timestamp: "2023-07-30T09:22:00Z" 
  },
  { 
    id: 5, 
    device: "Samsung Galaxy S21", 
    user: "Maria Lopez", 
    type: "usage", 
    message: "Excessive data usage detected (2GB in 1 hour)", 
    timestamp: "2023-07-29T16:10:00Z" 
  },
];

const COLORS = ['#2196f3', '#ff9800', '#f44336'];

export default function ReportsPage() {
  const { devices, isLoading } = useDevices();
  const [activePeriod, setActivePeriod] = useState("week");
  const [activeTab, setActiveTab] = useState("overview");
  const [chartView, setChartView] = useState("bar");
  
  // Setup WebSocket connection
  useEffect(() => {
    setupWebsocket();
  }, []);
  
  const formatDate = (isoString: string) => {
    return new Date(isoString).toLocaleString();
  };
  
  const getAlertTypeBadge = (type: string) => {
    switch (type) {
      case 'security':
        return <Badge className="bg-red-600">Security</Badge>;
      case 'location':
        return <Badge className="bg-orange-500">Location</Badge>;
      case 'battery':
        return <Badge className="bg-yellow-500">Battery</Badge>;
      case 'usage':
        return <Badge className="bg-blue-500">Usage</Badge>;
      default:
        return <Badge>{type}</Badge>;
    }
  };
  
  return (
    <MainLayout title="Reports">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Analytics & Reports</h1>
          <p className="text-neutral-dark">Monitor device usage and alerts</p>
        </div>
        
        <div className="flex items-center gap-2">
          <Select value={activePeriod} onValueChange={setActivePeriod}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="day">Last 24 Hours</SelectItem>
              <SelectItem value="week">Last 7 Days</SelectItem>
              <SelectItem value="month">Last 30 Days</SelectItem>
              <SelectItem value="quarter">Last 90 Days</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" className="flex items-center">
            <DownloadCloud className="h-4 w-4 mr-2" />
            Export
          </Button>
          
          <Button variant="ghost" size="icon">
            <Printer className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4 mb-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="devices">Device Usage</TabsTrigger>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
          <TabsTrigger value="activity">User Activity</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="m-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-neutral">Total Devices</p>
                    <p className="text-3xl font-semibold mt-1">{devices.length}</p>
                  </div>
                  <div className="bg-primary/10 p-3 rounded-full">
                    <Smartphone className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <p className="text-xs text-neutral-dark mt-4 flex items-center">
                  <Clock className="h-3 w-3 mr-1" />
                  Last updated: {new Date().toLocaleTimeString()}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-neutral">Active Users</p>
                    <p className="text-3xl font-semibold mt-1">{devices.filter(d => d.isOnline).length}</p>
                  </div>
                  <div className="bg-green-100 p-3 rounded-full">
                    <User className="h-6 w-6 text-green-600" />
                  </div>
                </div>
                <p className="text-xs text-green-600 mt-4 flex items-center">
                  <Clock className="h-3 w-3 mr-1" />
                  {devices.filter(d => d.isOnline).length} users currently online
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-neutral">Recent Alerts</p>
                    <p className="text-3xl font-semibold mt-1">{recentAlertsData.length}</p>
                  </div>
                  <div className="bg-red-100 p-3 rounded-full">
                    <FileText className="h-6 w-6 text-red-600" />
                  </div>
                </div>
                <p className="text-xs text-red-600 mt-4 flex items-center">
                  <Clock className="h-3 w-3 mr-1" />
                  {recentAlertsData.filter(a => new Date(a.timestamp) > new Date(Date.now() - 24 * 60 * 60 * 1000)).length} new alerts in last 24h
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-neutral">Avg. Usage</p>
                    <p className="text-3xl font-semibold mt-1">3.2h</p>
                  </div>
                  <div className="bg-blue-100 p-3 rounded-full">
                    <Clock className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
                <p className="text-xs text-blue-600 mt-4 flex items-center">
                  <Clock className="h-3 w-3 mr-1" />
                  Daily average per device
                </p>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-medium flex items-center">
                    <BarChartIcon className="h-4 w-4 mr-2 text-primary" />
                    Device Usage
                  </CardTitle>
                  
                  <Select value={chartView} onValueChange={setChartView}>
                    <SelectTrigger className="w-[120px] h-8">
                      <SelectValue placeholder="Chart type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bar">Bar Chart</SelectItem>
                      <SelectItem value="line">Line Chart</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <CardDescription>Hours of usage per device</CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    {chartView === 'bar' ? (
                      <BarChart
                        data={deviceUsageData}
                        margin={{ top: 20, right: 30, left: 20, bottom: 60 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="name" 
                          tick={{ fontSize: 12 }}
                          angle={-45}
                          textAnchor="end"
                          height={80}
                        />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="hours" fill="#1976d2" name="Hours" />
                      </BarChart>
                    ) : (
                      <LineChart
                        data={deviceUsageData}
                        margin={{ top: 20, right: 30, left: 20, bottom: 60 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="name" 
                          tick={{ fontSize: 12 }}
                          angle={-45}
                          textAnchor="end"
                          height={80}
                        />
                        <YAxis />
                        <Tooltip />
                        <Line type="monotone" dataKey="hours" stroke="#1976d2" name="Hours" />
                      </LineChart>
                    )}
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium flex items-center">
                  <PieChartIcon className="h-4 w-4 mr-2 text-primary" />
                  Device Status
                </CardTitle>
                <CardDescription>Current status of all devices</CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={deviceStatusData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        innerRadius={60}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {deviceStatusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value} devices`, 'Count']} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium flex items-center">
                <LineChartIcon className="h-4 w-4 mr-2 text-primary" />
                Alerts Per Day
              </CardTitle>
              <CardDescription>Number of alerts triggered each day</CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={alertsByDayData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Bar dataKey="alerts" fill="#f50057" name="Alerts" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="devices" className="m-0">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-medium">Device Usage Report</CardTitle>
                  <CardDescription>Usage statistics for all monitored devices</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <div className="space-x-2">
                        <Button variant="outline" size="sm">
                          <Filter className="h-4 w-4 mr-1" />
                          Filter
                        </Button>
                        
                        <Button variant="outline" size="sm">
                          <Calendar className="h-4 w-4 mr-1" />
                          Date Range
                        </Button>
                      </div>
                      
                      <div>
                        <Select defaultValue="usage">
                          <SelectTrigger className="w-[160px]">
                            <SelectValue placeholder="Select report type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="usage">Usage Time</SelectItem>
                            <SelectItem value="data">Data Usage</SelectItem>
                            <SelectItem value="battery">Battery Stats</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Device</TableHead>
                          <TableHead>User</TableHead>
                          <TableHead>Department</TableHead>
                          <TableHead className="text-right">Usage (Hours)</TableHead>
                          <TableHead className="text-right">Avg. Daily</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {devices.map((device) => (
                          <TableRow key={device.id}>
                            <TableCell className="font-medium">{device.name}</TableCell>
                            <TableCell>{device.user}</TableCell>
                            <TableCell>{device.department || "N/A"}</TableCell>
                            <TableCell className="text-right">
                              {Math.floor(Math.random() * 50) + 10}h
                            </TableCell>
                            <TableCell className="text-right">
                              {((Math.floor(Math.random() * 50) + 10) / 7).toFixed(1)}h
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle className="text-lg font-medium">Department Usage</CardTitle>
                  <CardDescription>Usage by department</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={departmentUsageData}
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis allowDecimals={false} />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="online" stackId="a" fill="#4caf50" name="Online" />
                        <Bar dataKey="offline" stackId="a" fill="#9e9e9e" name="Offline" />
                        <Bar dataKey="alerts" stackId="a" fill="#f44336" name="Alerts" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-medium">Export Report</CardTitle>
                  <CardDescription>Download detailed statistics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="report-type">Report Type</Label>
                    <Select defaultValue="usage">
                      <SelectTrigger id="report-type">
                        <SelectValue placeholder="Select report type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="usage">Usage Report</SelectItem>
                        <SelectItem value="alerts">Alerts Report</SelectItem>
                        <SelectItem value="summary">Executive Summary</SelectItem>
                        <SelectItem value="custom">Custom Report</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="format">Format</Label>
                    <Select defaultValue="pdf">
                      <SelectTrigger id="format">
                        <SelectValue placeholder="Select format" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pdf">PDF Document</SelectItem>
                        <SelectItem value="csv">CSV Spreadsheet</SelectItem>
                        <SelectItem value="xlsx">Excel Spreadsheet</SelectItem>
                        <SelectItem value="json">JSON Data</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <Button className="w-full">
                    <DownloadCloud className="h-4 w-4 mr-2" />
                    Generate & Download
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="alerts" className="m-0">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium">Recent Alerts</CardTitle>
              <CardDescription>Security and activity alerts from monitored devices</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <div className="space-x-2">
                    <Button variant="outline" size="sm">
                      <Filter className="h-4 w-4 mr-1" />
                      Filter
                    </Button>
                    
                    <Select defaultValue="all">
                      <SelectTrigger className="w-[160px]">
                        <SelectValue placeholder="Alert type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Types</SelectItem>
                        <SelectItem value="security">Security</SelectItem>
                        <SelectItem value="location">Location</SelectItem>
                        <SelectItem value="battery">Battery</SelectItem>
                        <SelectItem value="usage">Usage</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Input className="w-[250px]" placeholder="Search alerts..." />
                  </div>
                </div>
                
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Device</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Alert Message</TableHead>
                      <TableHead>Time</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentAlertsData.map((alert) => (
                      <TableRow key={alert.id}>
                        <TableCell className="font-medium">{alert.device}</TableCell>
                        <TableCell>{alert.user}</TableCell>
                        <TableCell>{getAlertTypeBadge(alert.type)}</TableCell>
                        <TableCell>{alert.message}</TableCell>
                        <TableCell>{formatDate(alert.timestamp)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                
                <div className="flex justify-between">
                  <div className="text-sm text-neutral-dark flex items-center">
                    <ClipboardList className="h-4 w-4 mr-1" />
                    Showing 5 of 27 alerts
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" disabled>Previous</Button>
                    <Button variant="outline" size="sm">Next</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">Alerts by Type</CardTitle>
                <CardDescription>Distribution of alert categories</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: "Security", value: 8 },
                          { name: "Location", value: 12 },
                          { name: "Battery", value: 5 },
                          { name: "Usage", value: 2 }
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        <Cell fill="#f44336" />
                        <Cell fill="#ff9800" />
                        <Cell fill="#ffeb3b" />
                        <Cell fill="#2196f3" />
                      </Pie>
                      <Tooltip formatter={(value) => [`${value} alerts`, 'Count']} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">Alerts Timeline</CardTitle>
                <CardDescription>Alert frequency over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={[
                        { date: "Jul 25", alerts: 2 },
                        { date: "Jul 26", alerts: 5 },
                        { date: "Jul 27", alerts: 3 },
                        { date: "Jul 28", alerts: 7 },
                        { date: "Jul 29", alerts: 2 },
                        { date: "Jul 30", alerts: 4 },
                        { date: "Jul 31", alerts: 3 },
                        { date: "Aug 1", alerts: 6 }
                      ]}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis allowDecimals={false} />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="alerts" 
                        stroke="#f50057" 
                        name="Alerts"
                        strokeWidth={2}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="activity" className="m-0">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-3">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-medium">User Activity Report</CardTitle>
                  <CardDescription>Detailed activity statistics by user</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <div className="space-x-2">
                        <Button variant="outline" size="sm">
                          <Filter className="h-4 w-4 mr-1" />
                          Filter
                        </Button>
                        
                        <Button variant="outline" size="sm">
                          <Calendar className="h-4 w-4 mr-1" />
                          Date Range
                        </Button>
                      </div>
                      
                      <div>
                        <Input className="w-[250px]" placeholder="Search users..." />
                      </div>
                    </div>
                    
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>User</TableHead>
                          <TableHead>Department</TableHead>
                          <TableHead>Device</TableHead>
                          <TableHead className="text-right">Active Hours</TableHead>
                          <TableHead className="text-right">Apps Used</TableHead>
                          <TableHead className="text-right">Data Used</TableHead>
                          <TableHead>Last Active</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {devices.map((device) => (
                          <TableRow key={device.id}>
                            <TableCell className="font-medium">{device.user}</TableCell>
                            <TableCell>{device.department || "N/A"}</TableCell>
                            <TableCell>{device.name}</TableCell>
                            <TableCell className="text-right">
                              {Math.floor(Math.random() * 40) + 5}h
                            </TableCell>
                            <TableCell className="text-right">
                              {Math.floor(Math.random() * 15) + 3}
                            </TableCell>
                            <TableCell className="text-right">
                              {(Math.random() * 5).toFixed(1)} GB
                            </TableCell>
                            <TableCell>
                              {device.lastActive ? new Date(device.lastActive).toLocaleString() : 'Unknown'}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-medium">App Usage by User</CardTitle>
                  <CardDescription>Most used applications per user</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={[
                          { user: "Maria Lopez", email: 4.5, browser: 3.2, messaging: 5.3, social: 2.1, other: 1.2 },
                          { user: "Carlos Mendez", email: 2.3, browser: 6.5, messaging: 2.1, social: 4.2, other: 0.9 },
                          { user: "Juan Perez", email: 3.7, browser: 4.2, messaging: 3.3, social: 1.5, other: 2.3 },
                          { user: "Ana Rivera", email: 5.2, browser: 2.8, messaging: 4.5, social: 3.2, other: 1.1 },
                          { user: "Roberto Garcia", email: 1.8, browser: 5.1, messaging: 2.7, social: 3.8, other: 2.5 },
                        ]}
                        margin={{ top: 20, right: 30, left: 20, bottom: 60 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="user" 
                          tick={{ fontSize: 12 }}
                          angle={-45}
                          textAnchor="end"
                          height={80}
                        />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="email" stackId="a" fill="#1976d2" name="Email" />
                        <Bar dataKey="browser" stackId="a" fill="#4caf50" name="Browser" />
                        <Bar dataKey="messaging" stackId="a" fill="#ff9800" name="Messaging" />
                        <Bar dataKey="social" stackId="a" fill="#f44336" name="Social" />
                        <Bar dataKey="other" stackId="a" fill="#9c27b0" name="Other Apps" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-medium">Top Active Users</CardTitle>
                  <CardDescription>Based on total usage time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {devices.slice(0, 5).map((device, index) => (
                      <div key={device.id} className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white mr-3">
                            <span>{device.user.split(' ').map(n => n[0]).join('').toUpperCase()}</span>
                          </div>
                          <div>
                            <p className="font-medium">{device.user}</p>
                            <p className="text-xs text-neutral-dark">{device.department || "No Department"}</p>
                          </div>
                        </div>
                        <div className="text-sm font-medium">
                          {Math.floor(40 - index * 5)}h
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </MainLayout>
  );
}
