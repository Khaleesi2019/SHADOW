import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Device, DeviceActivity } from "@shared/schema";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { Header } from "@/components/dashboard/Header";
import { useToast } from "@/hooks/use-toast";
import { PageTitle } from "@/components/PageTitle";
import { 
  Download, 
  BarChart, 
  PieChart, 
  Calendar, 
  Clock, 
  Filter,
  FileText,
  RefreshCw
} from "lucide-react";
import { 
  Button, 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui";

export default function Reports() {
  const { toast } = useToast();
  const [reportType, setReportType] = useState("activity");
  const [timeframe, setTimeframe] = useState("week");
  const [format, setFormat] = useState("pdf");
  
  const { data: devices = [], isLoading: devicesLoading } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
  });

  const { data: activities = [], isLoading: activitiesLoading } = useQuery<DeviceActivity[]>({
    queryKey: ["/api/activities", timeframe],
  });

  // Calculate statistics
  const totalDevices = devices.length;
  const onlineDevices = devices.filter(d => d.status === "online").length;
  const offlineDevices = devices.filter(d => d.status === "offline" || !d.status).length;
  const alertDevices = devices.filter(d => d.status === "alert").length;
  
  const totalActivities = activities.length;
  const screenCaptures = activities.filter(a => a.action === "screencapture").length;
  const fileTransfers = activities.filter(a => a.action === "filetransfer").length;
  const remoteControls = activities.filter(a => a.action === "remotecontrol").length;

  const handleGenerateReport = () => {
    toast({
      title: "Generating Report",
      description: `${reportType.charAt(0).toUpperCase() + reportType.slice(1)} report is being generated.`,
    });
    
    // Simulating report generation delay
    setTimeout(() => {
      toast({
        title: "Report Ready",
        description: `Your ${reportType} report is ready for download.`,
      });
    }, 2000);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-lightest">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="Reports" 
          searchPlaceholder="Search reports..."
          notificationCount={devices.filter(d => d.status === "alert").length}
        />
        
        <main className="flex-1 overflow-y-auto p-4 bg-neutral-lightest">
          <PageTitle 
            title="Reports & Analytics" 
            description="Generate detailed reports about device usage and activities"
          />
          
          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Devices</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{totalDevices}</div>
                <div className="mt-2 text-xs text-neutral flex items-center justify-between">
                  <span className="flex items-center">
                    <span className="w-2 h-2 rounded-full bg-green-500 mr-1"></span>
                    Online: {onlineDevices}
                  </span>
                  <span className="flex items-center">
                    <span className="w-2 h-2 rounded-full bg-neutral-dark mr-1"></span>
                    Offline: {offlineDevices}
                  </span>
                  <span className="flex items-center">
                    <span className="w-2 h-2 rounded-full bg-red-500 mr-1"></span>
                    Alert: {alertDevices}
                  </span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Activities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{totalActivities}</div>
                <div className="mt-2 text-xs text-neutral">
                  {timeframe === "today" ? "Today" : 
                   timeframe === "week" ? "This Week" : 
                   timeframe === "month" ? "This Month" : "All Time"}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Monitor Sessions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{screenCaptures}</div>
                <div className="mt-2 text-xs text-neutral">
                  {Math.round(screenCaptures / Math.max(totalActivities, 1) * 100)}% of all activities
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">File Transfers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{fileTransfers}</div>
                <div className="mt-2 text-xs text-neutral">
                  {Math.round(fileTransfers / Math.max(totalActivities, 1) * 100)}% of all activities
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Report Generator */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Report Generator
              </CardTitle>
              <CardDescription>
                Generate comprehensive reports for monitoring and compliance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Report Type</label>
                  <Select
                    value={reportType}
                    onValueChange={setReportType}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select report type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="activity">Activity Report</SelectItem>
                      <SelectItem value="device">Device Status Report</SelectItem>
                      <SelectItem value="location">Location History</SelectItem>
                      <SelectItem value="compliance">Compliance Report</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Time Period</label>
                  <Select
                    value={timeframe}
                    onValueChange={setTimeframe}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select time period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="today">Today</SelectItem>
                      <SelectItem value="week">This Week</SelectItem>
                      <SelectItem value="month">This Month</SelectItem>
                      <SelectItem value="quarter">Last Quarter</SelectItem>
                      <SelectItem value="year">This Year</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Format</label>
                  <Select
                    value={format}
                    onValueChange={setFormat}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pdf">PDF Document</SelectItem>
                      <SelectItem value="csv">CSV Spreadsheet</SelectItem>
                      <SelectItem value="excel">Excel Spreadsheet</SelectItem>
                      <SelectItem value="json">JSON Data</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-end">
                  <Button 
                    className="w-full gap-2" 
                    onClick={handleGenerateReport}
                  >
                    <FileText className="h-4 w-4" />
                    Generate Report
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Analytics Dashboard */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart className="h-5 w-5 text-primary" />
                Analytics Dashboard
              </CardTitle>
              <CardDescription>
                Visual insights into device usage and monitoring activities
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              <Tabs defaultValue="overview">
                <TabsList className="mb-4">
                  <TabsTrigger value="overview" className="flex items-center gap-1">
                    <BarChart className="h-4 w-4" /> Overview
                  </TabsTrigger>
                  <TabsTrigger value="devices" className="flex items-center gap-1">
                    <PieChart className="h-4 w-4" /> Devices
                  </TabsTrigger>
                  <TabsTrigger value="activities" className="flex items-center gap-1">
                    <Clock className="h-4 w-4" /> Activities
                  </TabsTrigger>
                  <TabsTrigger value="trends" className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" /> Trends
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="overview">
                  <div className="bg-neutral-lightest h-80 rounded-md flex items-center justify-center">
                    <div className="text-center">
                      <BarChart className="h-12 w-12 mx-auto text-neutral-medium mb-4" />
                      <h3 className="text-lg font-medium">Analytics Overview</h3>
                      <p className="text-sm text-neutral-dark mt-2 max-w-md mx-auto">
                        This dashboard provides a quick overview of all monitoring activities and device statuses.
                        Charts and graphs will be displayed here.
                      </p>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="devices">
                  <div className="bg-neutral-lightest h-80 rounded-md flex items-center justify-center">
                    <div className="text-center">
                      <PieChart className="h-12 w-12 mx-auto text-neutral-medium mb-4" />
                      <h3 className="text-lg font-medium">Device Analytics</h3>
                      <p className="text-sm text-neutral-dark mt-2 max-w-md mx-auto">
                        View device status distribution, usage patterns, and alert frequency across different departments.
                      </p>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="activities">
                  <div className="bg-neutral-lightest h-80 rounded-md flex items-center justify-center">
                    <div className="text-center">
                      <Clock className="h-12 w-12 mx-auto text-neutral-medium mb-4" />
                      <h3 className="text-lg font-medium">Activity Analytics</h3>
                      <p className="text-sm text-neutral-dark mt-2 max-w-md mx-auto">
                        Analyze monitoring activities, file transfers, and remote control sessions over time.
                      </p>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="trends">
                  <div className="bg-neutral-lightest h-80 rounded-md flex items-center justify-center">
                    <div className="text-center">
                      <Calendar className="h-12 w-12 mx-auto text-neutral-medium mb-4" />
                      <h3 className="text-lg font-medium">Trend Analysis</h3>
                      <p className="text-sm text-neutral-dark mt-2 max-w-md mx-auto">
                        Track trends in device usage, monitoring activities, and security alerts over time.
                      </p>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
