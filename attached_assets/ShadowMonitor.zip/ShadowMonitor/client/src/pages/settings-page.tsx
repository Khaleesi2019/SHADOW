import { useState } from "react";
import MainLayout from "@/components/layout/main-layout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { 
  UserCog, 
  Bell, 
  Lock, 
  Shield, 
  Eye, 
  EyeOff, 
  Save, 
  RefreshCw, 
  Globe, 
  Languages, 
  Moon, 
  Sun, 
  Paintbrush, 
  ToggleLeft, 
  Trash2, 
  LogOut, 
  HelpCircle,
  MessageSquare
} from "lucide-react";

export default function SettingsPage() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("account");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  // Form states
  const [notifications, setNotifications] = useState({
    emailAlerts: true,
    deviceConnections: true,
    securityAlerts: true,
    locationAlerts: true,
    usageReports: false,
    appInstallations: true
  });
  
  const [securitySettings, setSecuritySettings] = useState({
    twoFactorAuth: false,
    sessionTimeout: "30",
    ipRestriction: false,
    allowedIps: "",
    loginNotifications: true
  });
  
  const [appearance, setAppearance] = useState({
    theme: "system",
    language: "en",
    fontSize: "medium",
    compactView: false
  });
  
  const handleSaveSettings = () => {
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      toast({
        title: "Settings Saved",
        description: "Your changes have been successfully saved."
      });
    }, 1000);
  };
  
  const handlePasswordChange = () => {
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      toast({
        title: "Password Updated",
        description: "Your password has been successfully changed."
      });
    }, 1000);
  };
  
  const handleDeleteAccount = () => {
    toast({
      title: "Action Required",
      description: "Please contact system administrator to delete your account.",
      variant: "destructive"
    });
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const handleNotificationChange = (key: string, value: boolean) => {
    setNotifications(prev => ({
      ...prev,
      [key]: value
    }));
  };
  
  const handleSecurityChange = (key: string, value: any) => {
    setSecuritySettings(prev => ({
      ...prev,
      [key]: value
    }));
  };
  
  const handleAppearanceChange = (key: string, value: any) => {
    setAppearance(prev => ({
      ...prev,
      [key]: value
    }));
  };
  
  return (
    <MainLayout title="Settings">
      <div className="flex flex-col md:flex-row gap-6">
        {/* Settings navigation */}
        <div className="md:w-64">
          <Card>
            <CardContent className="p-4">
              <Tabs
                orientation="vertical"
                value={activeTab}
                onValueChange={setActiveTab}
                className="w-full"
              >
                <TabsList className="flex flex-col h-auto items-stretch justify-start bg-transparent p-0 space-y-1">
                  <TabsTrigger 
                    value="account" 
                    className="justify-start px-3 py-2 h-auto data-[state=active]:bg-primary-light/10 data-[state=active]:text-primary"
                  >
                    <UserCog className="h-4 w-4 mr-2" />
                    Account
                  </TabsTrigger>
                  <TabsTrigger 
                    value="notifications" 
                    className="justify-start px-3 py-2 h-auto data-[state=active]:bg-primary-light/10 data-[state=active]:text-primary"
                  >
                    <Bell className="h-4 w-4 mr-2" />
                    Notifications
                  </TabsTrigger>
                  <TabsTrigger 
                    value="security" 
                    className="justify-start px-3 py-2 h-auto data-[state=active]:bg-primary-light/10 data-[state=active]:text-primary"
                  >
                    <Lock className="h-4 w-4 mr-2" />
                    Security
                  </TabsTrigger>
                  <TabsTrigger 
                    value="appearance" 
                    className="justify-start px-3 py-2 h-auto data-[state=active]:bg-primary-light/10 data-[state=active]:text-primary"
                  >
                    <Paintbrush className="h-4 w-4 mr-2" />
                    Appearance
                  </TabsTrigger>
                  <TabsTrigger 
                    value="help" 
                    className="justify-start px-3 py-2 h-auto data-[state=active]:bg-primary-light/10 data-[state=active]:text-primary"
                  >
                    <HelpCircle className="h-4 w-4 mr-2" />
                    Help & Support
                  </TabsTrigger>
                </TabsList>
              </Tabs>
              
              <Separator className="my-4" />
              
              <Button 
                variant="destructive" 
                className="w-full justify-start"
                onClick={handleLogout}
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </CardContent>
          </Card>
        </div>
        
        {/* Settings content */}
        <div className="flex-1">
          <TabsContent value="account" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Account Settings</CardTitle>
                <CardDescription>Manage your account information and preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Personal Information</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <Input id="name" defaultValue={user?.name || ""} />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <Input id="email" defaultValue={user?.email || ""} type="email" />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="username">Username</Label>
                      <Input id="username" defaultValue={user?.username || ""} />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="role">Role</Label>
                      <Input id="role" defaultValue={user?.role || ""} disabled />
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Change Password</h3>
                  
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="current-password">Current Password</Label>
                      <div className="relative">
                        <Input 
                          id="current-password" 
                          type={showCurrentPassword ? "text" : "password"} 
                          placeholder="Enter current password" 
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="absolute right-2 top-1/2 -translate-y-1/2"
                          onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                        >
                          {showCurrentPassword ? (
                            <EyeOff className="h-4 w-4" />
                          ) : (
                            <Eye className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="new-password">New Password</Label>
                      <div className="relative">
                        <Input 
                          id="new-password" 
                          type={showNewPassword ? "text" : "password"} 
                          placeholder="Enter new password" 
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="absolute right-2 top-1/2 -translate-y-1/2"
                          onClick={() => setShowNewPassword(!showNewPassword)}
                        >
                          {showNewPassword ? (
                            <EyeOff className="h-4 w-4" />
                          ) : (
                            <Eye className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="confirm-password">Confirm New Password</Label>
                      <div className="relative">
                        <Input 
                          id="confirm-password" 
                          type={showConfirmPassword ? "text" : "password"} 
                          placeholder="Confirm new password" 
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="absolute right-2 top-1/2 -translate-y-1/2"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        >
                          {showConfirmPassword ? (
                            <EyeOff className="h-4 w-4" />
                          ) : (
                            <Eye className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                    
                    <Button onClick={handlePasswordChange} disabled={isSubmitting}>
                      {isSubmitting ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          Changing Password...
                        </>
                      ) : (
                        "Change Password"
                      )}
                    </Button>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Danger Zone</h3>
                  
                  <Card className="border-red-200 bg-red-50">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <h4 className="font-medium text-red-700">Delete Account</h4>
                          <p className="text-sm text-red-600">
                            This action cannot be undone. All data will be permanently deleted.
                          </p>
                        </div>
                        <Button variant="destructive" onClick={handleDeleteAccount}>
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete Account
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
              <CardFooter className="border-t px-6 py-4 flex justify-end">
                <Button onClick={handleSaveSettings} disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Save Changes
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="notifications" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Notification Settings</CardTitle>
                <CardDescription>Control how and when you receive notifications</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Email Alerts</Label>
                      <p className="text-sm text-neutral-dark">Receive email notifications for important alerts</p>
                    </div>
                    <Switch 
                      checked={notifications.emailAlerts} 
                      onCheckedChange={(checked) => handleNotificationChange("emailAlerts", checked)} 
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Device Connections</Label>
                      <p className="text-sm text-neutral-dark">Notify when devices connect or disconnect</p>
                    </div>
                    <Switch 
                      checked={notifications.deviceConnections} 
                      onCheckedChange={(checked) => handleNotificationChange("deviceConnections", checked)} 
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Security Alerts</Label>
                      <p className="text-sm text-neutral-dark">Notify about security issues and suspicious activity</p>
                    </div>
                    <Switch 
                      checked={notifications.securityAlerts} 
                      onCheckedChange={(checked) => handleNotificationChange("securityAlerts", checked)} 
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Location Alerts</Label>
                      <p className="text-sm text-neutral-dark">Notify when devices leave geofenced areas</p>
                    </div>
                    <Switch 
                      checked={notifications.locationAlerts} 
                      onCheckedChange={(checked) => handleNotificationChange("locationAlerts", checked)} 
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Usage Reports</Label>
                      <p className="text-sm text-neutral-dark">Receive weekly usage reports for all devices</p>
                    </div>
                    <Switch 
                      checked={notifications.usageReports} 
                      onCheckedChange={(checked) => handleNotificationChange("usageReports", checked)} 
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">App Installations</Label>
                      <p className="text-sm text-neutral-dark">Notify when new apps are installed on monitored devices</p>
                    </div>
                    <Switch 
                      checked={notifications.appInstallations} 
                      onCheckedChange={(checked) => handleNotificationChange("appInstallations", checked)} 
                    />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t px-6 py-4 flex justify-end">
                <Button onClick={handleSaveSettings} disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Save Changes
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="security" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Security Settings</CardTitle>
                <CardDescription>Configure security options for your account</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Two-Factor Authentication</Label>
                      <p className="text-sm text-neutral-dark">Add an extra layer of security to your account</p>
                    </div>
                    <Switch 
                      checked={securitySettings.twoFactorAuth} 
                      onCheckedChange={(checked) => handleSecurityChange("twoFactorAuth", checked)} 
                    />
                  </div>
                  
                  {securitySettings.twoFactorAuth && (
                    <Card className="border-primary/20 bg-primary/5">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          <Shield className="h-5 w-5 text-primary flex-shrink-0 mt-1" />
                          <div>
                            <h4 className="font-medium text-primary">Set up Two-Factor Authentication</h4>
                            <p className="text-sm text-neutral-dark">
                              To enable 2FA, you'll need to set up an authenticator app like Google Authenticator or Authy.
                            </p>
                            <Button variant="outline" className="mt-2 border-primary/20 text-primary">
                              Configure 2FA
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                  
                  <Separator />
                  
                  <div className="space-y-2">
                    <Label htmlFor="sessionTimeout" className="text-base">Session Timeout (minutes)</Label>
                    <p className="text-sm text-neutral-dark mb-2">Automatically log out after period of inactivity</p>
                    <Select 
                      value={securitySettings.sessionTimeout} 
                      onValueChange={(value) => handleSecurityChange("sessionTimeout", value)}
                    >
                      <SelectTrigger id="sessionTimeout">
                        <SelectValue placeholder="Select timeout period" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="15">15 minutes</SelectItem>
                        <SelectItem value="30">30 minutes</SelectItem>
                        <SelectItem value="60">1 hour</SelectItem>
                        <SelectItem value="120">2 hours</SelectItem>
                        <SelectItem value="0">Never</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-base">IP Restriction</Label>
                        <p className="text-sm text-neutral-dark">Only allow access from specific IP addresses</p>
                      </div>
                      <Switch 
                        checked={securitySettings.ipRestriction} 
                        onCheckedChange={(checked) => handleSecurityChange("ipRestriction", checked)} 
                      />
                    </div>
                    
                    {securitySettings.ipRestriction && (
                      <div className="space-y-2">
                        <Label htmlFor="allowedIps">Allowed IP Addresses</Label>
                        <Input 
                          id="allowedIps" 
                          placeholder="Enter comma-separated IP addresses" 
                          value={securitySettings.allowedIps}
                          onChange={(e) => handleSecurityChange("allowedIps", e.target.value)}
                        />
                        <p className="text-xs text-neutral-dark">e.g. 192.168.1.1, 10.0.0.1, 172.16.0.0/16</p>
                      </div>
                    )}
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Login Notifications</Label>
                      <p className="text-sm text-neutral-dark">Get notified of new login attempts</p>
                    </div>
                    <Switch 
                      checked={securitySettings.loginNotifications} 
                      onCheckedChange={(checked) => handleSecurityChange("loginNotifications", checked)} 
                    />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t px-6 py-4 flex justify-end">
                <Button onClick={handleSaveSettings} disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Save Changes
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="appearance" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Appearance Settings</CardTitle>
                <CardDescription>Customize the look and feel of the application</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="theme" className="text-base">Theme</Label>
                    <div className="grid grid-cols-3 gap-4 pt-2">
                      <div 
                        className={`flex flex-col items-center space-y-2 border rounded-md p-4 cursor-pointer transition-all hover:border-primary ${appearance.theme === 'light' ? 'border-primary bg-primary/5' : 'border-neutral-medium'}`}
                        onClick={() => handleAppearanceChange("theme", "light")}
                      >
                        <Sun className="h-8 w-8 text-orange-500" />
                        <span className="text-sm font-medium">Light</span>
                      </div>
                      
                      <div 
                        className={`flex flex-col items-center space-y-2 border rounded-md p-4 cursor-pointer transition-all hover:border-primary ${appearance.theme === 'dark' ? 'border-primary bg-primary/5' : 'border-neutral-medium'}`}
                        onClick={() => handleAppearanceChange("theme", "dark")}
                      >
                        <Moon className="h-8 w-8 text-indigo-600" />
                        <span className="text-sm font-medium">Dark</span>
                      </div>
                      
                      <div 
                        className={`flex flex-col items-center space-y-2 border rounded-md p-4 cursor-pointer transition-all hover:border-primary ${appearance.theme === 'system' ? 'border-primary bg-primary/5' : 'border-neutral-medium'}`}
                        onClick={() => handleAppearanceChange("theme", "system")}
                      >
                        <div className="flex gap-1">
                          <Sun className="h-4 w-4 text-orange-500" />
                          <Moon className="h-4 w-4 text-indigo-600" />
                        </div>
                        <span className="text-sm font-medium">System</span>
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-2">
                    <Label htmlFor="language" className="text-base">Language</Label>
                    <Select 
                      value={appearance.language} 
                      onValueChange={(value) => handleAppearanceChange("language", value)}
                    >
                      <SelectTrigger id="language" className="flex items-center">
                        <Globe className="h-4 w-4 mr-2" />
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="es">Español</SelectItem>
                        <SelectItem value="fr">Français</SelectItem>
                        <SelectItem value="de">Deutsch</SelectItem>
                        <SelectItem value="pt">Português</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-2">
                    <Label htmlFor="fontSize" className="text-base">Font Size</Label>
                    <Select 
                      value={appearance.fontSize} 
                      onValueChange={(value) => handleAppearanceChange("fontSize", value)}
                    >
                      <SelectTrigger id="fontSize">
                        <SelectValue placeholder="Select font size" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="small">Small</SelectItem>
                        <SelectItem value="medium">Medium (Default)</SelectItem>
                        <SelectItem value="large">Large</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Compact View</Label>
                      <p className="text-sm text-neutral-dark">Use a more compact layout to fit more content</p>
                    </div>
                    <Switch 
                      checked={appearance.compactView} 
                      onCheckedChange={(checked) => handleAppearanceChange("compactView", checked)} 
                    />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t px-6 py-4 flex justify-end">
                <Button onClick={handleSaveSettings} disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Save Changes
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="help" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Help & Support</CardTitle>
                <CardDescription>Get help with using SecureMonitor Pro</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <Card className="border-primary/20 bg-primary/5">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <HelpCircle className="h-5 w-5 text-primary flex-shrink-0 mt-1" />
                        <div>
                          <h4 className="font-medium text-primary">Documentation</h4>
                          <p className="text-sm text-neutral-dark mb-2">
                            Access comprehensive guides and documentation about using SecureMonitor Pro.
                          </p>
                          <Button variant="outline" className="border-primary/20 text-primary">
                            View Documentation
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex flex-col items-center text-center space-y-2 py-2">
                          <MessageSquare className="h-8 w-8 text-primary mb-2" />
                          <h4 className="font-medium">Contact Support</h4>
                          <p className="text-sm text-neutral-dark">
                            Get in touch with our support team for personalized assistance.
                          </p>
                          <Button variant="default" className="mt-2">
                            Contact Support
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex flex-col items-center text-center space-y-2 py-2">
                          <Languages className="h-8 w-8 text-primary mb-2" />
                          <h4 className="font-medium">Knowledge Base</h4>
                          <p className="text-sm text-neutral-dark">
                            Browse our knowledge base for answers to common questions.
                          </p>
                          <Button variant="outline" className="mt-2">
                            View Articles
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">Frequently Asked Questions</h3>
                    
                    <div className="space-y-4 pt-2">
                      <Card>
                        <CardContent className="p-4">
                          <h4 className="font-medium mb-2">How do I add a new device to monitor?</h4>
                          <p className="text-sm text-neutral-dark">
                            To add a new device, go to the Devices page and click the "Add Device" button. 
                            Follow the on-screen instructions to install the monitoring agent on the target device.
                          </p>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardContent className="p-4">
                          <h4 className="font-medium mb-2">Is the monitoring detectable by device users?</h4>
                          <p className="text-sm text-neutral-dark">
                            The monitoring agent runs in the background and is designed to be unobtrusive. 
                            However, for legal and ethical reasons, we recommend informing users that their 
                            company-owned devices are being monitored.
                          </p>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardContent className="p-4">
                          <h4 className="font-medium mb-2">What information is collected from monitored devices?</h4>
                          <p className="text-sm text-neutral-dark">
                            The system collects device usage statistics, installed applications, location data, 
                            and can provide remote screen viewing capabilities. You can configure exactly what 
                            data is collected in the device settings.
                          </p>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-neutral-lightest rounded-lg border border-neutral-medium">
                    <h3 className="font-medium">About SecureMonitor Pro</h3>
                    <p className="text-sm text-neutral-dark mt-1">Version 1.0.0</p>
                    <p className="text-sm text-neutral-dark mt-2">
                      SecureMonitor Pro is a comprehensive MDM solution for businesses to securely monitor 
                      and manage company devices.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </div>
    </MainLayout>
  );
}
