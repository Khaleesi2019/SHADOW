import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Device } from "@shared/schema";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { Header } from "@/components/dashboard/Header";
import { DeviceStats } from "@/components/dashboard/DeviceStats";
import { DeviceFilters, DeviceFilterValue, DeviceViewMode, DeviceSortOption } from "@/components/dashboard/DeviceFilters";
import { DeviceCard } from "@/components/dashboard/DeviceCard";
import { DeviceDetails } from "@/components/dashboard/DeviceDetails";
import { useToast } from "@/hooks/use-toast";
import { PageTitle } from "@/components/PageTitle";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSocket } from "@/lib/socket";

export default function Dashboard() {
  const { toast } = useToast();
  const socket = useSocket();
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [showDeviceDetails, setShowDeviceDetails] = useState(false);
  const [filter, setFilter] = useState<DeviceFilterValue>("all");
  const [viewMode, setViewMode] = useState<DeviceViewMode>("grid");
  const [sortBy, setSortBy] = useState<DeviceSortOption>("lastActive");
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: devices = [], isLoading, refetch } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
  });

  useEffect(() => {
    // Listen for device updates via WebSocket
    if (socket) {
      socket.on("device-update", (updatedDevice: Device) => {
        toast({
          title: "Device Updated",
          description: `${updatedDevice.name} status changed to ${updatedDevice.status}`,
        });
        refetch();
      });
      
      socket.on("device-alert", (alertDevice: Device) => {
        toast({
          title: "Alert Detected!",
          description: alertDevice.alertMessage || `Alert on ${alertDevice.name}`,
          variant: "destructive",
        });
        refetch();
      });
      
      return () => {
        socket.off("device-update");
        socket.off("device-alert");
      };
    }
  }, [socket, toast, refetch]);

  // Calculate statistics
  const totalDevices = devices.length;
  const onlineDevices = devices.filter(d => d.status === "online").length;
  const alertsCount = devices.filter(d => d.status === "alert").length;
  const dataTransferred = "1.2 GB"; // This would be calculated from actual transfer data

  // Filter devices
  const filteredDevices = devices
    .filter(device => {
      // Apply search filter
      const matchesSearch = 
        searchQuery === "" || 
        device.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        device.userId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        device.department?.toLowerCase().includes(searchQuery.toLowerCase());
      
      // Apply status filter
      const matchesFilter = 
        filter === "all" || 
        (filter === "online" && device.status === "online") ||
        (filter === "offline" && device.status === "offline") ||
        (filter === "alert" && device.status === "alert");
      
      return matchesSearch && matchesFilter;
    })
    .sort((a, b) => {
      // Apply sorting
      switch (sortBy) {
        case "name":
          return a.name.localeCompare(b.name);
        case "status":
          return (a.status || "").localeCompare(b.status || "");
        case "type":
          return (a.type || "").localeCompare(b.type || "");
        case "lastActive":
        default:
          const dateA = a.lastActive ? new Date(a.lastActive).getTime() : 0;
          const dateB = b.lastActive ? new Date(b.lastActive).getTime() : 0;
          return dateB - dateA; // Most recent first
      }
    });

  const handleMonitorClick = (device: Device) => {
    setSelectedDevice(device);
    setShowDeviceDetails(true);
  };

  const handleFilesClick = (device: Device) => {
    // Navigate to file transfer page with this device selected
    window.location.href = `/files?deviceId=${device.id}`;
  };

  const handleLocationClick = (device: Device) => {
    // Navigate to location page with this device selected
    window.location.href = `/location?deviceId=${device.id}`;
  };

  const handleMoreClick = (device: Device) => {
    setSelectedDevice(device);
    setShowDeviceDetails(true);
  };

  const handleTakeControl = (device: Device) => {
    toast({
      title: "Taking Control",
      description: `Establishing connection to ${device.name}...`,
    });
    
    if (socket) {
      socket.emit("take-control", { deviceId: device.id });
    }
  };

  const handleLockDevice = (device: Device) => {
    toast({
      title: "Device Locked",
      description: `${device.name} has been locked remotely.`,
    });
    
    if (socket) {
      socket.emit("lock-device", { deviceId: device.id });
    }
  };

  const handleRefreshScreen = () => {
    toast({
      title: "Refreshing Screen",
      description: "Requesting latest screenshot...",
    });
    
    if (socket && selectedDevice) {
      socket.emit("refresh-screen", { deviceId: selectedDevice.id });
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-lightest">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="Dashboard" 
          onSearch={setSearchQuery}
          searchPlaceholder="Search devices..."
          notificationCount={alertsCount}
        />
        
        <main className="flex-1 overflow-y-auto p-4 bg-neutral-lightest">
          <PageTitle 
            title="Dashboard Overview" 
            description="Monitor and manage all connected devices"
          >
            <Button size="sm" className="gap-1">
              <Plus className="h-4 w-4" /> Add Device
            </Button>
          </PageTitle>
          
          <DeviceStats 
            totalDevices={totalDevices}
            onlineDevices={onlineDevices}
            alertsCount={alertsCount}
            dataTransferred={dataTransferred}
            isLoading={isLoading}
          />
          
          <DeviceFilters 
            onFilterChange={setFilter}
            onViewModeChange={setViewMode}
            onSortChange={setSortBy}
            activeFilter={filter}
            viewMode={viewMode}
            sortBy={sortBy}
          />
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <div 
                  key={i} 
                  className="bg-white rounded-lg shadow-sm border border-neutral-medium h-60 animate-pulse"
                ></div>
              ))}
            </div>
          ) : filteredDevices.length > 0 ? (
            <div className={`grid gap-4 ${viewMode === "grid" 
              ? "grid-cols-1 md:grid-cols-2 xl:grid-cols-3" 
              : "grid-cols-1"}`}
            >
              {filteredDevices.map((device) => (
                <DeviceCard 
                  key={device.id}
                  device={device}
                  onMonitorClick={handleMonitorClick}
                  onFilesClick={handleFilesClick}
                  onLocationClick={handleLocationClick}
                  onMoreClick={handleMoreClick}
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-neutral">
              <div className="bg-white p-8 rounded-lg shadow-sm border border-neutral-medium text-center">
                <svg className="mx-auto h-12 w-12 text-neutral" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 className="mt-2 text-sm font-medium text-neutral-darkest">No devices found</h3>
                <p className="mt-1 text-sm text-neutral-dark">
                  {searchQuery ? "Try adjusting your search or filter criteria" : "Add devices to start monitoring"}
                </p>
                <div className="mt-6">
                  <Button size="sm" className="gap-1">
                    <Plus className="h-4 w-4" /> Add Device
                  </Button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
      
      {selectedDevice && (
        <DeviceDetails
          device={selectedDevice}
          isOpen={showDeviceDetails}
          onClose={() => setShowDeviceDetails(false)}
          onTakeControl={handleTakeControl}
          onLockDevice={handleLockDevice}
          onRefreshScreen={handleRefreshScreen}
        />
      )}
    </div>
  );
}
