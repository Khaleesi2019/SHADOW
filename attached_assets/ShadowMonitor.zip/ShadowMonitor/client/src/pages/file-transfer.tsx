import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Device, File as FileType } from "@shared/schema";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { Header } from "@/components/dashboard/Header";
import { FileTransferComponent } from "@/components/dashboard/FileTransfer";
import { useToast } from "@/hooks/use-toast";
import { PageTitle } from "@/components/PageTitle";
import { useSocket } from "@/lib/socket";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useSearchParams } from "wouter";

export default function FileTransfer() {
  const { toast } = useToast();
  const socket = useSocket();
  const [searchParams] = useSearchParams();
  const deviceIdParam = searchParams.get("deviceId");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDeviceId, setSelectedDeviceId] = useState<string | null>(deviceIdParam);
  
  const { data: devices = [], isLoading: devicesLoading } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
  });

  const { data: files = [], isLoading: filesLoading, refetch: refetchFiles } = useQuery<FileType[]>({
    queryKey: ["/api/files", selectedDeviceId],
    enabled: !!selectedDeviceId,
  });

  // Find the selected device
  const selectedDevice = selectedDeviceId 
    ? devices.find(d => d.id.toString() === selectedDeviceId) || null
    : null;

  useEffect(() => {
    // Update selected device from URL if provided
    if (deviceIdParam && deviceIdParam !== selectedDeviceId) {
      setSelectedDeviceId(deviceIdParam);
    }
  }, [deviceIdParam, selectedDeviceId]);

  useEffect(() => {
    // Listen for file transfer events via WebSocket
    if (socket) {
      socket.on("file-transfer-progress", (data: { deviceId: number, fileId: number, progress: number }) => {
        toast({
          title: "File Transfer Progress",
          description: `Transfer ${data.progress}% complete`,
        });
        if (data.progress === 100) {
          refetchFiles();
        }
      });
      
      socket.on("file-transfer-error", (data: { deviceId: number, fileId: number, error: string }) => {
        toast({
          title: "File Transfer Error",
          description: data.error,
          variant: "destructive",
        });
      });
      
      return () => {
        socket.off("file-transfer-progress");
        socket.off("file-transfer-error");
      };
    }
  }, [socket, toast, refetchFiles]);

  // File mutations
  const uploadFileMutation = useMutation({
    mutationFn: async (files: FileList) => {
      if (!selectedDeviceId) throw new Error("No device selected");
      
      const formData = new FormData();
      formData.append("deviceId", selectedDeviceId);
      
      for (let i = 0; i < files.length; i++) {
        formData.append("files", files[i]);
      }
      
      const res = await fetch("/api/files/upload", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || res.statusText);
      }
      
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/files", selectedDeviceId] });
      toast({
        title: "Upload Started",
        description: "Files are being uploaded to the device.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Upload Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const downloadFileMutation = useMutation({
    mutationFn: async (fileId: number) => {
      await apiRequest("GET", `/api/files/${fileId}/download`);
    },
    onSuccess: () => {
      toast({
        title: "Download Started",
        description: "File download initiated.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Download Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteFileMutation = useMutation({
    mutationFn: async (fileId: number) => {
      await apiRequest("DELETE", `/api/files/${fileId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/files", selectedDeviceId] });
      toast({
        title: "File Deleted",
        description: "File has been deleted.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Delete Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const viewFileMutation = useMutation({
    mutationFn: async (fileId: number) => {
      await apiRequest("GET", `/api/files/${fileId}/view`);
    },
    onSuccess: () => {
      toast({
        title: "Viewing File",
        description: "File viewer opened.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "View Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handlers
  const handleFileUpload = (files: FileList) => {
    uploadFileMutation.mutate(files);
  };

  const handleFileDownload = (fileId: number) => {
    downloadFileMutation.mutate(fileId);
  };

  const handleFileDelete = (fileId: number) => {
    if (confirm("Are you sure you want to delete this file?")) {
      deleteFileMutation.mutate(fileId);
    }
  };

  const handleFileView = (fileId: number) => {
    viewFileMutation.mutate(fileId);
  };

  const handleRefresh = () => {
    refetchFiles();
  };

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-lightest">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="File Transfer" 
          onSearch={setSearchQuery}
          searchPlaceholder="Search files..."
          notificationCount={devices.filter(d => d.status === "alert").length}
        />
        
        <main className="flex-1 overflow-y-auto p-4 bg-neutral-lightest">
          <PageTitle 
            title="File Transfer" 
            description={selectedDevice 
              ? `Transfer files to and from ${selectedDevice.name}` 
              : "Select a device to transfer files"}
          />
          
          <FileTransferComponent 
            selectedDevice={selectedDevice}
            files={files.filter(file => 
              !searchQuery || file.filename.toLowerCase().includes(searchQuery.toLowerCase())
            )}
            isLoading={filesLoading}
            onFileUpload={handleFileUpload}
            onFileDownload={handleFileDownload}
            onFileDelete={handleFileDelete}
            onFileView={handleFileView}
            onRefresh={handleRefresh}
          />
        </main>
      </div>
    </div>
  );
}
