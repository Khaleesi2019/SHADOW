import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Device, DeviceLocation } from "@shared/schema";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { Header } from "@/components/dashboard/Header";
import { LocationTracker } from "@/components/dashboard/LocationTracker";
import { useToast } from "@/hooks/use-toast";
import { PageTitle } from "@/components/PageTitle";
import { useSocket } from "@/lib/socket";
import { useSearchParams } from "wouter";

export default function Location() {
  const { toast } = useToast();
  const socket = useSocket();
  const [searchParams] = useSearchParams();
  const deviceIdParam = searchParams.get("deviceId");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDeviceId, setSelectedDeviceId] = useState<string | null>(deviceIdParam);
  const [timeframe, setTimeframe] = useState("today");
  
  const { data: devices = [], isLoading: devicesLoading } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
  });

  const { data: locations = [], isLoading: locationsLoading, refetch: refetchLocations } = useQuery<DeviceLocation[]>({
    queryKey: ["/api/locations", selectedDeviceId, timeframe],
    enabled: !!selectedDeviceId,
  });

  useEffect(() => {
    // Update selected device from URL if provided
    if (deviceIdParam && deviceIdParam !== selectedDeviceId) {
      setSelectedDeviceId(deviceIdParam);
    }
  }, [deviceIdParam, selectedDeviceId]);

  useEffect(() => {
    // Listen for location updates via WebSocket
    if (socket) {
      socket.on("location-update", (data: { deviceId: number, location: DeviceLocation }) => {
        if (selectedDeviceId && parseInt(selectedDeviceId) === data.deviceId) {
          toast({
            title: "Location Updated",
            description: "Device location has been updated.",
          });
          refetchLocations();
        }
      });
      
      return () => {
        socket.off("location-update");
      };
    }
  }, [socket, toast, refetchLocations, selectedDeviceId]);

  const handleDeviceSelect = (deviceId: string) => {
    setSelectedDeviceId(deviceId);
  };

  const handleTimeframeChange = (newTimeframe: string) => {
    setTimeframe(newTimeframe);
  };

  const handleRefresh = () => {
    refetchLocations();
  };

  // Find the selected device
  const selectedDevice = selectedDeviceId 
    ? devices.find(d => d.id.toString() === selectedDeviceId) 
    : null;

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-lightest">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="Location Tracking" 
          onSearch={setSearchQuery}
          searchPlaceholder="Search devices..."
          notificationCount={devices.filter(d => d.status === "alert").length}
        />
        
        <main className="flex-1 overflow-y-auto p-4 bg-neutral-lightest">
          <PageTitle 
            title="Location Tracking" 
            description="Monitor device locations in real-time"
          />
          
          <LocationTracker 
            devices={devices.filter(device => 
              !searchQuery || 
              device.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
              device.userId.toLowerCase().includes(searchQuery.toLowerCase())
            )}
            selectedDevice={selectedDevice}
            locations={locations}
            isLoading={locationsLoading}
            onDeviceSelect={handleDeviceSelect}
            onRefresh={handleRefresh}
            onTimeframeChange={handleTimeframeChange}
          />
        </main>
      </div>
    </div>
  );
}
