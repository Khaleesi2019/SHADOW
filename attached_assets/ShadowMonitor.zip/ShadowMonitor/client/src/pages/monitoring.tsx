import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Device, DeviceActivity } from "@shared/schema";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { Header } from "@/components/dashboard/Header";
import { DeviceDetails } from "@/components/dashboard/DeviceDetails";
import { useToast } from "@/hooks/use-toast";
import { PageTitle } from "@/components/PageTitle";
import { useSocket } from "@/lib/socket";
import { 
  Eye, 
  RefreshCw, 
  Clock, 
  Filter, 
  BarChart, 
  User, 
  MonitorSmartphone,
  DownloadCloud,
  MousePointerClick,
  Shield,
  CalendarRange,
  Search
} from "lucide-react";
import { 
  Button, 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
  Input,
  Badge,
  Avatar,
  AvatarFallback,
} from "@/components/ui";
import { DataTable } from "@/components/ui/data-table";
import { ColumnDef } from "@tanstack/react-table";

export default function Monitoring() {
  const { toast } = useToast();
  const socket = useSocket();
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [showDeviceDetails, setShowDeviceDetails] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [timeframe, setTimeframe] = useState("today");
  const [activityType, setActivityType] = useState("all");
  
  const { data: devices = [], isLoading: devicesLoading } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
  });

  const { data: activities = [], isLoading: activitiesLoading, refetch } = useQuery<DeviceActivity[]>({
    queryKey: ["/api/activities", timeframe, activityType],
  });

  useEffect(() => {
    // Listen for activities via WebSocket
    if (socket) {
      socket.on("new-activity", (activity: DeviceActivity) => {
        toast({
          title: "New Activity",
          description: `${activity.action} on device ${activity.deviceId}`,
        });
        refetch();
      });
      
      return () => {
        socket.off("new-activity");
      };
    }
  }, [socket, toast, refetch]);

  // Filter activities based on search query
  const filteredActivities = activities.filter(activity => {
    if (!searchQuery) return true;
    
    // Find the device name for this activity
    const device = devices.find(d => d.id === activity.deviceId);
    const deviceName = device?.name || `Device ${activity.deviceId}`;
    
    return (
      deviceName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      activity.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      activity.details?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  const handleTakeControl = (device: Device) => {
    toast({
      title: "Taking Control",
      description: `Establishing connection to ${device.name}...`,
    });
    
    if (socket) {
      socket.emit("take-control", { deviceId: device.id });
    }
  };

  const handleLockDevice = (device: Device) => {
    toast({
      title: "Device Locked",
      description: `${device.name} has been locked remotely.`,
    });
    
    if (socket) {
      socket.emit("lock-device", { deviceId: device.id });
    }
  };

  const handleRefreshScreen = () => {
    toast({
      title: "Refreshing Screen",
      description: "Requesting latest screenshot...",
    });
    
    if (socket && selectedDevice) {
      socket.emit("refresh-screen", { deviceId: selectedDevice.id });
    }
  };

  // View device details when clicking on a device activity
  const handleViewDevice = (deviceId: number) => {
    const device = devices.find(d => d.id === deviceId);
    if (device) {
      setSelectedDevice(device);
      setShowDeviceDetails(true);
    }
  };

  // Function to format timestamp
  const formatDate = (timestamp: string | Date) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  // Get status indicator badge for a device
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "online":
        return <Badge variant="outline" className="bg-green-100 text-green-700 border-green-200">Online</Badge>;
      case "alert":
        return <Badge variant="outline" className="bg-red-100 text-red-700 border-red-200">Alert</Badge>;
      default:
        return <Badge variant="outline" className="bg-neutral-100 text-neutral-700">Offline</Badge>;
    }
  };

  // Get action icon for activity
  const getActionIcon = (action: string) => {
    switch (action) {
      case "screencapture":
        return <Eye className="h-4 w-4 text-blue-500" />;
      case "filetransfer":
        return <DownloadCloud className="h-4 w-4 text-green-500" />;
      case "remotecontrol":
        return <MousePointerClick className="h-4 w-4 text-purple-500" />;
      case "unlock":
        return <Shield className="h-4 w-4 text-orange-500" />;
      default:
        return <Eye className="h-4 w-4 text-neutral-500" />;
    }
  };

  // Table columns for activity log
  const columns: ColumnDef<DeviceActivity>[] = [
    {
      accessorKey: "timestamp",
      header: "Time",
      cell: ({ row }) => {
        return <div className="flex items-center">
          <Clock className="h-4 w-4 text-neutral-dark mr-2" />
          <span>{formatDate(row.original.timestamp)}</span>
        </div>;
      },
    },
    {
      accessorKey: "deviceId",
      header: "Device",
      cell: ({ row }) => {
        const device = devices.find(d => d.id === row.original.deviceId);
        return (
          <div className="flex items-center">
            <MonitorSmartphone className="h-4 w-4 text-neutral-dark mr-2" />
            <span className="font-medium">{device?.name || `Device ${row.original.deviceId}`}</span>
            <div className="ml-2">
              {device && getStatusBadge(device.status || "offline")}
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "action",
      header: "Action",
      cell: ({ row }) => {
        return (
          <div className="flex items-center">
            {getActionIcon(row.original.action)}
            <span className="ml-2 capitalize">{row.original.action}</span>
          </div>
        );
      },
    },
    {
      accessorKey: "adminId",
      header: "Admin",
      cell: ({ row }) => {
        return (
          <div className="flex items-center">
            <Avatar className="h-6 w-6 mr-2">
              <AvatarFallback className="text-xs">
                {`A${row.original.adminId}`}
              </AvatarFallback>
            </Avatar>
            <span>Admin {row.original.adminId}</span>
          </div>
        );
      },
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => {
        return (
          <Badge variant={row.original.status === "success" ? "outline" : "destructive"} className="capitalize">
            {row.original.status}
          </Badge>
        );
      },
    },
    {
      id: "actions",
      cell: ({ row }) => {
        return (
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => handleViewDevice(row.original.deviceId)}
          >
            View
          </Button>
        );
      },
    },
  ];

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-lightest">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="Monitoring" 
          onSearch={setSearchQuery}
          searchPlaceholder="Search activities..."
          notificationCount={devices.filter(d => d.status === "alert").length}
        />
        
        <main className="flex-1 overflow-y-auto p-4 bg-neutral-lightest">
          <PageTitle 
            title="Activity Monitoring" 
            description="Track and review all device activities"
          >
            <div className="flex gap-2">
              <Button 
                size="sm" 
                variant="outline" 
                className="gap-1"
                onClick={() => refetch()}
                disabled={activitiesLoading}
              >
                <RefreshCw className={`h-4 w-4 ${activitiesLoading ? "animate-spin" : ""}`} /> Refresh
              </Button>
            </div>
          </PageTitle>
          
          {/* Activity Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Eye className="h-4 w-4 text-blue-500" />
                  Monitoring Sessions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {activities.filter(a => a.action === "screencapture").length}
                </div>
                <p className="text-xs text-neutral mt-1">
                  {timeframe === "today" ? "Today" : 
                   timeframe === "week" ? "This Week" : 
                   timeframe === "month" ? "This Month" : "All Time"}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <DownloadCloud className="h-4 w-4 text-green-500" />
                  File Transfers
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {activities.filter(a => a.action === "filetransfer").length}
                </div>
                <p className="text-xs text-neutral mt-1">
                  {timeframe === "today" ? "Today" : 
                   timeframe === "week" ? "This Week" : 
                   timeframe === "month" ? "This Month" : "All Time"}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <MousePointerClick className="h-4 w-4 text-purple-500" />
                  Remote Control
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {activities.filter(a => a.action === "remotecontrol").length}
                </div>
                <p className="text-xs text-neutral mt-1">
                  {timeframe === "today" ? "Today" : 
                   timeframe === "week" ? "This Week" : 
                   timeframe === "month" ? "This Month" : "All Time"}
                </p>
              </CardContent>
            </Card>
          </div>
          
          {/* Activity Filters */}
          <Card className="mb-6">
            <CardHeader className="pb-2 pt-4">
              <CardTitle className="text-base font-medium flex items-center gap-2">
                <Filter className="h-4 w-4 text-neutral-dark" />
                Activity Filters
              </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-wrap gap-4 pb-4">
              <div className="flex flex-col gap-1">
                <span className="text-sm font-medium">Timeframe</span>
                <Select
                  value={timeframe}
                  onValueChange={setTimeframe}
                >
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Select timeframe" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="today">Today</SelectItem>
                    <SelectItem value="week">This Week</SelectItem>
                    <SelectItem value="month">This Month</SelectItem>
                    <SelectItem value="all">All Time</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex flex-col gap-1">
                <span className="text-sm font-medium">Activity Type</span>
                <Select
                  value={activityType}
                  onValueChange={setActivityType}
                >
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Select activity type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Activities</SelectItem>
                    <SelectItem value="screencapture">Screen Capture</SelectItem>
                    <SelectItem value="filetransfer">File Transfer</SelectItem>
                    <SelectItem value="remotecontrol">Remote Control</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex flex-col gap-1 flex-1">
                <span className="text-sm font-medium">Search</span>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral" />
                  <Input
                    placeholder="Search by device or action..."
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Activity Log */}
          <Card>
            <CardHeader className="pb-0">
              <CardTitle className="text-lg font-medium">Activity Log</CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <Tabs defaultValue="table">
                <TabsList>
                  <TabsTrigger value="table" className="flex items-center gap-1">
                    <Eye className="h-4 w-4" /> Table View
                  </TabsTrigger>
                  <TabsTrigger value="timeline" className="flex items-center gap-1">
                    <Clock className="h-4 w-4" /> Timeline
                  </TabsTrigger>
                  <TabsTrigger value="chart" className="flex items-center gap-1">
                    <BarChart className="h-4 w-4" /> Charts
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="table" className="py-4">
                  {activitiesLoading ? (
                    <div className="flex justify-center py-8">
                      <RefreshCw className="h-8 w-8 animate-spin text-neutral" />
                    </div>
                  ) : filteredActivities.length > 0 ? (
                    <DataTable 
                      columns={columns} 
                      data={filteredActivities}
                      searchKey="action"
                      placeholder="Filter by action..."
                    />
                  ) : (
                    <div className="text-center py-12 text-neutral">
                      <CalendarRange className="h-12 w-12 mx-auto text-neutral-medium mb-2" />
                      <h3 className="text-lg font-medium">No activities found</h3>
                      <p className="text-sm text-neutral-dark mt-1">
                        {searchQuery ? "Try adjusting your search or filter criteria" : "No activity logs for the selected period"}
                      </p>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="timeline" className="py-4">
                  <div className="text-center py-12 text-neutral">
                    <Clock className="h-12 w-12 mx-auto text-neutral-medium mb-2" />
                    <h3 className="text-lg font-medium">Timeline View</h3>
                    <p className="text-sm text-neutral-dark mt-1">
                      Timeline visualization is coming soon
                    </p>
                  </div>
                </TabsContent>
                
                <TabsContent value="chart" className="py-4">
                  <div className="text-center py-12 text-neutral">
                    <BarChart className="h-12 w-12 mx-auto text-neutral-medium mb-2" />
                    <h3 className="text-lg font-medium">Activity Analytics</h3>
                    <p className="text-sm text-neutral-dark mt-1">
                      Graphical activity analytics is coming soon
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </main>
      </div>
      
      {selectedDevice && (
        <DeviceDetails
          device={selectedDevice}
          isOpen={showDeviceDetails}
          onClose={() => setShowDeviceDetails(false)}
          onTakeControl={handleTakeControl}
          onLockDevice={handleLockDevice}
          onRefreshScreen={handleRefreshScreen}
        />
      )}
    </div>
  );
}
