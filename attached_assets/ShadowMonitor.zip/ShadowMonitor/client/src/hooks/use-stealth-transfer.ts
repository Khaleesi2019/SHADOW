import { useState, useEffect } from 'react';
import { stealthTransfer, TransferInfo } from '@/lib/stealthTransfer';

export function useStealthTransfer() {
  const [transfers, setTransfers] = useState<TransferInfo[]>([]);
  
  useEffect(() => {
    // Subscribe to transfer updates
    const unsubscribe = stealthTransfer.subscribeToTransfers((updatedTransfers) => {
      setTransfers(updatedTransfers);
    });
    
    // Cleanup subscription on unmount
    return () => {
      unsubscribe();
    };
  }, []);
  
  // Upload files to device
  const uploadFiles = async (deviceId: string, files: File[]) => {
    try {
      return await stealthTransfer.uploadFilesToDevice(deviceId, files);
    } catch (error) {
      // Silent error handling
      return [];
    }
  };
  
  // Download a file from device
  const downloadFile = async (deviceId: string, filePath: string, filename: string, fileSize: number) => {
    try {
      return await stealthTransfer.downloadFileFromDevice(deviceId, filePath, filename, fileSize);
    } catch (error) {
      // Silent error handling
      return '';
    }
  };
  
  // Cancel an active transfer
  const cancelTransfer = (transferId: string) => {
    return stealthTransfer.cancelTransfer(transferId);
  };
  
  // Get a specific transfer
  const getTransfer = (transferId: string) => {
    return stealthTransfer.getTransfer(transferId);
  };
  
  // Filter transfers by device
  const getTransfersByDevice = (deviceId: string) => {
    return transfers.filter(transfer => transfer.deviceId === deviceId);
  };
  
  // Filter transfers by status
  const getTransfersByStatus = (status: TransferInfo['status']) => {
    return transfers.filter(transfer => transfer.status === status);
  };
  
  // Filter transfers by type
  const getTransfersByType = (type: TransferInfo['type']) => {
    return transfers.filter(transfer => transfer.type === type);
  };
  
  return {
    transfers,
    uploadFiles,
    downloadFile,
    cancelTransfer,
    getTransfer,
    getTransfersByDevice,
    getTransfersByStatus,
    getTransfersByType
  };
}