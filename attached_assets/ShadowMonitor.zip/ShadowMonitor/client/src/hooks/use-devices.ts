import { useQuery, useMutation } from "@tanstack/react-query";
import { Device, InsertDevice } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useWebsocket } from "@/lib/websocket";
import { useCallback, useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";

export function useDevices() {
  const { toast } = useToast();
  const [deviceStates, setDeviceStates] = useState<Record<string, Partial<Device>>>({});
  
  const { data: devices = [], isLoading, error } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
  });
  
  // Create a device
  const createDeviceMutation = useMutation({
    mutationFn: async (device: InsertDevice) => {
      const res = await apiRequest("POST", "/api/devices", device);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devices"] });
      toast({
        title: "Device Created",
        description: "The device has been successfully created.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error Creating Device",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update a device
  const updateDeviceMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Device> }) => {
      const res = await apiRequest("PATCH", `/api/devices/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devices"] });
      toast({
        title: "Device Updated",
        description: "The device has been successfully updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error Updating Device",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Send command to device
  const sendCommandMutation = useMutation({
    mutationFn: async ({ 
      deviceId, 
      command 
    }: { 
      deviceId: string; 
      command: { type: string; [key: string]: any } 
    }) => {
      const res = await apiRequest(
        "POST", 
        `/api/devices/${deviceId}/command`, 
        { command }
      );
      return res.json();
    },
    onSuccess: (_, variables) => {
      toast({
        title: "Command Sent",
        description: `Command '${variables.command.type}' was sent to the device.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Command Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Listen for device updates from WebSocket
  const handleDeviceUpdate = useCallback((message: any) => {
    const { deviceId, ...updates } = message.payload;
    
    if (deviceId) {
      // Update local state with the latest device info
      setDeviceStates(prev => ({
        ...prev,
        [deviceId]: {
          ...(prev[deviceId] || {}),
          ...updates
        }
      }));
    }
  }, []);
  
  useWebsocket('device_update', handleDeviceUpdate);
  
  // Listen for alerts
  const handleAlert = useCallback((message: any) => {
    const { deviceId, alert } = message.payload;
    
    if (deviceId && alert) {
      toast({
        title: `Alert: ${deviceId}`,
        description: alert.message,
        variant: "destructive",
      });
      
      // Update local state with alert
      setDeviceStates(prev => {
        const device = prev[deviceId] || {};
        const alerts = device.alerts || [];
        
        return {
          ...prev,
          [deviceId]: {
            ...device,
            status: 'alert',
            alerts: [...alerts, alert]
          }
        };
      });
    }
  }, [toast]);
  
  useWebsocket('alert', handleAlert);
  
  // Combine the base devices data with real-time updates
  const enhancedDevices = devices.map(device => {
    const realtimeUpdates = deviceStates[device.deviceId] || {};
    return { ...device, ...realtimeUpdates };
  });
  
  return {
    devices: enhancedDevices,
    isLoading,
    error,
    createDevice: createDeviceMutation.mutate,
    updateDevice: updateDeviceMutation.mutate,
    sendCommand: sendCommandMutation.mutate,
    isSendingCommand: sendCommandMutation.isPending
  };
}
